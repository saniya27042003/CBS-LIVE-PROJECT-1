import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { DatabaseMappingService } from './database-mapping.service';
import { DatabaseService } from '../database/database.service';

@Controller('database-mapping')
export class DatabaseMappingController {

  constructor(
    private readonly db: DatabaseMappingService,
    private readonly dbService: DatabaseService
  ) { }

  // ---------------- CONNECTION ENDPOINTS ----------------

  @Post('connect-server')
  async connectServer(@Body() config: any) {
    return this.db.connectServer(config);
  }

  @Post('connect-client')
  async connectClient(@Body() config: any) {
    return this.db.connectClient(config);
  }

  // ---------------- METADATA DISCOVERY (FOR DROPDOWNS) ----------------

  @Post('server/databases')
  async getServerDatabases(@Body() config: any) {
    return this.db.getServerDatabases(config);
  }

  @Get('server/tables')
  async getServerTables() {
    return this.db.getPrimaryTableNames();
  }

  @Get('server/columns/:tableName')
  async getServerColumns(@Param('tableName') tableName: string) {
    // Change this to call your Service method
    return await this.db.getAllColumnsNames(tableName);
  }

  @Get('client/tables')
  getClientTables() {
    return this.db.getClientTableNames();
  }

  @Get('client/columns/:tableName')
  async getClientColumns(@Param('tableName') tableName: string) {
    // Change this to call your Service method
    return await this.db.getClientColumns(tableName);
  }

  // ---------------- CORE BANKING MIGRATION ENDPOINTS ----------------

  @Post('migrate/syspara')
  async migrateSYSPARA() {
    return this.db.migrateSYSPARA();
  }

  @Post('migrate/schemast')
  async migrateSCHEMAST() {
    return this.db.migrateSCHEMAST();
  }

  @Post('migrate/acmaster')
  async migrateACMASTER() {
    return this.db.migrateACMASTER();
  }

  @Post('migrate/idmaster')
  async migrateIDMASTER() {
    return this.db.migrateIDMASTER();
  }

  @Post('migrate/dpmaster')
  async migrateDPWithLinks() {
    return this.db.migrateDPWithLinks();
  }

  @Post('migrate/lnmaster')
  async migrateLNMASTER() {
    return this.db.migrateLNMASTER();
  }

  @Post('migrate/shmaster')
  async migrateSHMASTERWithChild() {
    return this.db.migrateSHMASTERWithChild();
  }

  @Post('migrate/pgmaster')
  async migratePGMASTERWithChildren() {
    return this.db.migratePGMASTERWithChildren();
  }

  // ---------------- SUPPLEMENTARY & MASTER TABLES ----------------

  // @Post('migrate/branchmaster')
  // async migrateBRANCHMASTER() {
  //   return await this.db.migrateBRANCHMASTER();
  // }

  @Post('migrate/castmaster')
  async migrateCASTMASTER() {
    return this.db.migrateCASTMASTER();
  }

  @Post('migrate/guaranterdetails')
  async migrateGUARANTERDETAILS() {
    return this.db.migrateGUARANTERDETAILS();
  }

  @Post('migrate/termmaster')
  async migrateTERMMASTER() {
    return this.db.migrateTERMMASTER();
  }

  @Post('migrate/sizewisebalance')
  async migrateSIZEWISEBALANCE() {
    return this.db.migrateSIZEWISEBALANCE();
  }

  @Post('migrate/advocatemaster')
  async migrateADVOCATEMASTER() {
    return this.db.migrateADVOCATEMASTER();
  }

  @Post('migrate/balacata')
  async migrateBALACATA() {
    return this.db.migrateBALACATA();
  }

  @Post('migrate/prefix')
  async migratePREFIX() {
    return this.db.migratePREFIX();
  }

  @Post('migrate/prioritysectormaster')
  async migratePRIORITYSECTORMASTER() {
    return this.db.migratePRIORITYSECTORMASTER();
  }

  @Post('migrate/recoveryclearkmaster')
  async migrateRECOVERYCLEARKMASTER() {
    return this.db.migrateRECOVERYCLEARKMASTER();
  }

  @Post('migrate/salarydevisionmaster')
  async migrateSALARYDIVISIONMASTER() {
    return this.db.migrateSALARYDIVISIONMASTER();
  }

  @Post('migrate/subsalarymaster')
  async migrateSUBSALARYMASTER() {
    return this.db.migrateSUBSALARYMASTER();
  }

  @Post('migrate/weakermaster')
  async migrateWEAKERMASTER() {
    return this.db.migrateWEAKERMASTER();
  }

  @Post('migrate/tdreciptmaster')
  async migrateTDRECEIPTMASTER() {
    return this.db.migrateTDRECEIPTMASTER();
  }

  @Post('migrate/authoritymaster')
  async migrateAUTHORITYMASTER() {
    return this.db.migrateAUTHORITYMASTER();
  }

  @Post('migrate/lockerrackmaster')
  async migrateLOCKERRACKMASTER() {
    return this.db.migrateLOCKERRACKMASTER();
  }

  @Post('migrate/lockersize')
  async migrateLOCKERSIZE() {
    return this.db.migrateLOCKERSIZE();
  }

  @Post('migrate/lockermaster')
  async migrateLOCKERMASTER() {
    return this.db.migrateLOCKERMASTER();
  }

  @Post('migrate/ownbranchmaster')
  async migrateOWNBRANCHMASTER() {
    return this.db.migrateOWNBRANCHMASTER();
  }

  @Post('migrate/ITEMCATEGORYMASTER')
  async migrateITEMCATEGORYMASTER() {
    return this.db.migrateITEMCATEGORYMASTER();
  }

  @Post('migrate/documentmaster')
  async migrateDOCUMENTMASTER() {
    return this.db.migrateDOCUMENTMASTER();
  }

  @Post('migrate/courtmaster')
  async migrateCOURTMASTER() {
    return this.db.migrateCOURTMASTER();
  }

  @Post('migrate/branchmaster')
  async migrateBRANCHMASTER() {
    return await this.db.migrateBRANCHMASTER();
  }

  @Post('migrate/categorymaster')
  async migrateCATEGORYMASTER() {
    return await this.db.migrateCATEGORYMASTER();
  }

  @Post('migrate/bankdeatails')
  async migrateBANKDETAILS() {
    return await this.db.migrateBANKDETAILS();
  }


  @Post('migrate/citymaster')
  async migrateCITYMASTER() {
    return await this.db.migrateCITYMASTER();
  }

  @Post('migrate/bankmaster')
  async migrateBANKMASTER() {
    return await this.db.migrateBANKMASTER();
  }

  @Post('migrate/depercategory')
  async migrateDEPRCATEGORY() {
    return await this.db.migrateDEPRCATEGORY();
  }


  @Post('migrate/directormaster')
  async migrateDIRECTORMASTER() {
    return await this.db.migrateDIRECTORMASTER();
  }

  @Post('migrate/healthmaster')
  async migrateHEALTHMASTER() {
    return await this.db.migrateHEALTHMASTER();
  }

  @Post('migrate/industrymaster')
  async migrateINDUSTRYMASTER() {
    return await this.db.migrateINDUSTRYMASTER();
  }

  @Post('migrate/insurancemaster')
  async migrateINSUARANCEMASTER() {
    return await this.db.migrateINSUARANCEMASTER();
  }

  @Post('migrate/intcategorymaster') // Make sure this matches the frontend call exactly
  async migrateIntCategory() {
    return await this.db.migrateINTCATEGORYMASTER();
  }

  @Post('migrate/itemmaster')
  async migrateITEMMASTER() {
    return await this.db.migrateITEMMASTER();
  }

  @Post('migrate/loanstagemaster')
  async migrateLOANSTAGEMASTER() {
    return await this.db.migrateLOANSTAGEMASTER();
  }

  @Post('migrate/narrationmaster')
  async migrateNARRATIONMASTER() {
    return await this.db.migrateNARRATIONMASTER();
  }

  @Post('migrate/occupationmaster')
  async migrateOCCUPATIONMASTER() {
    return await this.db.migrateOCCUPATIONMASTER();
  }

  @Post('migrate/operationmaster')
  async migrateOPERATIONMASTER() {
    return await this.db.migrateOPERATIONMASTER();
  }


  @Post('migrate/prioritymaster')
  async migratePRIORITYMASTER() {
    return await this.db.migratePRIORITYMASTER();
  }

  @Post('migrate/purposemaster')
  async migratePURPOSEMASTER() {
    return await this.db.migratePURPOSEMASTER();
  }

  @Post('migrate/reporttypemaster')
  async migrateREPORTTYPEMASTER() {
    return await this.db.migrateREPORTTYPEMASTER();
  }

  @Post('migrate/holidaysmaster')
  async migrateHOLIDAYSMASTER() {
    return await this.db.migrateHOLIDAYSMASTER();
  }

  @Post('migrate/traninputhead')
  async migrateTRANINPUTHEAD() {
    return await this.db.migrateTRANINPUTHEAD();
  }

  @Post('migrate/pgcommissionmaster')
  async migratePGCOMMISSIONMASTER() {
    return await this.db.migratePGCOMMISSIONMASTER();
  }

  @Post('migrate/stockstatement')
  async migrateSTOCKSTATEMENT() {
    return await this.db.migrateSTOCKSTATEMENT();
  }

  @Post('migrate/vehicle')
  async migrateVEHICLE() {
    return await this.db.migrateVEHICLE();
  }

  @Post('migrate/pledgestock')
  async migratePLEDGESTOCK() {
    return await this.db.migratePLEDGESTOCK();
  }

  @Post('migrate/plantmachinary')
  async migratePLANTMACHINARY() {
    return await this.db.migratePLANTMACHINARY();
  }

  @Post('migrate/owndeposit')
  async migrateOWNDEPOSIT() {
    return await this.db.migrateOWNDEPOSIT();
  }

  @Post('migrate/othersecurity')
  async migrateOTHERSECURITY() {
    return await this.db.migrateOTHERSECURITY();
  }


  @Post('migrate/marketshare')
  async migrateMARKETSHARE() {
    return this.db.migrateMARKETSHARE();
  }

  @Post('migrate/landbuilding')
  async migrateLANDBUILDING() {
    return this.db.migrateLANDBUILDING();
  }

  @Post('migrate/goldsilver')
  async migrateGOLDSILVER() {
    return this.db.migrateGOLDSILVER();
  }


  @Post('migrate/furniture')
  async migrateFURNITURE() {
    return this.db.migrateFURNITURE();
  }

  @Post('migrate/firepolicy')
  async migrateFIREPOLICY() {
    return this.db.migrateFIREPOLICY();
  }

  @Post('migrate/secinsurance')
  async migrateSECINSURANCE() {
    return this.db.migrateSECINSURANCE();
  }

  @Post('migrate/govtseculic')
  async migrateGOVTSECULIC() {
    return this.db.migrateGOVTSECULIC();
  }

  @Post('migrate/bookdebts')
  async migrateBOOKDEBTS() {
    return this.db.migrateBOOKDEBTS();
  }

  @Post('migrate/tdsformsubmit')
  async migrateTDSFORMSUBMIT() {
    return await this.db.migrateTDSFORMSUBMIT();
  }

  @Post('migrate/specialinstruction')
  async migrateSPECIALINSTRUCTION() {
    return await this.db.migrateSPECIALINSTRUCTION();
  }


  @Post('migrate/todtran')
  async migrateTODTRAN() {
    return await this.db.migrateTODTRAN();
  }

  //2:43
  @Post('migrate/standinstruction')
  async migrateSTANDINSTRUCTION() {
    return await this.db.migrateSTANDINSTRUCTION();
  }

  @Post('migrate/intinstruction')
  async migrateINTINSTRUCTION() {
    return await this.db.migrateINTINSTRUCTION();
  }

  @Post('migrate/intrateid')
  async migrateintrateTD() {
    return await this.db.migrateintrateTD();
  }

  @Post('migrate/intratetdmulti')
  async migrateINTRATETDMULTI() {
    return await this.db.migrateINTRATETDMULTI();
  }

  @Post('migrate/deprate')
  async migrateDEPRRATE() {
    return await this.db.migrateDEPRRATE();
  }


  @Post('migrate/intrateloan')
  async migrateINTRATELOAN() {
    return await this.db.migrateINTRATELOAN();
  }

  @Post('migrate/intratepatschems')
  async migrateINTRATEPATSCHEMES() {
    return await this.db.migrateINTRATEPATSCHEMES();
  }

  @Post('migrate/prematulessrate')
  async migratePREMATULESSRATE() {
    return await this.db.migratePREMATULESSRATE();
  }

  @Post('migrate/intratesbpg')
  async migrateINTRATESBPG() {
    return await this.db.migrateINTRATESBPG();
  }

  @Post('migrate/securitymaster')
  async migrateSECURITYMASTER() {
    return await this.db.migrateSECURITYMASTER();
  }


  @Post('migrate/tdsrate')
  async migrateTDSRATE() {
    return await this.db.migrateTDSRATE();
  }

  @Post('migrate/npamaster')
  async migrateNPAMASTER() {
    return await this.db.migrateNPAMASTER();
  }

  @Post('migrate/deadstockheader')
  async migrateDEADSTOCKHEADER() {
    return await this.db.migrateDEADSTOCKHEADER();
  }

  @Post('migrate/depoclosetransac')
  async migrateDEPOCLOSETRANSAC() {
    return await this.db.migrateDEPOCLOSETRANSAC();
  }



  // ---------------- UI DISCOVERY ENDPOINT ----------------

  @Get('migratable-tables')
  getMigratableTables() {
    return [
      'SYSPARA', 'SCHEMAST', 'ACMASTER', 'IDMASTER', 'DPMASTER', 'LNMASTER',
      'SHMASTER', 'TERMMASTER', 'BALACATA', 'ADVOCATEMASTER', 'PREFIX',
      'PRIORITYSECTORMASTER', 'RECOVERYCLEARKMASTER', 'SALARYDIVISIONMASTER',
      'SUBSALARYMASTER', 'WEAKERMASTER', 'TDRECEIPTMASTER', 'AUTHORITYMASTER',
      'LOCKERRACKMASTER', 'LOCKERSIZE', 'LOCKERMASTER', 'OWNBRANCHMASTER', 'DOCUMENTMASTER',
      'ITEMCATEGORYMASTER', 'BANKMASTER', 'CITYMASTER', 'BANKDETAILS', 'CATEGORYMASTER',
      'BRANCHMASTER', 'COURTMASTER', 'PGCOMMISSIONMASTER', 'TRANINPUTHEAD', 'HOLIDAYSMASTER',
      'REPORTTYPEMASTER', 'DEPRCATEGORY', 'DIRECTORMASTER', 'HEALTHMASTER', 'INDUSTRYMASTER',
      'INSUARANCEMASTER', 'INTCATEGORYMASTER', 'ITEMMASTER', 'LOANSTAGEMASTER', 'NARRATIONMASTER', 'OCCUPATIONMASTER',
      'OPERATIONMASTER', 'PRIORITYMASTER', 'PURPOSEMASTER', 'REPORTTYPEMASTER', 'STOCKSTATEMENT',
      'VEHICLE', 'PLEDGESTOCK', 'PLANTMACHINARY', 'OWNDEPOSIT', 'OTHERSECURITY', 'MARKETSHARE', 'LANDBUILDING',
      'GOLDSILVER', 'FURNITURE', 'FIREPOLICY', 'SECINSURANCE', 'GUARANTERDETAILS', 'TDSFORMSUBMIT', 'SPECIALINSTRUCTION',
      'GOVTSECULIC', 'BOOKDEBTS', 'PGMASTER', 'CASTMASTER', 'SIZEWISEBALANCE', 'TODTRAN', 'NPAMASTER', 'TDSRATE',
      'SECURITYMASTER', 'INTRATESBPG', 'PREMATULESSRATE', 'INTRATEPATSCHEMES', 'INTRATELOAN', 'DEPRRATE', 'INTRATETDMULTI',
      'intrateTD', 'INTINSTRUCTION', 'STANDINSTRUCTION', 'DEADSTOCKHEADER', 'DEPOCLOSETRANSAC'
    ];
  }
}
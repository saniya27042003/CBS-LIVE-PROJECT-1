/* eslint-disable @typescript-eslint/no-unsafe-argument */
import unidev from 'unidev';
import Sanscript from '@indic-transliteration/sanscript';
import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { IDMASTER } from '../entity/customer-id.entity';
import { CUSTOMERADDRESS } from '../entity/customer-address.entity';
import { OCCUPATIONMASTER } from '../entity/occupation-master.entity';
import { CASTMASTER } from '../entity/cast-master.entity';
import { RISKCATEGORYMASTER } from '../entity/risk-category.entity';
import { SCHEMAST } from '../entity/schemeParameters.entity'; // Adjust paths as needed
import { ADVOCATEMASTER } from '../entity/advocate-master.entity';
import { BALACATA } from '../entity/minimum-balance-master.entity';
import moment from 'moment';
// import { unidev } from 'unidev';
import { ManualSymbolMapper } from '../legacy-font/manual-symbol-maps';
// import Sanscript from '@indic-transliteration/sanscript';
import { DataSource } from 'typeorm';
import { QueryRunner } from 'typeorm';
import { CATEGORYMASTER } from '../entity/category-master.entity';
import { PREFIX } from '../entity/prefix-master.entity';
import { OWNBRANCHMASTER } from '../entity/own-branch-master.entity';
import { LOCKERMASTER } from '../entity/locker-rackwise-master.entity';
import { LOCKERSIZE } from '../entity/locker-size-master.entity';
import { LOCKERRACKMASTER } from '../entity/locker-rack-master.entity';
import { AUTHORITYMASTER } from '../entity/authority-master.entity';
import { TDRECEIPTMASTER } from '../entity/td-receipt-type.entity';
import { WEAKERMASTER } from '../entity/weaker-master.entity';
import { SUBSALARYMASTER } from '../entity/sub-salary-division-master.entity';
import { SALARYDIVISIONMASTER } from '../entity/salary-division-master.entity';
import { RECOVERYCLEARKMASTER } from '../entity/recovery-cleark-master.entity';
import { PRIORITYSECTORMASTER } from '../entity/priority-sector-master.entity';
import { ITEMCATEGORYMASTER } from '../entity/item-category-master.entity';
import { DOCUMENTMASTER } from '../entity/document-master.entity';
import { BANKMASTER } from '../entity/bank-master.entity';
import { CITYMASTER } from '../entity/city-master.entity';
import { BANKDETAILS } from '../entity/BANKDETAILS.entity';
import { BRANCHMASTER } from '../entity/clearing-branch-master.entity';
import { COURTMASTER } from '../entity/court-master.entity';
import { INSUARANCEMASTER } from '../entity/insurance-master.entity';
import { INTCATEGORYMASTER } from '../entity/interest-category-master.entity';
import { INDUSTRYMASTER } from '../entity/industry-master.entity';
import { HEALTHMASTER } from '../entity/health-master.entity';
import { DEPRCATEGORY } from '../entity/depriciation-category-master.entity';
import { PLANTMACHINARY } from '../entity/plant-and-machinery.entity';
import { TODTRAN } from '../entity/over-draft.entity';
import { SPECIALINSTRUCTION } from '../entity/special-instruction.entity';
import { NPACLASSIFICATION } from '../entity/npa-class.entity';
import { NPAMASTER } from '../entity/npa-classification.entity';
import { TDSRATE } from '../entity/tds-interest-rate.entity';
import { INTINSTRUCTION } from '../entity/interest-instruction.entity';
import { INTRATETD } from '../entity/interest-rate-for-term-deposit.entity';
import { STANDINSTRUCTION } from '../entity/standing-instruction.entity';
import { NOMINEELINK } from '../entity/nominee.entity';
import { ATTERONEYLINK } from '../entity/atteroneylink.entity';
import { JointAcLink } from '../entity/joint-account.entity';
import { PGMASTER } from '../entity/pgmaster.entity';
const unidev = require('unidev');
// import * as oracledb from 'oracledb';
// import { LNMASTER } from '../entity/term-loan-master.entity';
// import { SECURITYDETAILS } from '../entity/security.entity';
// import { GUARANTERDETAILS } from '../entity/guarantor.entity';
// import { COBORROWER } from '../entity/coborrower.entity';
// import { LNACINTRATE } from '../entity/lnacintrate.entity';

interface BranchRecord {
  id: number;
  CODE: string | number;
}

interface OracleQueryResult {
  rows: any[][];
  metaData: { name: string }[];
}

interface StockStatementOracleRow {
  AC_NO: number;
  AC_ACNOTYPE: string;
  AC_TYPE: number;        // Raw column from STOCKSTATEMENT
  JOIN_ACTYPE: number;    // Joined column from SCHEMAST
  SECU_CODE: string;
  SUBMISSION_DATE: any;   // Use any here to avoid "Unsafe call" when passing to moment()
  STATEMENT_DATE: any;    // Oracle results are often complex objects
  RAW_MATERIAL: number;
  WORK_PROGRESS: number;
  FINISHED_GOODS: number;
  RAW_MARGIN: number;
  WORK_MARGIN: number;
  FINISHED_MARGIN: number;
  REMARK: any;            // Use any to prevent transformValue safety warnings
  SECURITY_TYPE: string;
}
interface VehicleOracleRow {
  AC_NO: number;
  AC_TYPE: number;
  AC_ACNOTYPE: string;
  SUBMISSION_DATE: any;
  SECU_CODE: string;
  MARGIN: number;
  REMARK: any;
  SECURITY_TYPE: string;
  RTO_REG_DATE: any;
  AQUISITION_DATE: any;
  VEHICLE_MAKE: any;
  MANUFACTURE_YEAR: string;
  VEHICLE_NO: string;
  CHASSIS_NO: string;
  NEW_VEHICLE: string;
  NEW_EQUIPEMENT: string;
  SUPPLIER_NAME: any;
  PURCHASE_PRICE: number;
  REF_ID: string;
  ACTYPE: number;
}


interface PledgeStockOracleRow {
  AC_NO: number;
  AC_TYPE: number;
  AC_ACNOTYPE: string;
  SECU_CODE: string;
  SUBMISSION_DATE: any;
  STATEMENT_DATE: any;
  QUANTITY: number;
  RATE: number;
  TOTAL_VALUE: number;
  MARGIN: number;
  DRAWING_POWER: number;
  REMARK: any;
  SECURITY_TYPE: string;
  GODOWN_ADDRESS: string;
  ITEM_DESCRIPTION: string;
  UNIT: string;
}

export interface PlantMachinaryOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  AQUISITION_DATE: any;
  MARGIN: number | string;
  PURCHASE_PRICE: number | string;
  REMARK: any;
  SUPPLIER_NAME: any;
  SECURITY_TYPE: string;
  MANUFACTURE_YEAR: string;
  NEW_VEHICLE: string;
  NEW_EQUIPEMENT: string;
  REF_ID: string;
}

export interface OwnDepositOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  STATEMENT_DATE: any; // Used in Oracle but missing in Entity
  MARGIN: number | string;
  TOTAL_VALUE: number | string; // Used in Oracle but missing in Entity
  RECEIPT_NO: string;
  LIEN_MARK: string; // Used in Oracle but missing in Entity
  REMARK: any;
  SECURITY_TYPE: string; // Used in Oracle but missing in Entity
}

export interface OtherSecurityOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  REMARK: any;
  SECURITY_TYPE: string;
  PARTICULARS: string;
  VALUATION_AMT: number | string;
  MARGIN: number | string;
}


export interface MarketShareOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  REMARK: any;
  SECURITY_TYPE: string;
  NO_OF_SHARES: number | string;
  FACE_VALUE: number | string;
  MARKET_VALUE: number | string;
  COMPANY_NAME: string;
  CERTIFICATE_NO: string;
  MARGIN: number | string;
}


export interface LandBuildingOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  AQUISITION_DATE: any;
  VALUATION_DATE: any;
  AREA: number | string;
  UNIT_AREA: string;
  VALUE: number | string;
  LOCATION: string;
  MARGIN: number | string;
  ADDRESS: string;
  REMARK: any;
  SECURITY_TYPE: string;
}

export interface GoldSilverOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  VALUATION_DATE: any;
  GROSS_WEIGHT: number | string;
  NET_WEIGHT: number | string;
  PURITY: string;
  QUANTITY: number | string;
  VALUATION_AMT: number | string;
  MARGIN: number | string;
  REMARK: any;
  SECURITY_TYPE: string;
  ITEM_DESCRIPTION: string;
}

export interface FurnitureOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  AQUISITION_DATE: any;
  PURCHASE_PRICE: number | string;
  MARGIN: number | string;
  ITEM_DESCRIPTION: string;
  QUANTITY: number | string;
  REMARK: any;
  SECURITY_TYPE: string;
  VALUATION_AMT: number | string;
}

export interface FirePolicyOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  POLICY_NO: string;
  INSURANCE_COMPANY: string;
  POLICY_AMT: number | string;
  EXPIRY_DATE: any;
  PREMIUM_AMT: number | string;
  REMARK: any;
  SECURITY_TYPE: string;
}

export interface SecInsuranceOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  POLICY_NO: string;
  INSURANCE_COMPANY: string;
  POLICY_AMT: number | string;
  EXPIRY_DATE: any;
  PREMIUM_AMT: number | string;
  REMARK: any;
  SECURITY_TYPE: string;
}

export interface GovtSecuLicOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  POLICY_NO: string;
  CERTIFICATE_NO: string;
  MATURITY_DATE: any;
  FACE_VALUE: number | string;
  SURRENDER_VALUE: number | string;
  MARGIN: number | string;
  REMARK: any;
  SECURITY_TYPE: string;
  ISSUING_AUTHORITY: string;
}

export interface BookDebtsOracleRow {
  AC_NO: number | string;
  AC_ACNOTYPE: string;
  AC_TYPE: number;
  SECU_CODE: string | number;
  SUBMISSION_DATE: any;
  VALUATION_DATE: any;
  TOTAL_BOOK_DEBTS: number | string;
  UPTO_90_DAYS: number | string;
  OVER_90_DAYS: number | string;
  ELIGIBLE_DEBTS: number | string;
  MARGIN: number | string;
  REMARK: any;
  SECURITY_TYPE: string;
  PARTY_NAME: string;
}

export interface ITdsFormSubmit {
  AC_NO: string | number;
  AC_ACNOTYPE: string;
  FIN_YEAR: string;
  FORM_TYPE: string;
  SUB_DATE: Date | string | null;
  REMARKS: string | null;
  DPMasterID?: number | null;
  BRANCH_CODE?: number;
  SUBMISSION_DATE?: string | null;
  status?: string;
}

export interface ISpecialInstruction {
  AC_NO: string | number;
  AC_ACNOTYPE: string;
  INSTRUCTION: string | null;
  // Oracle source fields
  INST_DATE?: Date | string | null;
  DATE_IN?: Date | string | null;
  // Postgres target fields (based on Image 1)
  INSTRUCTION_NO?: number;
  DETAILS?: string;
  TRAN_ACNO?: string;
  TRAN_ACTYPE?: number;
}

@Injectable()
export class DatabaseMappingService {
  [x: string]: any;
  private readonly logger = new Logger(DatabaseMappingService.name);
  limit: number = 1000;
  offset: number = 0;
  count: number = 0;
  flag: number = 0;

  private clientConn!: {
    execute: (
      query: string,
      params?: any[]
    ) => Promise<{
      rows: any[];
      metaData: { name: string }[];
    }>;
  };

  private serverDB!: DataSource;

  constructor(private readonly dbService: DatabaseService) { }

  // store connections after controller call
  async connectServer(config: any) {
    this.serverDB = await this.dbService.getServerDataSource(config);
    return { success: true };
  }

  async connectClient(config: any) {
    this.clientConn = await this.dbService.getClientConnection(config);
    return { success: true };
  }

  private convertYogeshToEnglish(text: any) {

    if (!text) return null;

    const font = 'DVBW-TTYogeshEn';

    try {

      // 1️⃣ Yogesh → Unicode Marathi
      let marathi = unidev(String(text), 'hindi', font);

      // 2️⃣ Fix special Yogesh symbols
      if (marathi.includes('×')) {
        marathi = marathi.replace(/×(.)/g, '$1ि');
      }

      if (marathi.includes('Ø')) {
        marathi = marathi.replace(/Ø(.)/g, '$1िं');
      }

      if (marathi.includes('Ô')) {

        marathi = marathi.replace(
          /([क-ह])([ािीुूृेैोौंॅॉ]*)Ô/g,
          'र्$1$2'
        );

        marathi = marathi.replace(/Ô/g, 'र्');
      }

      // 3️⃣ Normalize manual symbol mappings
      marathi = ManualSymbolMapper.normalize(marathi);

      // 4️⃣ Marathi → IAST transliteration
      let english = Sanscript.t(marathi, 'devanagari', 'iast');

      // 5️⃣ Normalize to readable English
      english = english
        .toLowerCase()
        .replace(/ā/g, 'a')
        .replace(/ī/g, 'i')
        .replace(/ū/g, 'u')
        .replace(/ṛ|ṝ/g, 'r')
        .replace(/ḷ|ḹ/g, 'l')
        .replace(/c/g, 'ch')
        .replace(/ṭ/g, 't')
        .replace(/ḍ/g, 'd')
        .replace(/ś|ṣ/g, 'sh')
        .replace(/ṅ|ñ|ṇ/g, 'n')
        .replace(/ḥ/g, 'h')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/aa+/g, 'a')
        .replace(/ii+/g, 'i')
        .replace(/uu+/g, 'u')
        .replace(/a$/i, '')
        .replace(/\b\w/g, c => c.toUpperCase());

      return english.trim();

    } catch {
      return text;
    }
  }


  private resolveAnusvara(iast: string): string {
    return iast
      .replace(/ṃ(?=[pbm])/g, 'm').replace(/ṃ(?=[kg])/g, 'n').replace(/ṃ(?=[tdn])/g, 'n')
      .replace(/ṃ(?=[cj])/g, 'n').replace(/ṃ(?=[ṭḍṇ])/g, 'n').replace(/ṃ/g, 'm');
  }

  private safe(value: any): any {
    if (value === undefined || value === null || value === '') {
      return null;
    }
    return value;
  }

  private transformValue(raw: any): any {
    if (raw === null || raw === undefined || raw === '') return null;

    const strRaw = String(raw);

    // 1. Detect mojibake / legacy corruption
    const looksCorrupted =
      /�|Ã|Â|¤|§|ª|©️/.test(strRaw) ||
      /[A-Za-z]�[A-Za-z]/.test(strRaw);

    if (!looksCorrupted && /^[\x20-\x7E\s]*$/.test(strRaw)) {
      return strRaw; // safe English
    }

    // 2. PURE Unicode Devanagari → leave untouched
    const isPureUnicodeDevanagari =
      /[\u0900-\u097F]/.test(strRaw) &&
      !/[A-Za-z]/.test(strRaw);

    if (isPureUnicodeDevanagari) return strRaw;

    // 3. Legacy font detection
    const looksLegacy = /[^\u0900-\u097F]/.test(strRaw);
    if (!looksLegacy) return strRaw;

    try {
      const unidevFn = unidev as unknown as (a: string, b: string, c: string) => string;
      let marathi = unidevFn(strRaw, 'hindi', 'DVBW-TTYogeshEn');
      marathi = ManualSymbolMapper.normalize(marathi);

      let english = Sanscript.t(marathi, 'devanagari', 'iast');
      english = this.resolveAnusvara(english);

      english = english
        .toLowerCase()
        .replace(/ā/g, 'a')
        .replace(/ī/g, 'i')
        .replace(/ū/g, 'u')
        .replace(/ṛ|ṝ/g, 'r')
        .replace(/ḷ|ḹ/g, 'l')
        .replace(/c/g, 'ch')
        .replace(/ṭ/g, 't')
        .replace(/ḍ/g, 'd')
        .replace(/ś|ṣ/g, 'sh')
        .replace(/ṅ|ñ|ṇ/g, 'n')
        .replace(/ḥ/g, 'h')
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/aa+/g, 'a')
        .replace(/ii+/g, 'i')
        .replace(/uu+/g, 'u')
        .replace(/a$/i, '')
        .replace(/\b([a-z]+)(dr|tr|kr|gr)\b/gi, '$1$2a')
        .replace(/\b\w/g, c => c.toUpperCase());

      return english.trim() === '' ? strRaw : english;
    } catch {
      return strRaw;
    }
  }


  // ---------------- IDMASTER MIGRATION ----------------
  async migrateIDMASTER() {
    if (!this.clientConn) throw new Error('Client DB not connected');
    if (!this.serverDB) throw new Error('Server DB not connected');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const occupationData = await queryRunner.manager.find(OCCUPATIONMASTER);
      const castData = await queryRunner.manager.find(CASTMASTER);
      const riskData = await queryRunner.manager.find(RISKCATEGORYMASTER);



      const result = await this.clientConn.execute(`
        SELECT IDMASTER.*, 
               OCCUPATIONMASTER.CODE AS OCCUPATION,
               CASTMASTER.CODE AS CASTMASTER,
               RISKCATEGORYMASTER.CODE AS RISKCATEGORYMASTER
        FROM IDMASTER
        LEFT JOIN OCCUPATIONMASTER 
          ON IDMASTER.AC_OCODE = OCCUPATIONMASTER.CODE
        LEFT JOIN CASTMASTER 
          ON IDMASTER.AC_CAST = CASTMASTER.CODE
        LEFT JOIN RISKCATEGORYMASTER 
          ON IDMASTER.AC_RISKCATG = RISKCATEGORYMASTER.CODE
        ORDER BY IDMASTER.AC_NO
      `);

      const rows = this.convertOracleRows(result as {
        rows: any[];
        metaData: { name: string }[];
      });

      // --- DYNAMIC BRANCH LOOKUP ---
      // Instead of hardcoding 101, we fetch all branches currently in your Postgres table
      const branches = await queryRunner.manager.query(`SELECT id, "CODE" FROM ownbranchmaster`);
      const branchMap = new Map(branches.map(b => [Number(b.CODE), b.id]));

      this.logger.log(`Mapped Branches from PG: ${JSON.stringify(Object.fromEntries(branchMap))}`);

      // Check if we have at least one branch to avoid total failure
      if (branchMap.size === 0) {
        throw new Error('No branches found in ownbranchmaster. Please insert branches first.');
      }


      for (const ele of rows) {
        const newObj = new IDMASTER();
        const namearr = String(ele.AC_NAME || '').trim().split(/\s+/);

        let marathiTitle = '';

        if (ele.AC_TITLE) {
          const font = 'DVBW-TTYogeshEn';

          marathiTitle = unidev(String(ele.AC_TITLE), 'hindi', font);

          if (font === 'DVBW-TTYogeshEn') {
            if (marathiTitle.includes('×')) {
              marathiTitle = marathiTitle.replace(/×(.)/g, '$1ि');
            }

            if (marathiTitle.includes('Ø')) {
              marathiTitle = marathiTitle.replace(/Ø(.)/g, '$1िं');
            }

            if (marathiTitle.includes('Ô')) {
              marathiTitle = marathiTitle.replace(
                /([क-ह])([ािीुूृेैोौंॅॉ]*)Ô/g,
                'र्$1$2'
              );

              marathiTitle = marathiTitle.replace(/Ô/g, 'र्');
            }
          }
        }

        newObj['AC_TITLE_REG'] = marathiTitle ?? null;

        let marathiName = '';

        if (ele.AC_NAME) {
          const font = 'DVBW-TTYogeshEn';

          marathiName = unidev(String(ele.AC_NAME), 'hindi', font);

          if (font === 'DVBW-TTYogeshEn') {
            if (marathiName.includes('×')) {
              marathiName = marathiName.replace(/×(.)/g, '$1ि');
            }

            if (marathiName.includes('Ø')) {
              marathiName = marathiName.replace(/Ø(.)/g, '$1िं');
            }

            if (marathiName.includes('Ô')) {
              marathiName = marathiName.replace(
                /([क-ह])([ािीुूृेैोौंॅॉ]*)Ô/g,
                'र्$1$2'
              );

              marathiName = marathiName.replace(/Ô/g, 'र्');
            }
          }
        }


        const namearrReg = marathiName
          ? marathiName.split(' ')
          : [];

        newObj['L_NAME_REG'] = namearrReg[0] ?? null;
        newObj['F_NAME_REG'] = namearrReg[1] ?? null;
        newObj['M_NAME_REG'] = namearrReg[2] ?? null;

        newObj['AC_NAME_REG'] = marathiName || '';


        newObj['AC_MEMBNO'] =
          ele.AC_MEMBNO === 0 || ele.AC_MEMBNO == null
            ? 0
            : Number(ele.AC_MEMBNO) + 100000;     // Name Splitting logic
        newObj['L_NAME'] = namearr[0] ? this.transformValue(namearr[0]) : null;
        newObj['F_NAME'] = namearr[1] ? this.transformValue(namearr[1]) : null;
        newObj['M_NAME'] = namearr[2] ? this.transformValue(namearr[2]) : null;


        // --- Cast lookup ---
        let castID: any = null;
        if (ele.CASTMASTER != null) {
          let CASTdATA = await this.clientConn.execute(`select CODE from CASTMASTER where CODE=${ele.CASTMASTER}`)
          let occData = await this.convertOracleRows(CASTdATA);
          for (let eleme of occData) {
            castID = (castData.find(castData => castData['CODE'] == eleme.CODE))
          }

        }

        // --- Risk category lookup ---
        let RISKID: any = null;
        if (ele.RISKCATEGORYMASTER != null) {
          let CASTdATA = await this.clientConn.execute(`select NAME from RISKCATEGORYMASTER where CODE=${ele.RISKCATEGORYMASTER}`)
          let occData = await this.convertOracleRows(CASTdATA);
          for (let eleme of occData) {
            RISKID = (riskData.find(riskCategoryData => riskCategoryData['CODE'] == eleme.CODE))
          }
        }

        // --- Membership type lookup ---
        let mem_TYPE: any[] = [];
        if (ele.AC_MEMBTYPE != null) {
          const memTYPE = await this.clientConn.execute(
            `SELECT S_APPL FROM schemast WHERE S_APPL = ${ele.AC_MEMBTYPE}`
          );
          mem_TYPE = this.convertOracleRows(memTYPE);
        }

        // --- Membership number normalization ---
        const AC_MEMBNO = ele.AC_MEMBNO == 0 ? null : Number(ele.AC_MEMBNO) + 100000;

        newObj.AC_NO = Number(ele.AC_NO || 0) + 100000;
        //newObj['AC_NO'] = ele.AC_NO;
        newObj.AC_MEMBTYPE = mem_TYPE && mem_TYPE.length > 0 ? mem_TYPE[0].S_APPL : null;
        newObj.AC_MEMBNO = ele.AC_MEMBNO;
        newObj.AC_TITLE = this.transformValue(ele.AC_TITLE);
        newObj.AC_NAME = this.transformValue(ele.AC_NAME);
        newObj['L_NAME'] = this.transformValue(namearr[0] || null);
        newObj['F_NAME'] = this.transformValue(namearr[1] || null);
        newObj['M_NAME'] = this.transformValue(namearr[2] || null);
        newObj['AC_ADHARNO'] = ele.AC_ADHARNO;
        newObj['AC_BIRTH_DT'] = ele.AC_BIRTH_DT
          ? moment(ele.AC_BIRTH_DT as unknown as Date).format('DD/MM/YYYY')
          : null;

        newObj['AC_PANNO'] = ele.AC_PANNO;
        newObj['AC_MOBILENO'] = ele.AC_MOBILENO;
        newObj['AC_PHONE_RES'] = ele.AC_PHONE_RES;
        newObj['AC_PHONE_OFFICE'] = ele.AC_PHONE_OFFICE;
        newObj['AC_EMAILID'] = ele.AC_EMAIL;
        newObj['TDSDOCUMNET'] = '0';
        newObj['TDS_REQUIRED'] = ele.TDS_REQUIRED ? '1' : '0';
        newObj['SMS_REQUIRED'] = ele.SMS_REQUIRED ? '1' : '0';
        newObj['IS_KYC_RECEIVED'] = ele.IS_KYC_RECEIVED ? '1' : '0';

        const occ = occupationData.find(x => x.CODE == ele.OCCUPATION);
        newObj['AC_OCODE'] = occ ? occ.id : null;

        // const cast = castData.find(x => x.CODE == ele.CASTMASTER);
        // newObj['AC_CAST'] = cast ? cast.id : null;

        // const risk = riskData.find(x => x.CODE == ele.RISKCATEGORYMASTER);
        // newObj['AC_RISKCATG'] = risk ? risk.id : null;
        newObj['AC_RISKCATG'] = RISKID == null ? null : RISKID.id;
        newObj['AC_CAST'] = castID == null ? null : castID.id;


        newObj['ORA_AC_NO'] = ele.AC_NO;

        // --- DYNAMIC BRANCH ASSIGNMENT ---
        const oracleBranchCode = Number(ele.AC_BRANCH || 1);
        // Try to find match, otherwise fallback to the first branch ID in the map
        const postgresBranchId = (branchMap.get(oracleBranchCode) || branchMap.values().next().value) as number;
        newObj['ORA_BRANCH'] = oracleBranchCode;
        newObj['BRANCH_CODE'] = postgresBranchId;

        const saved = await queryRunner.manager.save(IDMASTER, newObj);

        const address = new CUSTOMERADDRESS();
        address['idmasterID'] = saved.id;
        address['AC_HONO'] = ele.AC_HONO == 0 || ele.AC_HONO == undefined ? null : ele.AC_HONO;
        address['AC_WARD'] = ele.AC_WARD == undefined ? null : ele.AC_WARD;
        address['AC_GALLI'] = this.safe(ele.AC_ADDR1);
        address['AC_AREA'] = this.safe(ele.AC_ADDR2);
        address['AC_ADDR'] = this.safe(ele.AC_ADDR3);
        address['AC_PIN'] = ele.AC_PIN || null;
        address['AC_ADDFLAG'] = true;
        address['AC_ADDTYPE'] = 'P';
        address['AC_CTCODE'] = ele.AC_CTCODE == 9999 ? 10 : ele.AC_CTCODE;


        await queryRunner.manager.save(CUSTOMERADDRESS, address);
      }

      await queryRunner.commitTransaction();
      this.logger.log('IDMASTER migration completed successfully');

      return { success: true };

    } catch (err) {
      if (queryRunner.isTransactionActive) {
        await queryRunner.rollbackTransaction();
      }
      this.logger.error('IDMASTER Migration failed', err);
      throw err;
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  // helper
  private convertOracleRows(result: {
    rows: any[];
    metaData: { name: string }[];
  }) {
    return result.rows.map((row: any[]) => {
      const obj: Record<string, any> = {};
      result.metaData.forEach((m, i) => {
        obj[m.name] = row[i];
      });
      return obj;
    });
  }


  private generateBankAcNo(
    bankCode: number,
    branchCode: number,
    schemeCode: number,
    acNo: number
  ): string {

    const bank = String(bankCode).padStart(3, '0');
    const branch = String(branchCode).padStart(3, '0');
    const scheme = String(schemeCode).padStart(3, '0');
    const account = String(acNo).padStart(6, '0');

    return `${bank}${branch}${scheme}${account}`;
  }



  //=================================DPMASTER TABLE INSERTION =============================================
  async migrateDPWithLinks() {
    if (!this.clientConn || !this.serverDB) throw new Error('Databases not connected');

    this.logger.log('Starting Final Sync: Migrating all rows with dynamic branch and scheme logic...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    // 1. PRE-FETCH existing parent IDs from Postgres to handle existing records
    const existingDpMap = new Map<string, number>();
    const currentRecords = await queryRunner.manager.query(
      `SELECT id, "AC_ACNOTYPE", "AC_NO" FROM dpmaster`
    );
    currentRecords.forEach(r => {
      // Key format: TYPE-ORIGNAL_NO (subtracting the 100000 offset to match Oracle)
      const key = `${String(r.AC_ACNOTYPE).trim()}-${Number(r.AC_NO) - 100000}`;
      existingDpMap.set(key, r.id);
    });
    this.logger.log(`Pre-loaded ${existingDpMap.size} existing account IDs for child linking.`);

    try {
      // 2. FETCH DATA FROM ORACLE
      const [dpResult, nomineeResult, attorneyResult, jointResult] = await Promise.all([
        this.clientConn.execute(`SELECT * FROM DPMASTER`),
        this.clientConn.execute(`SELECT * FROM NOMINEELINK`),
        this.clientConn.execute(`SELECT * FROM ATTERONEYLINK`),
        this.clientConn.execute(`SELECT * FROM JOINTACLINK`)
      ]);

      const dpRows = this.convertOracleRows(dpResult as any);
      const nomineeRows = this.convertOracleRows(nomineeResult as any);
      const attorneyRows = this.convertOracleRows(attorneyResult as any);
      const jointRows = this.convertOracleRows(jointResult as any);

      // 3. LOAD SYSTEM CONFIG & LOOKUP MAPS
      const syspara = await queryRunner.manager.query(`SELECT "BANK_CODE", "BRANCH_CODE" FROM syspara LIMIT 1`);
      const bankCode = String(syspara[0]?.BANK_CODE || '0').padStart(3, '0');

      const [branches, schemas, categories, balCats, operations, intCats] = await Promise.all([
        queryRunner.manager.query(`SELECT id, "CODE" FROM ownbranchmaster`),
        queryRunner.manager.query(`SELECT id, "S_APPL" FROM schemast`),
        queryRunner.manager.query(`SELECT id, "CODE" FROM categorymaster`),
        queryRunner.manager.query(`SELECT id, "BC_CODE" FROM balacata`),
        queryRunner.manager.query(`SELECT id, "CODE" FROM operationmaster`),
        queryRunner.manager.query(`SELECT id, "CODE" FROM intcategorymaster`)
      ]);

      const branchMap = new Map(branches.map(b => [Number(b.CODE), b.id]));
      const schemaIdMap = new Map(schemas.map(s => [Number(s.S_APPL), s.id]));
      const categoryMap = new Map(categories.map(c => [Number(c.CODE), c.id]));
      const balCatMap = new Map(balCats.map(b => [String(b.BC_CODE).trim(), b.id]));
      const operationMap = new Map(operations.map(op => [String(op.CODE).trim(), op.id]));
      const intCategoryMap = new Map(intCats.map(cat => [String(cat.CODE).trim(), cat.id]));

      const acToIdMap = new Map<string, number>();
      await queryRunner.startTransaction();

      try {
        for (const ele of dpRows) {
          const key = `${String(ele.AC_ACNOTYPE).trim()}-${ele.AC_NO}`;

          // Logical Mappings
          const targetInternalId = schemaIdMap.get(Number(ele.AC_TYPE)) || 1;
          const rowBranchCodeRaw = ele.INVEST_BRANCH || ele.AC_INTROBRANCH || syspara[0]?.BRANCH_CODE || 1;
          const branchInternalId = branchMap.get(Number(rowBranchCodeRaw)) || branches[0].id;

          const offsetAcNoInt = 100000 + Number(ele.AC_NO);
          const bankAcNo15 = `${bankCode}${String(rowBranchCodeRaw).padStart(3, '0')}${String(ele.AC_TYPE).slice(0, 3)}${String(offsetAcNoInt).padStart(6, '0')}`;

          // Prepare the massive object with ALL your required columns
          const dpData: any = {
            BANKACNO: bankAcNo15,
            AC_NO: offsetAcNoInt,
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_TYPE: targetInternalId,
            BRANCH_CODE: branchInternalId,
            AC_NAME: this.transformValue(ele.AC_NAME),
            AC_CATG: categoryMap.get(Number(ele.AC_CATG)) || null,
            AC_CUSTID: ele.AC_CUSTID,
            AC_BALCATG: balCatMap.get(String(ele.AC_BALCATG).trim()) || null,
            AC_OPR_CODE: operationMap.get(String(ele.AC_OPR_CODE).trim()) || null,
            AC_INTCATA: intCategoryMap.get(String(ele.AC_INTCATA).trim()) || null,
            AC_INTROBRANCH: branchMap.get(Number(ele.AC_INTROBRANCH)) || null,
            AC_EXPDT: ele.AC_EXPDT ? moment(ele.AC_EXPDT).format('DD/MM/YYYY') : null,
            AC_INTROID: ele.AC_INTROID ? Number(ele.AC_INTROID) : null,
            AC_INTRACNO: (ele.AC_INTRACNO && Number(ele.AC_INTRACNO) > 0) ? String(Number(ele.AC_INTRACNO) + 100000) : null,
            AC_MEMBTYPE: ele.AC_MEMBTYPE,
            AC_MEMBNO: ele.AC_MEMBNO ? Number(ele.AC_MEMBNO) + 100000 : null,
            AC_MONTHS: ele.AC_MONTHS ? Number(ele.AC_MONTHS) : 0,
            AC_DAYS: ele.AC_DAYS ? Number(ele.AC_DAYS) : 0,
            AC_CLOSEDT: ele.AC_CLOSEDT ? moment(ele.AC_CLOSEDT).format('DD/MM/YYYY') : null,
            AC_PRODUCT: ele.AC_PRODUCT,
            AC_LINTEDT: ele.AC_LINTEDT ? moment(ele.AC_LINTEDT).format('DD/MM/YYYY') : null,
            AC_BALDATE: ele.AC_BALDATE ? moment(ele.AC_BALDATE).format('DD/MM/YYYY') : null,
            OP_CR_INT_FIN_YEAR: ele.OP_CR_INT_FIN_YEAR ? Number(ele.OP_CR_INT_FIN_YEAR) : null,
            AC_OP_CD: ele.AC_OP_CD || 'C',
            status: 1,
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'MIGRATION',
            AC_OPDATE: ele.AC_OPDATE ? moment(ele.AC_OPDATE).format('DD/MM/YYYY') : null,
            AC_MBDATE: ele.AC_MBDATE ? moment(ele.AC_MBDATE).format('DD/MM/YYYY') : null,
            AC_ASON_DATE: ele.AC_ASON_DATE ? moment(ele.AC_ASON_DATE).format('DD/MM/YYYY') : null,
            AC_FREEZE_STATUS: ele.AC_FREEZE_STATUS,
            AC_CLOSED: ele.AC_CLOSED == 0 ? 0 : 1,
            IS_DORMANT: ele.IS_DORMANT != 0,
          };

          const dpInsert = await queryRunner.manager.createQueryBuilder()
            .insert().into('dpmaster').values(dpData)
            .orUpdate(Object.keys(dpData).filter(k => k !== 'BANKACNO'), ['BANKACNO'])
            .execute();

          // FIX: Ensure parentId is found even if row was updated instead of inserted
          const generatedId = dpInsert.identifiers[0]?.id || existingDpMap.get(key);
          if (generatedId) acToIdMap.set(key, generatedId);
        }

        // 4. CHILD TABLES LINKING
        // --- NOMINEE ---
        for (const n of nomineeRows) {
          const parentId = acToIdMap.get(`${String(n.AC_ACNOTYPE).trim()}-${n.AC_NO}`);
          if (parentId) {
            await queryRunner.manager.insert('nomineelink', {
              DPMasterID: parentId,
              AC_NNAME: this.transformValue(n.AC_NNAME),
              AC_NRELA: this.transformValue(n.AC_NRELA),
              AC_NDATE: n.AC_NDATE ? moment(n.AC_NDATE).format('DD/MM/YYYY') : null,
              AGE: n.AGE,
              AC_NADDR: this.transformValue(n.ADDR1),
              AC_NO: 100000 + Number(n.AC_NO),
              status: '1'
            });
          }
        }

        // --- ATTORNEY ---
        for (const a of attorneyRows) {
          const parentId = acToIdMap.get(`${String(a.AC_ACNOTYPE).trim()}-${a.AC_NO}`);
          if (parentId) {
            await queryRunner.manager.insert('atteroneylink', {
              DPMasterID: parentId,
              ATTERONEY_NAME: this.transformValue(a.ATTERONEY_NAME),
              DATE_APPOINTED: a.DATE_APPOINTED ? moment(a.DATE_APPOINTED).format('DD/MM/YYYY') : null,
              status: '1'
            });
          }
        }

        // --- JOINT ACCOUNT ---
        for (const j of jointRows) {
          const parentId = acToIdMap.get(`${String(j.AC_ACNOTYPE).trim()}-${j.AC_NO}`);
          if (parentId) {
            await queryRunner.manager.insert('joint_ac_link', {
              DPMasterID: parentId,
              JOINT_ACNAME: this.transformValue(j.JOINT_ACNAME),
              OPERATOR: Number(j.OPERATOR) === 0 ? 'No' : 'Yes',
              status: '1'
            });
          }
        }

        await queryRunner.commitTransaction();
        this.logger.log('Migration Successful. DPMASTER and children synced.');
        return { success: true };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        this.logger.error('Migration failed during transaction', err as any);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  // FIX 3: Robust key generation (Trimming and Uppercasing)
  private groupByRelation(rows: any[]): Map<string, any[]> {
    const map = new Map<string, any[]>();
    for (const row of rows) {
      // Aggressively clean AC_NO and AC_TYPE
      const acNo = String(row.AC_NO || '').replace(/\0/g, '').trim();
      const acType = String(row.AC_TYPE || '').replace(/\0/g, '').trim();

      if (!acNo || !acType) continue;

      const key = `${acNo}_${acType}`;

      if (!map.has(key)) {
        map.set(key, []);
      }
      map.get(key)!.push(row);
    }
    return map;
  }



  //-------------------------------------LNMASTER LOGIC ---------------------------------
  async migrateLNMASTER() {
    if (!this.clientConn) throw new Error('Client DB not connected');
    if (!this.serverDB) throw new Error('Server DB not connected');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      /* 1. LOAD MAPPINGS */
      const idmasterData = await queryRunner.manager.find(IDMASTER);
      const idMasterMap = new Map(idmasterData.map(x => [x.ORA_AC_NO, x]));
      const fallbackId = idmasterData.length > 0 ? idmasterData[0].id : null;

      if (!fallbackId) {
        throw new Error('Cannot migrate LNMASTER: IDMASTER table is empty in Postgres!');
      }

      const schemaData: any[] = await queryRunner.manager.query(`SELECT id, "S_APPL" FROM schemast`);
      const schemaMap = new Map(schemaData.map(x => [Number(x.S_APPL), x]));

      const syspara = await queryRunner.manager.query(`SELECT "BANK_CODE", "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0].BRANCH_CODE}`
      );
      const branchId = branch[0].id;

      /* 2. PRE-FETCH ORACLE DATA */
      const result = await this.clientConn.execute(`SELECT * FROM LNMASTER ORDER BY AC_NO`);
      const rows = this.convertOracleRows(result as any);

      this.logger.log('Pre-fetching LN child tables into memory...');
      const [secRes, guaRes, cobRes, intRes] = await Promise.all([
        this.clientConn.execute(`SELECT * FROM SECURITYDETAILS`),
        this.clientConn.execute(`SELECT * FROM GUARANTERDETAILS`),
        this.clientConn.execute(`SELECT * FROM COBORROWER`),
        this.clientConn.execute(`SELECT * FROM LNACINTRATE`)
      ]);

      const securityMap = this.groupByRelation(this.convertOracleRows(secRes as any));
      const guarantorMap = this.groupByRelation(this.convertOracleRows(guaRes as any));
      const coborrowerMap = this.groupByRelation(this.convertOracleRows(cobRes as any));
      const interestMap = this.groupByRelation(this.convertOracleRows(intRes as any));

      /* 3. BATCH PROCESSING */
      const batchSize = 500;
      for (let i = 0; i < rows.length; i += batchSize) {
        const batch = rows.slice(i, i + batchSize);
        await queryRunner.startTransaction();

        try {
          for (const ele of batch) {
            if (!ele.AC_TYPE) continue;

            let schemaCode = Number(ele.AC_TYPE);
            if (schemaCode > 999) schemaCode = Math.floor(schemaCode / 100);

            const schema = schemaMap.get(schemaCode);
            if (!schema) continue;

            const newAcNo = 100000 + Number(ele.AC_NO);
            const BANKACNO = this.generateBankAcNo(
              syspara[0].BANK_CODE,
              syspara[0].BRANCH_CODE,
              schema.S_APPL,
              newAcNo
            );

            const idmaster = idMasterMap.get(ele.AC_CUSTID);
            const finalCustId = idmaster ? idmaster.id : fallbackId;

            const newObj: any = {
              AC_NO: newAcNo,
              BANKACNO: BANKACNO,
              AC_TYPE: schema.id,
              AC_ACNOTYPE: schema.S_APPL,
              AC_CUSTID: finalCustId,
              idmasterID: finalCustId,
              AC_NAME: idmaster?.AC_NAME ?? this.transformValue(ele.AC_NAME),
              ORA_AC_NAME: ele.AC_NAME,
              AC_OPDATE: ele.AC_OPDATE ? moment(ele.AC_OPDATE).format('DD/MM/YYYY') : null,
              AC_SANCTION_AMOUNT: Number(ele.AC_SANCTION_AMOUNT) || 0,
              AC_INTRATE: Number(ele.AC_INTRATE) || 0,
              BRANCH_CODE: branchId,
              OID: ele.AC_NO,
              SYSCHNG_LOGIN: ele.OFFICER_CODE
            };

            const saved = await queryRunner.manager
              .createQueryBuilder()
              .insert()
              .into('lnmaster')
              .values(newObj)
              .orIgnore()
              .execute();

            const lnmasterId = saved.identifiers[0]?.id;

            if (lnmasterId) {
              // Correctly passing specific maps and IDs
              await this.migrateLNSecurity(ele, lnmasterId, BANKACNO, queryRunner, securityMap);
              await this.migrateLNGuarantors(ele, lnmasterId, BANKACNO, queryRunner, guarantorMap, idMasterMap);
              await this.migrateLNCoborrowers(ele, lnmasterId, BANKACNO, queryRunner, coborrowerMap, idMasterMap);
              await this.migrateLNInterestRates(ele, lnmasterId, BANKACNO, queryRunner, interestMap, branchId);
            } else {
              this.logger.warn(`Skipped children for ${BANKACNO}: Parent already exists.`);
            }
          }
          await queryRunner.commitTransaction();
          this.logger.log(`Processed batch up to ${i + batchSize}`);
        } catch (err) {

          if (queryRunner.isTransactionActive) {
            await queryRunner.rollbackTransaction();
          }

          this.logger.error(`Batch failed at index ${i}`, err);

          throw err;
        }
      }
      this.logger.log('LNMASTER Migration completed successfully.');
    }
    finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  // ----------------------------------- CHILD HELPERS -----------------------------------
  // 1. SECURITY DETAILS (Key: lnmasterID)
  private async migrateLNSecurity(ele: any, lnId: number, bankAcNo: string, queryRunner: QueryRunner, map: Map<string, any[]>) {
    const key = `${String(ele.AC_NO).trim()}_${String(ele.AC_TYPE).trim()}_${String(ele.AC_ACNOTYPE).trim().toUpperCase()}`;
    const rows = map.get(key) || [];

    for (const row of rows) {

      const migratedShortAcNo = Number(row.AC_NO);
      await queryRunner.manager.insert('securitydetails', {
        AC_ACNOTYPE: row.AC_ACNOTYPE,
        AC_TYPE: String(ele.AC_TYPE),
        AC_NO: migratedShortAcNo,
        SECURITY_CODE: row.SECURITY_CODE,
        SECURITY_VALUE: Number(row.SECURITY_VALUE) || 0,
        lnmasterID: lnId // Corrected to match Entity
      });
    }
  }

  // 2. GUARANTOR DETAILS (Key: lnmasterID)
  private async migrateLNGuarantors(ele: any, lnId: number, bankAcNo: string, queryRunner: QueryRunner, map: Map<string, any[]>, idMap: Map<number, any>) {
    const key = `${String(ele.AC_NO).trim()}_${String(ele.AC_TYPE).trim()}_${String(ele.AC_ACNOTYPE).trim().toUpperCase()}`;
    const rows = map.get(key) || [];

    for (const row of rows) {
      const guarantor = idMap.get(row.AC_CUSTID);
      const AC_MEMBNO = row.MEMBER_NO ? Number(row.MEMBER_NO) + 100000 : null;
      const migratedShortAcNo = Number(row.AC_NO);

      await queryRunner.manager.insert('guaranterdetails', {
        AC_ACNOTYPE: row.AC_ACNOTYPE,
        AC_TYPE: String(ele.AC_TYPE),
        AC_NO: migratedShortAcNo,
        AC_NAME: guarantor?.AC_NAME ?? this.transformValue(row.NAME || row.AC_NAME),
        MEMBER_TYPE: row.MEMBER_TYPE,
        MEMBER_NO: AC_MEMBNO ? String(AC_MEMBNO) : null,
        EXP_DATE: row.EXP_DATE ? moment(row.EXP_DATE).format('DD/MM/YYYY') : null,
        GAC_CUSTID: guarantor ? String(guarantor.id) : "0",
        lnmasterID: lnId // Corrected to match Entity
      });
    }
  }

  // 3. CO-BORROWERS (Key: LNMASTER_ID - as per your previous snippet)
  private async migrateLNCoborrowers(ele: any, lnId: number, bankAcNo: string, queryRunner: QueryRunner, map: Map<string, any[]>, idMap: Map<number, any>) {
    const key = `${String(ele.AC_NO).trim()}_${String(ele.AC_TYPE).trim()}_${String(ele.AC_ACNOTYPE).trim().toUpperCase()}`;
    const rows = map.get(key) || [];

    for (const row of rows) {
      const coborrower = idMap.get(row.AC_CUSTID);
      const migratedShortAcNo = Number(row.AC_NO);

      await queryRunner.manager.insert('coborrower', {
        AC_ACNOTYPE: row.AC_ACNOTYPE,
        AC_NO: migratedShortAcNo,
        AC_TYPE: String(ele.AC_TYPE),
        AC_NAME: coborrower?.AC_NAME ?? this.transformValue(row.NAME || row.AC_NAME),
        CAC_CUSTID: coborrower ? String(coborrower.id) : "0",
        lnmasterID: lnId // Corrected to match your previous entity snippet
      });
    }
  }

  // 4. INTEREST RATES (Key: LNMASTERID)
  private async migrateLNInterestRates(ele: any, lnId: number, bankAcNo: string, queryRunner: QueryRunner, map: Map<string, any[]>, branchId: number) {
    const key = `${String(ele.AC_NO).trim()}_${String(ele.AC_TYPE).trim()}_${String(ele.AC_ACNOTYPE).trim().toUpperCase()}`;
    const rows = map.get(key) || [];

    for (const row of rows) {
      const migratedShortAcNo = Number(row.AC_NO);

      await queryRunner.manager.insert('lnacintrate', {
        AC_ACNOTYPE: row.AC_ACNOTYPE,
        EFFECT_DATE: row.EFFECT_DATE ? moment(row.EFFECT_DATE).format('DD/MM/YYYY') : null,
        AC_NO: migratedShortAcNo,
        BANKACNO: bankAcNo,
        SERIAL_NO: row.SERIAL_NO,
        INT_RATE: Number(row.INT_RATE) || 0,
        PENAL_INT_RATE: Number(row.PENAL_INT_RATE) || 0,
        BRANCH_CODE: branchId,
        UPDATEFLAG: 1,
        lnmasterID: lnId // Corrected to match Entity (Uppercase)
      });
    }
  }


  // ------------------------------------ PGMASTER MIGRATION ------------------------------------
  async migratePGMASTERWithChildren() {
    if (!this.clientConn || !this.serverDB) {
      throw new Error('Databases not connected. Please connect via UI first.');
    }

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. --- LOAD MASTER DATA ---
      const syspara = await queryRunner.manager.query(
        `SELECT "BANK_CODE","BRANCH_CODE" FROM syspara LIMIT 1`
      );
      if (!syspara || syspara.length === 0) throw new Error('syspara configuration missing');

      const bankCodeStr = String(syspara[0].BANK_CODE || '0').padStart(3, '0');

      const schemaRows = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaRows.map(r => [Number(r.S_APPL), r.id]));

      const idmasterRows = await queryRunner.manager.query<{ id: number; ORA_AC_NO: string; AC_NAME: string }[]>(
        `SELECT id, "ORA_AC_NO", "AC_NAME" FROM idmaster`
      );
      const custMap = new Map(idmasterRows.map(r => [String(r.ORA_AC_NO || '').trim(), r]));

      const branchRes = await queryRunner.manager.query<{ id: number; CODE: string }[]>(
        `SELECT id, "CODE" FROM ownbranchmaster`
      );
      const branchMap = new Map(branchRes.map(b => [Number(b.CODE), b]));

      const branchRecord = branchMap.get(Number(this.BRANCH_CODE)) || branchRes[0];
      const branchInternalId = branchRecord?.id || 1;
      const branchCodeStr = String(branchRecord?.CODE || '001').padStart(3, '0');

      if (this.offset === 0) {
        const countRes = await this.clientConn.execute(`SELECT COUNT(*) as TOTAL FROM PGMASTER`);
        const countData = this.mapOracleToPgRows(countRes);
        this.count = Number(countData[0].TOTAL || 0);
      }

      this.logger.log(`Starting PGMASTER migration at offset: ${this.offset} / Total: ${this.count}`);

      // 2. --- FETCH ORACLE DATA ---
      const oracleQuery = `
      SELECT * FROM (
        SELECT rownum offset_val, rs.* FROM (
          SELECT PGMASTER.*, CATEGORYMASTER.CODE AS ACCATG, SCHEMAST.S_APPL,
          PGMASTER.AC_TYPE AS DPTYPE, OWNBRANCHMASTER.CODE AS ACINTROBRANCH,
          OPERATIONMASTER.CODE AS ACOPRCODE, INTCATEGORYMASTER.CODE AS ACINTCATA 
          FROM PGMASTER
          LEFT JOIN INTCATEGORYMASTER ON PGMASTER.AC_INTCATA = INTCATEGORYMASTER.CODE
          LEFT JOIN OPERATIONMASTER ON PGMASTER.AC_OPR_CODE = OPERATIONMASTER.CODE
          LEFT JOIN CATEGORYMASTER ON PGMASTER.AC_CATG = CATEGORYMASTER.CODE
          LEFT JOIN OWNBRANCHMASTER ON PGMASTER.AC_INTROBRANCH = OWNBRANCHMASTER.CODE
          LEFT JOIN SCHEMAST ON PGMASTER.AC_TYPE = SCHEMAST.S_APPL
          ORDER BY PGMASTER.AC_NO ASC
        ) rs
      ) WHERE offset_val <= ${(this.offset || 0) + (this.limit || 1000)} AND offset_val > ${this.offset || 0}`;

      const result = await this.clientConn.execute(oracleQuery);
      const rows = this.mapOracleToPgRows(result);

      let successCount = 0;

      for (const ele of rows) {
        const schemeTrimmed = String(ele.S_APPL || ele.AC_TYPE).slice(0, 3).padStart(3, '0');
        const transformedAcNo = Number(ele.AC_NO) + 100000;
        const acNoPadded = String(transformedAcNo).padStart(6, '0');
        const bankAcNo = `${bankCodeStr}${branchCodeStr}${schemeTrimmed}${acNoPadded}`;

        const schemaId = schemaMap.get(Number(ele.AC_TYPE));
        if (!schemaId) continue;

        const idmaster = custMap.get(String(ele.AC_CUSTID || '').trim());

        const exists = await queryRunner.manager.query(
          `SELECT id FROM pgmaster WHERE "BANKACNO" = $1`, [bankAcNo]
        );
        if (exists.length > 0) continue;

        let agentBankAcNo: string | undefined = undefined;
        let agentInternalId: number | undefined = undefined;
        if (ele.AGENT_ACTYPE) {
          agentInternalId = schemaMap.get(Number(ele.AGENT_ACTYPE)) || undefined;
          if (agentInternalId) {
            const agentSchemeTrimmed = String(ele.AGENT_ACTYPE).slice(0, 3).padStart(3, '0');
            const agentAcPadded = String(Number(ele.AGENT_ACNO) + 100000).padStart(6, '0');
            agentBankAcNo = `${bankCodeStr}${branchCodeStr}${agentSchemeTrimmed}${agentAcPadded}`;
          }
        }

        await queryRunner.startTransaction();

        try {
          const insertRes = await queryRunner.manager.createQueryBuilder()
            .insert()
            .into(PGMASTER)
            .values({
              BANKACNO: bankAcNo,
              AC_NO: transformedAcNo,
              AC_ACNOTYPE: 'PG',
              AC_TYPE: schemaId,
              idmasterID: idmaster?.id || 1,
              AC_CUSTID: ele.AC_CUSTID ? Number(ele.AC_CUSTID) : 1,
              AC_SHORT_NAME: this.transformValue(ele.AC_SHORT_NAME) || undefined,
              AC_CATG: ele.AC_CATG || undefined,
              AC_OPR_CODE: ele.AC_OPR_CODE || undefined,
              AC_INTCATA: ele.AC_INTCATA || undefined,
              BRANCH_CODE: branchInternalId,
              AC_MONTHS: Number(ele.AC_MONTHS) || 0,
              AC_SCHMAMT: Number(ele.AC_SCHMAMT) || 0,
              AC_AGE: (ele.AC_AGE !== null && ele.AC_AGE !== undefined) ? Number(ele.AC_AGE) : undefined,

              AC_EXPDT: ele.AC_EXPDT ? moment(ele.AC_EXPDT).format('DD/MM/YYYY') : undefined,
              AC_CLOSEDT: ele.AC_CLOSEDT ? moment(ele.AC_CLOSEDT).format('DD/MM/YYYY') : undefined,
              AC_BALDATE: ele.AC_BALDATE ? moment(ele.AC_BALDATE).format('DD/MM/YYYY') : undefined,
              AC_OPDATE: ele.AC_OPDATE ? moment(ele.AC_OPDATE).format('DD/MM/YYYY') : undefined,

              AC_INTROBRANCH: ele.AC_INTROBRANCH || undefined,
              AC_INTROID: ele.AC_INTROID || undefined,
              // FIX: Introducer Account No offset (+100,000) check
              AC_INTRACNO: (ele.AC_INTRACNO && Number(ele.AC_INTRACNO) > 0) ? String(Number(ele.AC_INTRACNO) + 100000) : undefined,

              AC_OP_BAL: ele.AC_OP_BAL || 0,
              AC_OP_CD: ele.AC_OP_CD || 'C',
              AC_CLOSED: ele.AC_CLOSED == 1 ? 1 : 0,
              AC_ODDAYS: ele.AC_ODDAYS || 0,

              AGENT_BRANCH: branchInternalId,
              AC_NAME: idmaster ? idmaster.AC_NAME : (this.transformValue(ele.AC_NAME) || undefined),
              AC_MEMBTYPE: ele.AC_MEMBTYPE === 99200 ? 99020 : (ele.AC_MEMBTYPE || undefined),
              // FIX: Safe check for Membership Number to avoid NaN errors
              AC_MEMBNO: (ele.AC_MEMBNO && Number(ele.AC_MEMBNO) > 0) ? (Number(ele.AC_MEMBNO) + 100000) : undefined,
              AGENT_ACTYPE: agentInternalId,
              AGENT_ACNO: agentBankAcNo,
              status: 1,
              SYSCHNG_LOGIN: ele.OFFICER_CODE || 'SYSTEM'
            })
            .execute();

          const parentId = insertRes.identifiers[0].id;

          await this.nomineelink('PGMASTER', ele.AC_ACNOTYPE, ele.DPTYPE, ele.AC_NO, parentId, queryRunner);
          await this.atteroneylink('PGMASTER', ele.AC_ACNOTYPE, ele.DPTYPE, ele.AC_NO, parentId, queryRunner);
          await this.jointAc('PGMASTER', ele.AC_ACNOTYPE, ele.DPTYPE, ele.AC_NO, parentId, queryRunner);

          await queryRunner.commitTransaction();
          successCount++;

        } catch (err: any) {
          await queryRunner.rollbackTransaction();
          this.logger.error(`DB ERROR AC ${ele.AC_NO}: ${err.message}`);
        }
      }

      if (this.offset + this.limit < this.count && this.flag === 0) {
        this.offset += this.limit;
        await this.migratePGMASTERWithChildren();
      }

      return { success: true, successCount };

    } catch (err: any) {
      this.logger.error(`FATAL: ${err.message}`);
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async migrateSHMASTERWithChild() {
    if (!this.clientConn || !this.serverDB) {
      throw new Error('Databases not connected. Please connect via UI first.');
    }

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. --- LOAD MASTER DATA ---
      const syspara = await queryRunner.manager.query(
        `SELECT "BANK_CODE","BRANCH_CODE" FROM syspara LIMIT 1`
      );
      if (!syspara || syspara.length === 0) throw new Error('syspara configuration missing');

      const schemaRows = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaRows.map(r => [Number(r.S_APPL), r.id]));

      const idmasterRows = await queryRunner.manager.query<{ id: number; ORA_AC_NO: string; AC_NAME: string }[]>(
        `SELECT id, "ORA_AC_NO", "AC_NAME" FROM idmaster`
      );
      const custMap = new Map(idmasterRows.map(r => [String(r.ORA_AC_NO || '').trim(), r]));

      const branchRes = await queryRunner.manager.query<{ id: number; CODE: string }[]>(
        `SELECT id, "CODE" FROM ownbranchmaster`
      );
      const branchMap = new Map(branchRes.map(b => [Number(b.CODE), b]));

      const branchRecord = branchMap.get(Number(this.BRANCH_CODE)) || branchRes[0];
      const branchInternalId = branchRecord?.id || 1;
      const branchCodeForAc = String(branchRecord?.CODE || '001').padStart(3, '0');

      if (this.offset === 0) {
        const countRes = await this.clientConn.execute(`SELECT COUNT(*) as TOTAL FROM SHMASTER`);
        const countData = this.mapOracleToPgRows(countRes);
        this.count = Number(countData[0].TOTAL || 0);
      }

      this.logger.log(`Starting SHMASTER migration at offset: ${this.offset} / Total: ${this.count}`);

      // 2. --- FETCH ORACLE DATA WITH PAGINATION ---
      const oracleQuery = `
      SELECT * FROM (
        SELECT rownum offset_val, rs.* FROM (
          SELECT * FROM SHMASTER ORDER BY AC_NO ASC
        ) rs
      ) WHERE offset_val <= ${this.offset + this.limit} AND offset_val > ${this.offset}`;

      const result = await this.clientConn.execute(oracleQuery);
      const rows = this.mapOracleToPgRows(result);

      let successCount = 0;

      // 3. --- LOOP THROUGH ROWS ---
      for (const ele of rows) {
        const schemaId = schemaMap.get(Number(ele.AC_TYPE));
        if (!schemaId) continue;

        const idmaster = custMap.get(String(ele.AC_CUSTID || '').trim());
        const transformedAcNo = Number(ele.AC_NO) + 100000;

        const bankAcNo = this.generateBankAcNo(
          Number(syspara[0].BANK_CODE),
          Number(branchCodeForAc), // Convert to number here
          Number(ele.S_APPL || ele.AC_TYPE),
          transformedAcNo
        );

        const exists = await queryRunner.manager.query(
          `SELECT id FROM shmaster WHERE "BANKACNO" = $1`, [bankAcNo]
        );
        if (exists.length > 0) continue;

        await queryRunner.startTransaction();

        try {

          const insertRes = await queryRunner.manager.createQueryBuilder()
            .insert()
            .into('shmaster')
            .values({
              BANKACNO: bankAcNo,
              AC_NO: transformedAcNo,
              AC_ACNOTYPE: 'SH',
              AC_TYPE: schemaId,
              idmasterID: idmaster?.id || 1,
              BRANCH_CODE: branchInternalId,
              AC_NAME: idmaster ? idmaster.AC_NAME : (this.transformValue(ele.AC_NAME) || undefined),
              AC_OPDATE: ele.AC_OPDATE ? moment(ele.AC_OPDATE).format('DD/MM/YYYY') : undefined,
              AC_MEMBTYPE: ele.AC_MEMBTYPE === 99200 ? 99020 : (ele.AC_MEMBTYPE || undefined),
              AC_MEMBNO: ele.AC_MEMBNO ? (Number(ele.AC_MEMBNO) + 100000) : undefined,
              // AC_CLOSED: Number(ele.AC_CLOSED) === 1 ? 1 : 0,

              // Identity & Employment
              AC_CUSTID: ele.AC_CUSTID ? Number(ele.AC_CUSTID) : 1,
              EMP_NO: (ele.EMP_NO !== null && ele.EMP_NO !== undefined) ? String(ele.EMP_NO) : undefined,
              MEMBERSHIP_BY: ele.MEMBERSHIP_BY || undefined,

              // Categorization & Office
              AC_CATG: ele.AC_CATG || undefined,
              AC_DIRECT: ele.AC_DIRECT || undefined,
              AC_BRANCH: (ele.AC_BRANCH !== null && ele.AC_BRANCH !== undefined) ? Number(ele.AC_BRANCH) : undefined,
              // Salary Division Mapping
              AC_SALARYDIVISION_CODE: (ele.AC_SALARYDIVISION_CODE !== null && ele.AC_SALARYDIVISION_CODE !== undefined) ? Number(ele.AC_SALARYDIVISION_CODE) : undefined,
              SUB_SALARYDIVISION_CODE: (ele.SUB_SALARYDIVISION_CODE !== null && ele.SUB_SALARYDIVISION_CODE !== undefined) ? Number(ele.SUB_SALARYDIVISION_CODE) : undefined,
              // Balance & Share Info
              AC_OP_SHNO: (ele.AC_OP_SHNO !== null && ele.AC_OP_SHNO !== undefined) ? Number(ele.AC_OP_SHNO) : 0,
              AC_FACE_VALUE: (ele.AC_FACE_VALUE !== null && ele.AC_FACE_VALUE !== undefined) ? Number(ele.AC_FACE_VALUE) : 0,
              AC_OP_BAL: (ele.AC_OP_BAL !== null && ele.AC_OP_BAL !== undefined) ? Number(ele.AC_OP_BAL) : 0,
              AC_OP_CD: ele.AC_OP_CD || 'C',

              // Dates
              AC_SHBALDATE: ele.AC_SHBALDATE ? moment(ele.AC_SHBALDATE).format('DD/MM/YYYY') : undefined,
              AC_CLOSEDT: ele.AC_CLOSEDT ? moment(ele.AC_CLOSEDT).format('DD/MM/YYYY') : undefined,

              // Transfer & References
              REF_ACNO: ele.REF_ACNO || undefined,
              DIV_TRANSFER_ACNOTYPE: ele.DIV_TRANSFER_ACNOTYPE || undefined,
              DIV_TRANSFER_ACNO: ele.DIV_TRANSFER_ACNO || undefined,

              // Status
              AC_CLOSED: Number(ele.AC_CLOSED) === 1 ? 1 : 0,
              status: 1,
              SYSCHNG_LOGIN: ele.OFFICER_CODE || 'SYSTEM'
            })
            .execute();


          const parentId = insertRes.identifiers[0].id;


          // SH table usually needs 'SHMASTER' as the table identifier for the link logic
          await this.nomineelink('SHMASTER', 'SH', ele.AC_TYPE, ele.AC_NO, parentId, queryRunner);
          await this.jointAc('SHMASTER', 'SH', ele.AC_TYPE, ele.AC_NO, parentId, queryRunner);

          await queryRunner.commitTransaction();
          successCount++;

        } catch (err: any) {
          await queryRunner.rollbackTransaction();
          this.logger.error(`DB ERROR SH AC ${ele.AC_NO}: ${err.message}`);
        }
      }

      // 4. --- RECURSIVE PAGINATION ---
      if (this.offset + this.limit < this.count && this.flag === 0) {
        this.offset += this.limit;
        await this.migrateSHMASTERWithChild();
      }

      return { success: true, successCount };

    } catch (err: any) {
      this.logger.error(`FATAL SHMASTER: ${err.message}`);
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async nomineelink(table: string, acnotype: string, ac_type: number, ac_no: number, id: number, queryRunner: QueryRunner) {
    try {
      const result = await this.clientConn.execute(
        `SELECT AC_NNAME, AC_NRELA, AC_NDATE, AGE, addr1 as AC_NADDR, addr2 as AC_NGALLI, addr3 as AC_NAREA, pin as AC_NPIN, ctcode as AC_CTCODE 
             FROM nomineelink 
             WHERE ac_acnotype = :1 AND ac_type = :2 AND ac_no = :3`,
        [acnotype, ac_type, ac_no]
      );

      const data = this.mapOracleToPgRows(result);

      for (const element of data) {
        const cityRes = await queryRunner.manager.query(
          `SELECT id FROM citymaster WHERE "CITY_CODE" = $1`,
          [element.AC_CTCODE]
        );
        const cityId = cityRes[0]?.id || undefined;

        const nomineePayload: any = {
          AC_NNAME: this.transformValue(element.AC_NNAME) || undefined,
          AC_NRELA: this.transformValue(element.AC_NRELA) || undefined,
          AC_NDATE: element.AC_NDATE ? moment(element.AC_NDATE).format('DD/MM/YYYY') : undefined,
          AGE: String(element.AGE || ''),
          AC_NADDR: this.transformValue(element.AC_NADDR) || undefined,
          AC_NGALLI: this.transformValue(element.AC_NGALLI) || undefined,
          AC_NAREA: this.transformValue(element.AC_NAREA) || undefined,
          AC_NCTCODE: cityId,
          AC_NPIN: element.AC_NPIN ? String(element.AC_NPIN) : undefined,
          status: '1'
        };

        if (table === 'SHMASTER') {
          nomineePayload.sharesID = id;
        } else if (table === 'DPMASTER') {
          nomineePayload.DPMasterID = id;
        } else if (table === 'PGMASTER') {
          nomineePayload.DPMasterID = id;
        }

        await queryRunner.manager.insert(NOMINEELINK, nomineePayload);
      }
    } catch (err: any) {
      this.logger.error(`Nominee link failed for AC ${ac_no}: ${err.message}`);
    }
  }

  async atteroneylink(table: string, acnotype: string, ac_type: number, ac_no: number, id: number, queryRunner: QueryRunner) {
    try {
      const result = await this.clientConn.execute(
        `SELECT ATTERONEY_NAME, DATE_APPOINTED, DATE_EXPIRY FROM ATTERONEYLINK 
             WHERE ac_acnotype = :1 AND ac_type = :2 AND ac_no = :3`,
        [acnotype, ac_type, ac_no]
      );

      const data = this.mapOracleToPgRows(result);

      for (const element of data) {
        await queryRunner.manager.insert(ATTERONEYLINK, {
          ATTERONEY_NAME: this.transformValue(element.ATTERONEY_NAME) || undefined,
          DATE_APPOINTED: element.DATE_APPOINTED ? moment(element.DATE_APPOINTED).format('DD/MM/YYYY') : undefined,
          DATE_EXPIRY: element.DATE_EXPIRY ? moment(element.DATE_EXPIRY).format('DD/MM/YYYY') : undefined,
          DPMasterID: table === 'DPMASTER' ? id : undefined,
          PGMasterID: table === 'PGMASTER' ? id : undefined,
        });
      }
    } catch (err: any) {
      this.logger.error(`Attorney link failed for AC ${ac_no}: ${err.message}`);
    }
  }

  async jointAc(table: string, acnotype: string, ac_type: number, ac_no: number, id: number, queryRunner: QueryRunner) {
    try {
      const result = await this.clientConn.execute(
        `SELECT * FROM JointAcLink WHERE ac_acnotype = :1 AND ac_type = :2 AND ac_no = :3`,
        [acnotype, ac_type, ac_no]
      );

      const data = this.mapOracleToPgRows(result);
      for (const element of data) {
        await queryRunner.manager.insert(JointAcLink, {
          JOINT_AC_CUSTID: Number(element.AC_CUSTID || 0),
          JOINT_ACNAME: this.transformValue(element.JOINT_ACNAME) || undefined,
          OPERATOR: Number(element.OPERATOR) === 0 ? 'No' : 'Yes',
          DPMasterID: table === 'DPMASTER' ? id : undefined,
          PGMasterID: table === 'PGMASTER' ? id : undefined,
        });
      }
    } catch (err: any) {
      this.logger.error(`Joint link failed for AC ${ac_no}: ${err.message}`);
    }
  }


  private mapOracleToPgRows(result: any): Record<string, any>[] {
    if (!result || !result.rows) return [];
    const oracleResult = result as OracleQueryResult;
    return oracleResult.rows.map((row: any[]) => {
      const obj: Record<string, any> = {};
      oracleResult.metaData.forEach((meta, index) => {
        obj[meta.name] = row[index];
      });
      return obj;
    });
  }

  // ---------------- SCHEMAST MIGRATION ----------------
  async migrateSCHEMAST() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const result = await this.clientConn.execute(`SELECT * FROM SCHEMAST ORDER BY S_APPL`);
      const data = this.convertOracleRows(result as any);
      const existing: { S_APPL: number }[] = await queryRunner.manager.query(`SELECT "S_APPL" FROM schemast`);
      const existingSet = new Set(existing.map(e => Number(e.S_APPL)));
      let inserted = 0;
      for (const ele of data) {
        const sAppl = Number(ele.S_APPL);
        if (!sAppl || existingSet.has(sAppl)) continue;
        const obj: Record<string, any> = {
          S_ACNOTYPE: ele.S_ACNOTYPE,
          S_APPL: sAppl,
          S_NAME: this.convertYogeshToEnglish(ele.S_NAME),
          S_SHNAME: this.transformValue(ele.S_SHNAME),
          S_GLACNO: ele.S_GLACNO,
          S_INT_ACNO: ele.S_INT_ACNO,
          IS_DEPO_LOAN: ele.IS_DEPO_LOAN == 0 ? '0' : '1',
          S_INT_APPLICABLE: ele.S_INT_APPLICABLE == 0 ? '0' : '1',
          POST_TO_INDIVIDUAL_AC: ele.POST_TO_INDIVIDUAL_AC == 0 ? '0' : '1',
          S_RECEIVABLE_INT_ALLOW: ele.S_RECEIVABLE_INT_ALLOW == 0 ? '0' : '1',
          IS_INT_ON_RECINT: ele.IS_INT_ON_RECINT == 0 ? '0' : '1',
          IS_INT_ON_OTHERAMT: ele.IS_INT_ON_OTHERAMT == 0 ? '0' : '1',
          INTEREST_METHOD: ele.INTEREST_METHOD,
          MIN_INT_LIMIT: ele.MIN_INT_LIMIT,
          S_PENAL_INT_RATE: ele.S_PENAL_INT_RATE,
          MAX_LOAN_LMT: ele.MAX_LOAN_LMT,
          DEFAULT_LOAN_PERIOD: ele.DEFAULT_LOAN_PERIOD,
          INSTALLMENT_METHOD: ele.INSTALLMENT_METHOD,
          S_PRODUCT_DAY_BASE: ele.S_PRODUCT_DAY_BASE,
          GL_ACNO: ele.GL_ACNO,
          MEMBER_TYPE: ele.MEMBER_TYPE,
          SHARES_FACE_VALUE: ele.SHARES_FACE_VALUE,
          DIVIDEND_PERCENTAGE: ele.DIVIDEND_PERCENTAGE,
        };
        await queryRunner.manager.insert(SCHEMAST, obj);
        inserted++;
      }
      await queryRunner.commitTransaction();
      return { success: true, inserted };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  // ---------------- SYSPARA MIGRATION ----------------
  async migrateSYSPARA() {

    if (!this.clientConn) throw new Error('Client DB not connected');
    if (!this.serverDB) throw new Error('Server DB not connected');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {

      // ✅ 1. Get Oracle data
      const result = await this.clientConn.execute(`SELECT * FROM SYSPARA`);
      const rows = this.convertOracleRows(result as any);

      if (!rows.length) {
        throw new Error('No SYSPARA data found in Oracle');
      }

      const ele = rows[0];

      // ✅ 2. Check already exists (important)
      const existing = await queryRunner.manager.query(
        `SELECT id FROM syspara LIMIT 1`
      );

      if (existing.length > 0) {
        this.logger.warn('SYSPARA already exists, skipping...');
        return { success: true, message: 'Already exists' };
      }

      // ✅ 3. Prepare object
      const sys: any = {

        SYSPARA_CODE: ele.SYSPARA_CODE,
        BANK_CODE: ele.BANK_CODE,
        BRANCH_CODE: String(ele.BRANCH_CODE),

        BANK_NAME: this.transformValue(ele.BANK_NAME),
        ADDRESS: this.transformValue(ele.ADDRESS),

        MAX_CERTI_NO: ele.MAX_CERTI_NO,
        MAX_SHARES_NO: ele.MAX_SHARES_NO,

        CHAIRMAN: this.transformValue(ele.CHAIRMAN),
        ACCOUNTANT: this.transformValue(ele.ACCOUNTANT),
        GENERAL_MANAGER: this.transformValue(ele.GENERAL_MANAGER),

        COMPANY_START_DATE: ele.COMPANY_START_DATE
          ? moment(ele.COMPANY_START_DATE).format('DD/MM/YYYY')
          : null,

        NO_OF_EMPLOYEES: ele.NO_OF_EMPLOYEES,

        OFFICER_NAME: this.transformValue(ele.OFFICER_NAME),
        OFFICER_DESIGNATION: this.transformValue(ele.OFFICER_DESIGNATION),

        RBI_LICENCE_NO: ele.RBI_LICENCE_NO,

        MANAGER_NAME: this.transformValue(ele.MANAGER_NAME),

        // ✅ Boolean conversions
        RECOVERY_METHOD: ele.RECOVERY_METHOD == 0 ? '0' : '1',
        IS_PROCESS_FOR_MONTH: ele.IS_PROCESS_FOR_MONTH == 0 ? '0' : '1',
        IS_PROCESS_UPTO_TRANDATE: ele.IS_PROCESS_UPTO_TRANDATE == 0 ? '0' : '1',

        // ✅ Dates
        PREVIOUS_DATE: ele.PREVIOUS_DATE
          ? moment(ele.PREVIOUS_DATE).format('DD/MM/YYYY')
          : null,

        CURRENT_DATE: ele.CURRENT_DATE
          ? moment(ele.CURRENT_DATE).format('DD/MM/YYYY')
          : null,

        // add more fields if needed (you already wrote them 👍)

      };

      // ✅ 4. Insert
      await queryRunner.manager.insert('syspara', sys);

      await queryRunner.commitTransaction();

      this.logger.log('SYSPARA migration completed');

      return { success: true };

    } catch (error) {

      await queryRunner.rollbackTransaction();
      this.logger.error('SYSPARA migration failed', error);
      throw error;

    } finally {

      await queryRunner.release();
    }
  }

  // ---------------- ACMASTER MIGRATION ----------------
  async migrateACMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    try {
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(`SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]);
      const branchId = branch[0]?.id || 1;
      const result = await this.clientConn.execute(`
        SELECT ACMASTER.*, SCHEMAST.S_APPL 
        FROM ACMASTER 
        LEFT JOIN SCHEMAST ON ACMASTER.AC_TYPE = SCHEMAST.S_APPL 
        ORDER BY ACMASTER.AC_NO ASC
      `);
      const rows = this.convertOracleRows(result as any);
      for (let i = 0; i < rows.length; i += 500) {
        const batch = rows.slice(i, i + 500);
        await queryRunner.startTransaction();
        try {
          for (const ele of batch) {
            const acNo = Number(ele.AC_NO);
            if (!acNo) continue;
            const existing = await queryRunner.manager.query(`SELECT id FROM acmaster WHERE "AC_NO" = $1`, [acNo]);
            if (existing.length > 0) continue;
            await queryRunner.manager.insert('acmaster', {
              id: acNo,
              AC_NO: acNo,
              AC_NAME: this.transformValue(ele.AC_NAME),
              BRANCH_CODE: branchId,
              AC_OP_BAL: Number(ele.AC_OP_BAL) || 0,
              AC_ACNOTYPE: ele.AC_ACNOTYPE || 'GL',
              AC_TYPE: ele.AC_TYPE,
              IS_POST_INT_AC: ele.IS_POST_INT_AC === 1,
              IS_DIRECT_ENTRY_ALLOW: ele.IS_DIRECT_ENTRY_ALLOW !== 0,
              IS_RED_BALANCE_AC: ele.IS_RED_BALANCE_AC === 1,
              AC_IS_CASH_IN_TRANSIT: ele.AC_IS_CASH_IN_TRANSIT === 1,
              IS_TAXABLEFOR_GST: ele.IS_TAXABLEFOR_GST === 1,
              IS_ACTIVE: true,
              AC_CLOSEDT: ele.AC_CLOSEDT ? moment(ele.AC_CLOSEDT).format('DD/MM/YYYY') : null,
              AC_OPDATE: ele.AC_OPDATE ? moment(ele.AC_OPDATE).format('DD/MM/YYYY') : null,
            });
          }
          await queryRunner.commitTransaction();
        } catch (err) {
          await queryRunner.rollbackTransaction();
          throw err;
        }
      }
      return { success: true };
    } finally {
      await queryRunner.release();
    }
  }

  // ---------------- TERMMASTER MIGRATION ----------------
  async migrateTERMMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    try {
      const result = await this.clientConn.execute(`SELECT * FROM TERMMASTER ORDER BY SR_NO ASC`);
      const rows = this.convertOracleRows(result as any);
      await queryRunner.startTransaction();
      for (const ele of rows) {
        if (ele.SR_NO == null) continue;
        const existing = await queryRunner.manager.query(`SELECT id FROM termmaster WHERE "SR_NO" = $1 AND "ACNOTYPE" = $2`, [ele.SR_NO, ele.ACNOTYPE]);
        if (existing.length > 0) continue;
        await queryRunner.manager.insert('termmaster', {
          SR_NO: ele.SR_NO,
          ACNOTYPE: ele.ACNOTYPE,
          TERM_TYPE: this.transformValue(ele.TERM_TYPE),
          PERIOD_FROM: Number(ele.PERIOD_FROM) || 0,
          PERIOD_TO: Number(ele.PERIOD_TO) || 0,
        });
      }
      await queryRunner.commitTransaction();
      return { success: true };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  async migrateOWNBRANCHMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting OWNBRANCHMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM OWNBRANCHMASTER ORDER BY CODE ASC`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(OWNBRANCHMASTER);
      const existingCodes = new Set(existingData.map(item => Number(item.CODE)));

      // 3. Get Syspara ID (Branches must link to the main system parameters)
      const syspara = await queryRunner.manager.query(`SELECT id FROM syspara LIMIT 1`);
      const sysparaId = syspara[0]?.id;

      if (!sysparaId) {
        throw new Error('Cannot migrate branches: syspara table is empty. Please migrate SYSPARA first.');
      }

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const branchCode = Number(ele.CODE);
          if (!branchCode) continue;

          // Skip if this branch code already exists in Postgres
          if (existingCodes.has(branchCode)) {
            this.logger.warn(`Branch code ${branchCode} already exists. Skipping.`);
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(ele.NAME), // Transliterate Marathi legacy font to English
            CODE: branchCode,
            AC_NO: ele.AC_NO === 0 ? null : ele.AC_NO,
            sysparaId: sysparaId,               // Relationship to system master
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(OWNBRANCHMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`OWNBRANCHMASTER: Migrated ${inserted} branches.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in OWNBRANCHMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  // ---------------- SIZEWISEBALANCE MIGRATION ----------------
  async migrateSIZEWISEBALANCE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    try {
      const result = await this.clientConn.execute(`SELECT * FROM SIZEWISEBALANCE ORDER BY AMOUNT_FROM ASC`);
      const rows = this.convertOracleRows(result as any);
      await queryRunner.startTransaction();
      for (const ele of rows) {
        if (ele.SR_NO == null) continue;
        const existing = await queryRunner.manager.query(`SELECT id FROM sizewisebalance WHERE "SR_NO" = $1 AND "ACNOTYPE" = $2`, [ele.SR_NO, ele.ACNOTYPE]);
        if (existing.length > 0) continue;
        await queryRunner.manager.insert('sizewisebalance', {
          SR_NO: ele.SR_NO,
          ACNOTYPE: ele.ACNOTYPE,
          SLAB_TYPE: this.transformValue(ele.SLAB_TYPE),
          AMOUNT_FROM: Number(ele.AMOUNT_FROM) === -1 ? 1 : Number(ele.AMOUNT_FROM) || 0,
          AMOUNT_TO: Number(ele.AMOUNT_TO) || 0,
          UNIT_OF_PERIOD: ele.UNIT_OF_PERIOD,
          FROM_MONTHS: Number(ele.FROM_MONTHS) || 0,
          FROM_DAYS: Number(ele.FROM_DAYS) || 0,
          TO_MONTHS: Number(ele.TO_MONTHS) || 0,
          TO_DAYS: Number(ele.TO_DAYS) || 0,
          DEDUCTION_PERCENT: Number(ele.DEDUCTION_PERCENT) || 0
        });
      }
      await queryRunner.commitTransaction();
      return { success: true };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  // ---------------- ADVOCATEMASTER MIGRATION ----------------
  async migrateADVOCATEMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    try {
      const result = await this.clientConn.execute(`SELECT * FROM ADVOCATEMASTER ORDER BY CODE ASC`);
      const rows = this.convertOracleRows(result as any);
      const existing = await queryRunner.manager.find(ADVOCATEMASTER);
      const existingNames = new Set(existing.map(adv => String(adv.NAME || '').trim().toLowerCase()));
      await queryRunner.startTransaction();
      for (const ele of rows) {
        const rawName = ele.NAME ? String(ele.NAME).trim() : null;
        if (!rawName || existingNames.has(rawName.toLowerCase())) continue;
        await queryRunner.manager.insert(ADVOCATEMASTER, { CODE: ele.CODE, NAME: this.transformValue(rawName) });
      }
      await queryRunner.commitTransaction();
      return { success: true };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  // ---------------- BALACATA MIGRATION ----------------
  async migrateBALACATA() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    try {
      const result = await this.clientConn.execute(`SELECT * FROM BALACATA ORDER BY BC_CODE ASC`);
      const rows = this.convertOracleRows(result as any);
      const existing = await queryRunner.manager.find(BALACATA);
      const existingNames = new Set(existing.map(item => String(item.BC_NAME || '').trim().toLowerCase()));
      await queryRunner.startTransaction();
      for (const ele of rows) {
        const rawName = ele.BC_NAME ? String(ele.BC_NAME).replace(/\0/g, '').trim() : null;
        if (!rawName || existingNames.has(rawName.toLowerCase())) continue;
        await queryRunner.manager.insert(BALACATA, { BC_NAME: this.transformValue(rawName), BC_MINBAL: Number(ele.BC_MINBAL) || 0 });
      }
      await queryRunner.commitTransaction();
      return { success: true };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }


  async migratePREFIX() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PREFIX migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM PREFIX ORDER BY SR_NO ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(PREFIX);
      const existingPrefixes = new Set(
        existingData.map(item => String(item.PREFIX || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawPrefix = ele.PREFIX ? String(ele.PREFIX).trim() : null;
          if (!rawPrefix) continue;

          // Skip if this prefix already exists
          if (existingPrefixes.has(rawPrefix.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            PREFIX: this.transformValue(rawPrefix), // Transliterate if stored in legacy font
            SEX: ele.SEX,                           // M/F/O
            PREFIX_REG: ele.PREFIX_REG,             // Regional language prefix
            // SR_NO: ele.SR_NO                     // Optional: mapping original serial
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(PREFIX, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PREFIX: Migrated ${inserted} new prefixes.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in PREFIX loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  // ---------------- GUARANTERDETAILS (LINKING) ----------------
  async migrateGUARANTERDETAILS() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();
    try {
      const pgData: any[] = await queryRunner.manager.query(`SELECT id, "AC_NAME" FROM guaranterdetails`);
      const nameMap = new Map(pgData.map(x => [String(x.AC_NAME || '').trim().toLowerCase(), x]));
      const result = await this.clientConn.execute(`SELECT AC_CUSTID, NAME FROM GUARANTERDETAILS`);
      const rows = this.convertOracleRows(result as any);
      for (const item of rows) {
        const name = String(this.transformValue(item.NAME || '')).trim().toLowerCase();
        const match = nameMap.get(name);
        if (match) {
          await queryRunner.manager.query(`UPDATE guaranterdetails SET "GAC_CUSTID" = $1 WHERE id = $2`, [item.AC_CUSTID, match.id]);
        }
      }
      await queryRunner.commitTransaction();
      return { success: true };
    } catch (error) {
      await queryRunner.rollbackTransaction();
      throw error;
    } finally {
      await queryRunner.release();
    }
  }

  async migratePRIORITYSECTORMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PRIORITYSECTORMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      // We select from PRIORITYMASTER (the Oracle table name)
      const result = await this.clientConn.execute(`
      SELECT * FROM PRIORITYMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(PRIORITYSECTORMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this sector name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            SUB1_CODE: ele.SUB1_CODE,
            SUB2_CODE: ele.SUB2_CODE,
            SUB3_CODE: ele.SUB3_CODE,
            NAME: this.transformValue(rawName), // Transliterate Marathi font to English
            // CODE: ele.CODE                  // Optional: mapping original unique code
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(PRIORITYSECTORMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PRIORITYSECTORMASTER: Migrated ${inserted} new sectors.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in PRIORITYSECTORMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateRECOVERYCLEARKMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting RECOVERYCLEARKMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM RECOVERYCLEARKMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(RECOVERYCLEARKMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get the Default Branch ID (matching your IDMASTER logic)
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this clerk name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi font to English
            BRANCH_CODE: branchId,             // Link to the internal Branch ID
            // CODE: ele.CODE                  // Optional: mapping original unique code if entity has it
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(RECOVERYCLEARKMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`RECOVERYCLEARKMASTER: Migrated ${inserted} new recovery clerks.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion for TypeScript 'unknown' variable
        this.logger.error(`Inner failure in RECOVERYCLEARKMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }


  async migrateSALARYDIVISIONMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting SALARYDIVISIONMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM SALARYDIVISIONMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(SALARYDIVISIONMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get the Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this salary division already exists
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName),
            SHORT_NAME: this.transformValue(ele.SHORT_NAME),
            AT_POST: this.transformValue(ele.AT_POST),
            TALUKA_NAME: this.transformValue(ele.TALUKA_NAME),
            DISTRICT_NAME: this.transformValue(ele.DISTRICT_NAME),
            PHNO: ele.PHNO || null,
            MOBNO: ele.MOBNO || null,
            BRANCH_CODE: branchId, // Mapping to internal Branch ID
            // CODE: ele.CODE      // Include if your entity preserves the original code
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(SALARYDIVISIONMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`SALARYDIVISIONMASTER: Migrated ${inserted} new divisions.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error
        this.logger.error(`Inner failure in SALARYDIVISIONMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateSUBSALARYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('Client DB not connected');
    if (!this.serverDB) throw new Error('Server DB not connected');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM SUBSALARYMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(SUBSALARYMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this sub-salary division already exists
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName),
            AT_POST: this.transformValue(ele.AT_POST),
            TALUKA_NAME: this.transformValue(ele.TALUKA_NAME),
            DISTRICT_NAME: this.transformValue(ele.DISTRICT_NAME),
            AC_EMAILID: ele.AC_EMAILID || null,
            PHNO: ele.PHNO || null,
            MOBNO: ele.MOBNO || null,
            SAL_CODE: ele.SAL_CODE || null, // Link to Parent Salary Division Code
            BRANCH_CODE: branchId,         // Internal Branch ID
            // CODE: ele.CODE               // Original unique code
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(SUBSALARYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`SUBSALARYMASTER: Migrated ${inserted} new sub-divisions.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion for TypeScript 'unknown' variable
        this.logger.error(`Inner failure in SUBSALARYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateWEAKERMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting WEAKERMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM WEAKERMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicate entries
      const existingData = await queryRunner.manager.find(WEAKERMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this weaker section category already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            // CODE: ele.CODE                  // Optional: original code if required by entity
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(WEAKERMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`WEAKERMASTER: Migrated ${inserted} new weaker section categories.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in WEAKERMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateTDRECEIPTMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting TDRECEIPTMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM TDRECEIPTMASTER
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(TDRECEIPTMASTER);
      const existingTypes = new Set(
        existingData.map(item => String(item.RECEIPT_TYPE || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawType = ele.RECEIPT_TYPE ? String(ele.RECEIPT_TYPE).trim() : null;
          if (!rawType) continue;

          // Skip if this receipt type already exists for this specific branch
          if (existingTypes.has(rawType.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            RECEIPT_TYPE: this.transformValue(rawType), // Transliterate if stored in legacy font
            LAST_RECEIPT_NO: Number(ele.LAST_RECEIPT_NO) || 0,
            BRANCH_CODE: branchId, // Link to internal Branch ID
            // OID: ele.ID         // Include if your entity tracks original Oracle ID
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(TDRECEIPTMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`TDRECEIPTMASTER: Migrated ${inserted} receipt types.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion to satisfy 'unknown' type check
        this.logger.error(`Inner failure in TDRECEIPTMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateAUTHORITYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting AUTHORITYMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM AUTHORITYMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(AUTHORITYMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this authority name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            // CODE: ele.CODE                  // Optional: include original code if entity supports it
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(AUTHORITYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`AUTHORITYMASTER: Migrated ${inserted} new authorities.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion for TypeScript 'unknown' variable
        this.logger.error(`Inner failure in AUTHORITYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateLOCKERRACKMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting LOCKERRACKMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM LOCKERRACKMASTER ORDER BY RACK_NO ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(LOCKERRACKMASTER);
      const existingRacks = new Set(
        existingData.map(item => String(item.RACK_DESC || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawDesc = ele.RACK_DESC ? String(ele.RACK_DESC).trim() : null;
          if (!rawDesc) continue;

          // Skip if this rack description already exists
          if (existingRacks.has(rawDesc.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            RACK_DESC: this.transformValue(rawDesc), // Transliterate Marathi legacy font
            LOCKER_FROMNO: Number(ele.LOCKER_FROMNO) || 0,
            LOCKER_TONO: Number(ele.LOCKER_TONO) || 0,
            BRANCH_CODE: branchId, // Mapping to internal Branch ID
            // RACK_NO: ele.RACK_NO // Optional: mapping original sequence number
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(LOCKERRACKMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`LOCKERRACKMASTER: Migrated ${inserted} racks.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Fixed 'unknown' type error
        this.logger.error(`Inner failure in LOCKERRACKMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }


  async migrateLOCKERSIZE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting LOCKERSIZE migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM LOCKERSIZE ORDER BY SIZE_SR_NO ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(LOCKERSIZE);
      const existingSizes = new Set(
        existingData.map(item => String(item.SIZE_NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.SIZE_NAME ? String(ele.SIZE_NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this size definition already exists
          if (existingSizes.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            SIZE_NAME: this.transformValue(rawName), // Transliterate Marathi font to English
            RENT: Number(ele.RENT) || 0,
            BRANCH_CODE: branchId,                  // Mapping to internal Branch ID
            // SIZE_SR_NO: ele.SIZE_SR_NO            // Optional: mapping original serial number
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(LOCKERSIZE, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`LOCKERSIZE: Migrated ${inserted} locker sizes.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in LOCKERSIZE loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateLOCKERMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting LOCKERMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data with a join to get the Size Serial Number
      const result = await this.clientConn.execute(`
      SELECT LOCKERMASTER.*, LOCKERSIZE.SIZE_SR_NO 
      FROM LOCKERMASTER 
      LEFT JOIN LOCKERSIZE ON LOCKERMASTER.SIZE_SR_NO = LOCKERSIZE.SIZE_SR_NO
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing Size mappings from Postgres to link by original Serial No
      const pgSizes = await queryRunner.manager.find(LOCKERSIZE);
      // Note: This assumes your LOCKERSIZE entity has a field to store the original Oracle SIZE_SR_NO
      // If not, we map by the index/code logic used during LOCKERSIZE migration.

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      // 4. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Skip if locker number is missing
          if (!ele.LOCKER_NO) continue;

          // Duplicate Check: prevent double-entry for the same locker in the same branch
          const existing = await queryRunner.manager.query(
            `SELECT id FROM lockermaster WHERE "LOCKER_NO" = $1 AND "BRANCH_CODE" = $2`,
            [ele.LOCKER_NO, branchId]
          );
          if (existing.length > 0) continue;

          // Link to the correct Postgres LOCKERSIZE record
          const sizeRecord = pgSizes.find(s => s.id === ele.SIZE_SR_NO); // Adjust lookup logic based on your Entity fields

          const newObj: any = {
            LOCKER_NO: ele.LOCKER_NO,
            KEY_NO: ele.KEY_NO ? String(ele.KEY_NO).trim() : null,
            SIZE_SR_NO: sizeRecord ? sizeRecord.id : null, // Foreign Key to locker_size_master
            BRANCH_CODE: branchId,
            // If you have rack associations:
            // RACK_NO: ele.RACK_NO 
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(LOCKERMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`LOCKERMASTER: Migrated ${inserted} locker units.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion for TypeScript 'unknown' variable
        this.logger.error(`Inner failure in LOCKERMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }



  async migrateITEMCATEGORYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting ITEMCATEGORYMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      // Note: Oracle table name is usually ITEMCATEGORY
      const result = await this.clientConn.execute(`
      SELECT * FROM ITEMCATEGORY ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(ITEMCATEGORYMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this category name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi font to English
            // CODE: ele.CODE                  // Optional: include if your entity tracks original code
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(ITEMCATEGORYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`ITEMCATEGORYMASTER: Migrated ${inserted} new categories.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion for TypeScript 'unknown' variable
        this.logger.error(`Inner failure in ITEMCATEGORYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateDOCUMENTMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting DOCUMENTMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM DOCUMENTMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingDocs = await queryRunner.manager.find(DOCUMENTMASTER);
      const existingNames = new Set(
        existingDocs.map(doc => String(doc.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if the document name already exists in the Postgres database
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            // CODE: ele.CODE                  // Optional: original unique code mapping
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(DOCUMENTMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`DOCUMENTMASTER: Migrated ${inserted} new document types.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Type assertion to resolve 'unknown' error type
        this.logger.error(`Inner failure in DOCUMENTMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateCOURTMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting COURTMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM COURTMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(COURTMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this court name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            this.logger.warn(`Skipping duplicate COURT: ${rawName}`);
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            CODE: ele.CODE ?? null              // Map original unique code if entity has it
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(COURTMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`COURTMASTER: Migrated ${inserted} new court records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for TypeScript compiler
        this.logger.error(`Inner failure in COURTMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateBRANCHMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting BRANCHMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM BRANCHMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(BRANCHMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this branch name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            this.logger.warn(`Skipping duplicate Branch: ${rawName}`);
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            AC_NO: ele.AC_NO === 0 ? null : ele.AC_NO,
            CODE: ele.CODE ?? null              // Maintain original sequence code
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(BRANCHMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`BRANCHMASTER: Migrated ${inserted} new branch records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in BRANCHMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateCATEGORYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting CATEGORYMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM CATEGORYMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(CATEGORYMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this category name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            this.logger.warn(`Skipping duplicate Category: ${rawName}`);
            continue;
          }

          const newObj: any = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            CODE: ele.CODE ?? null              // Maintain original category code
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(CATEGORYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`CATEGORYMASTER: Migrated ${inserted} new category records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for TypeScript
        this.logger.error(`Inner failure in CATEGORYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateBANKDETAILS() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting BANKDETAILS migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM BANKDETAILS ORDER BY BANK_CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Check if data already exists (Usually only 1 record for the bank itself)
      const existingCount = await queryRunner.manager.count(BANKDETAILS);
      if (existingCount > 0) {
        this.logger.warn('BANKDETAILS already exists in Postgres. skipping...');
        return { success: true, message: 'Already exists' };
      }

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const newObj: any = {
            NAME: this.transformValue(ele.NAME),           // Transliterates Bank Name
            TAN_NO: ele.TAN_NO || null,
            PAN_NO: ele.PAN_NO || null,
            FLAT_PRM_NO: ele.FLAT_PRM_NO || null,
            FLAT_PRM_NAME: this.transformValue(ele.FLAT_PRM_NAME),
            RD_LANE_NAME: this.transformValue(ele.RD_LANE_NAME),
            AREA_LOCATION: this.transformValue(ele.AREA_LOCATION),
            CITY_CODE: ele.CITY_CODE || null,
            PIN_CODE: ele.PIN_CODE || null,
            PHONE_OFFICE: ele.PHONE_OFFICE || null,
            EMAIL: ele.EMAIL || null,
            SHORT_NAME: this.transformValue(ele.SHORT_NAME),
            SBI_BANKCODE: ele.SBI_BANKCODE || null,
            // If your entity has these fields added for the new system:
            GST_NO: ele.GST_NO || null,
            MOB_NUM: ele.MOB_NUM || null,
            STATE: ele.STATE || null
          };

          await queryRunner.manager.insert(BANKDETAILS, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`BANKDETAILS: Migrated ${inserted} records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // TypeScript fix for 'unknown' type
        this.logger.error(`Inner failure in BANKDETAILS loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateCITYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting CITYMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      const result = await this.clientConn.execute(`SELECT * FROM CITYMASTER ORDER BY CITY_CODE ASC`);
      const rows = this.convertOracleRows(result as any);

      const existingCities = await queryRunner.manager.find(CITYMASTER);
      const existingNames = new Set(
        existingCities.map(city => String(city.CITY_NAME || '').trim().toLowerCase())
      );

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.CITY_NAME ? String(ele.CITY_NAME).trim() : null;
          if (!rawName) continue;

          if (existingNames.has(rawName.toLowerCase())) continue;

          const newObj: any = {
            CITY_CODE: ele.CITY_CODE,
            CITY_NAME: this.transformValue(rawName),
            TALUKA_CODE: ele.TALUKA_CODE || 1,    // Fallback to 1 if null
            DISTRICT_CODE: ele.DISTRICT_CODE || 1, // Fallback to 1 if null
            STATE_CODE: ele.STATE_CODE || 1,       // Fallback to 1 if null

            // FIX: Providing a default value of 1 to satisfy the NOT NULL constraint
            REGION_CODE: ele.REGION_CODE || 1,

            DISTANCE: Number(ele.DISTANCE) || 0
          };

          await queryRunner.manager.insert(CITYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`CITYMASTER: Migrated ${inserted} city records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Inner failure in CITYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateBANKMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting BANKMASTER migration with corrected Oracle query...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      // FIX: Changed "ORDER BY CODE" to "ORDER BY BANK_CODE" (or remove the order by)
      const result = await this.clientConn.execute(`
      SELECT * FROM BANKMASTER
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      const existingData = await queryRunner.manager.find(BANKMASTER);
      const existingNames = new Set(
        existingData.map(item => String(item.BANK_NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Handle variations in Oracle column naming (BANK_NAME or NAME)
          const rawName = (ele.BANK_NAME || ele.NAME) ? String(ele.BANK_NAME || ele.NAME).trim() : null;
          if (!rawName) continue;

          if (existingNames.has(rawName.toLowerCase())) continue;

          const newObj: any = {
            BANK_NAME: this.transformValue(rawName),
            BANK_SHORTNAME: this.transformValue(ele.BANK_SHORTNAME || ele.SHORT_NAME || ''),
            LEDGER_CODE: ele.LEDGER_CODE || null,
            BANKCODE: ele.BANKCODE || null,
            DD_APPLICABLE: String(ele.DD_APPLICABLE || '0'),
            GL_ACNO: ele.GL_ACNO || null,
            HO_SUB_GLACNO: ele.HO_SUB_GLACNO || null,
            BANKERS_COMM_APPLICABLE: String(ele.BANKERS_COMM_APPLICABLE || '0'),
            RIGHT_TO_PREPARE_DD: String(ele.RIGHT_TO_PREPARE_DD || '0'),
            PARTICIPATE_IN_CLEARING: String(ele.PARTICIPATE_IN_CLEARING || '0'),
          };

          await queryRunner.manager.insert(BANKMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`BANKMASTER: Migrated ${inserted} records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Inner failure in BANKMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateDEPRCATEGORY() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting DEPRCATEGORY migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM DEPRCATEGORY`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data with explicit typing for ESLint
      const existingData: DEPRCATEGORY[] = await queryRunner.manager.find(DEPRCATEGORY);
      const existingNames = new Set(
        existingData.map((item: DEPRCATEGORY) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Prevent FK Violation: Fetch valid AC_NOs from acmaster
      const validAccounts: { AC_NO: number }[] = await queryRunner.manager.query(`SELECT "AC_NO" FROM acmaster`);
      const validAcSet = new Set(validAccounts.map(a => Number(a.AC_NO)));

      // 4. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;
        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const oracleAcNo = Number(ele.AC_NO);
          const hasValidAccount = validAcSet.has(oracleAcNo);

          // Map data to Entity
          const newObj: Partial<DEPRCATEGORY> = {
            NAME: this.transformValue(rawName),
            // If account doesn't exist in acmaster, we set to null to avoid FK error
            AC_NO: hasValidAccount ? oracleAcNo : undefined, BRANCH_CODE: branchId,
          };

          if (!hasValidAccount && oracleAcNo !== 0) {
            this.logger.warn(`AC_NO ${oracleAcNo} missing in acmaster. Setting to null for ${rawName}`);
          }

          await queryRunner.manager.insert(DEPRCATEGORY, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`DEPRCATEGORY: Migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateDIRECTORMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting DIRECTORMASTER migration (Clean Lint & DB Bypass)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data - No CTCODE in select
      const result = await this.clientConn.execute(`
      SELECT CODE, NAME, DESIGNATION, AC_ADDR1, AC_ADDR2, AC_ADDR3, AC_PIN, AC_MOBILENO 
      FROM DIRECTORMASTER
    `);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG names
      // FIX: Typed variable declaration (removes unnecessary-type-assertion error)
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM directormaster`
      );

      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id || null;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          // 4. Create payload WITHOUT CTCODE
          const payload = {
            NAME: this.transformValue(rawName),
            DESIGNATION: this.transformValue(ele.DESIGNATION || ''),
            AC_ADDR1: this.transformValue(ele.AC_ADDR1 || ''),
            AC_ADDR2: this.transformValue(ele.AC_ADDR2 || ''),
            AC_ADDR3: this.transformValue(ele.AC_ADDR3 || ''),
            AC_PIN: ele.AC_PIN ? String(ele.AC_PIN) : null,
            AC_MOBILENO: ele.AC_MOBILENO || null,
            IS_CURRENT_BODY_MEMBER: '1',
            SMS_REQUIRED: '0',
            BRANCH_CODE: branchId,
          };

          // 5. Insert using table name string 'directormaster'
          // FIX: This bypasses the DIRECTORMASTER Entity entirely (resolves unused-vars error)
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('directormaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`DIRECTORMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateHEALTHMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting HEALTHMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM HEALTHMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data (Explicitly typed for ESLint no-unsafe-call)
      const existingData: HEALTHMASTER[] = await queryRunner.manager.find(HEALTHMASTER);
      const existingNames = new Set(
        existingData.map((item: HEALTHMASTER) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this health status already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            this.logger.warn(`Skipping duplicate Health Status: ${rawName}`);
            continue;
          }

          const newObj: Partial<HEALTHMASTER> = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            CODE: ele.CODE ?? null              // Map original unique code if entity has it
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(HEALTHMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`HEALTHMASTER: Migrated ${inserted} new health records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in HEALTHMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateINDUSTRYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting INDUSTRYMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM INDUSTRYMASTER ORDER BY CODE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data (Explicitly typed for ESLint no-unsafe-call)
      const existingData: INDUSTRYMASTER[] = await queryRunner.manager.find(INDUSTRYMASTER);
      const existingNames = new Set(
        existingData.map((item: INDUSTRYMASTER) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName) continue;

          // Skip if this industry name already exists in Postgres
          if (existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          const newObj: Partial<INDUSTRYMASTER> = {
            NAME: this.transformValue(rawName), // Transliterate Marathi legacy font to English
            CODE: ele.CODE ?? null              // Map original unique code if entity has it
          };

          // Standard Insert using the Entity reference
          await queryRunner.manager.insert(INDUSTRYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`INDUSTRYMASTER: Migrated ${inserted} new industry records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error; // Resolve 'unknown' type error for compiler
        this.logger.error(`Inner failure in INDUSTRYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateINSUARANCEMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting INSUARANCEMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM INSUARANCEMASTER`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data (Typed to INSUARANCEMASTER[] to satisfy ESLint)
      const existingData: INSUARANCEMASTER[] = await queryRunner.manager.find(INSUARANCEMASTER);
      const existingNames = new Set(
        existingData.map((item: INSUARANCEMASTER) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;

          // Skip if name is missing or already exists
          if (!rawName || existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          // Mapping only the properties present in your Entity
          const newObj: Partial<INSUARANCEMASTER> = {
            NAME: this.transformValue(rawName)
            // CODE is @Generated('increment'), no need to map manually
          };

          await queryRunner.manager.insert(INSUARANCEMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`INSUARANCEMASTER: Successfully migrated ${inserted} records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error;
        this.logger.error(`Inner failure in INSUARANCEMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateINTCATEGORYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting INTCATEGORYMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM INTCATEGORYMASTER`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data (Typed for ESLint compliance)
      const existingData: INTCATEGORYMASTER[] = await queryRunner.manager.find(INTCATEGORYMASTER);
      const existingNames = new Set(
        existingData.map((item: INTCATEGORYMASTER) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Start Transaction
      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;

          // Skip if name is missing or already exists
          if (!rawName || existingNames.has(rawName.toLowerCase())) {
            continue;
          }

          // FIX: Mapping only the 'NAME' property to match your Entity
          const newObj: Partial<INTCATEGORYMASTER> = {
            NAME: this.transformValue(rawName)
            // Removed SHORT_NAME to resolve TS2353
          };

          await queryRunner.manager.insert(INTCATEGORYMASTER, newObj);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`INTCATEGORYMASTER: Successfully migrated ${inserted} records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) {
          await queryRunner.rollbackTransaction();
        }
        const error = err as Error;
        this.logger.error(`Inner failure in INTCATEGORYMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) {
        await queryRunner.release();
      }
    }
  }

  async migrateITEMMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting ITEMMASTER migration (Overflow Protection Active)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      const result = await this.clientConn.execute(`SELECT * FROM ITEMMASTER`);
      const rows = this.convertOracleRows(result as any);

      const existingRows: { ITEM_NAME: string }[] = await queryRunner.manager.query(
        `SELECT "ITEM_NAME" FROM itemmaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.ITEM_NAME || '').trim().toLowerCase())
      );

      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      // Helper to prevent numeric(8,2) overflow (Max 999,999.99)
      const safeNumeric = (val: any): number => {
        const num = Number(val || 0);
        return num >= 1000000 ? 999999.99 : num;
      };

      const defaultDate = moment().format('DD/MM/YYYY');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = (ele.ITEM_NAME || ele.NAME || ele.DESCRIPTION)
            ? String(ele.ITEM_NAME || ele.NAME || ele.DESCRIPTION).trim()
            : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            ITEM_NAME: this.transformValue(rawName),
            ITEM_TYPE: ele.ITEM_TYPE || 'DEDST',

            PURCHASE_DATE: ele.PURCHASE_DATE
              ? moment(ele.PURCHASE_DATE).format('DD/MM/YYYY')
              : (ele.OP_BAL_DATE ? moment(ele.OP_BAL_DATE).format('DD/MM/YYYY') : defaultDate),

            OP_BAL_DATE: ele.OP_BAL_DATE
              ? moment(ele.OP_BAL_DATE).format('DD/MM/YYYY')
              : defaultDate,

            // FIX: Capping values to prevent "numeric field overflow"
            PURCHASE_RATE: safeNumeric(ele.PURCHASE_RATE),
            PURCHASE_VALUE: safeNumeric(ele.PURCHASE_VALUE),
            OP_QUANTITY: Number(ele.OP_QUANTITY || 1),
            OP_BALANCE: safeNumeric(ele.OP_BALANCE),

            status: '1',
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'SUPERVISOR',
            DEPR_CATEGORY: Number(ele.DEPR_CATEGORY || 3),
            SUPPLIER_NAME: this.transformValue(ele.SUPPLIER_NAME || 'OPENING STOCK'),
            BRANCH_CODE: branchId,
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('itemmaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`ITEMMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateLOANSTAGEMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting LOANSTAGEMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      // Common table names: LOANSTAGEMASTER or LNSTAGEMASTER
      const result = await this.clientConn.execute(`SELECT * FROM LOANSTAGEMASTER`);
      const rows = this.convertOracleRows(result as any);

      // 2. Duplicate Check using NAME or STAGE_NAME
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM loanstagemaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      // Helper for numeric(8,2) limits (No-Alter workaround)
      const safeNumeric = (val: any): number => {
        const num = Number(val || 0);
        return num >= 1000000 ? 999999.99 : num;
      };

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Fallback for Oracle Column names
          const rawName = (ele.NAME || ele.STAGE_NAME || ele.DESCRIPTION)
            ? String(ele.NAME || ele.STAGE_NAME || ele.DESCRIPTION).trim()
            : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            NAME: this.transformValue(rawName),           // Transliterates Marathi font
            SHORT_NAME: this.transformValue(ele.SHORT_NAME || ele.SHNAME || ''),

            // Loan stages often have sequence or priority numbers
            STAGE_ORDER: Number(ele.STAGE_ORDER || ele.SR_NO || 0),

            // Fees or charges associated with the stage
            STAGE_FEES: safeNumeric(ele.STAGE_FEES || ele.FEES),

            // Mandatory tracking columns
            STATUS: ele.STATUS || '1',
            BRANCH_CODE: branchId,
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',

            // Dates (If applicable to your PG schema)
            CREATED_DATE: ele.CREATED_DATE ? moment(ele.CREATED_DATE).format('DD/MM/YYYY') : moment().format('DD/MM/YYYY')
          };

          // 4. Insert into PostgreSQL
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('loanstagemaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`LOANSTAGEMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateNARRATIONMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting NARRATIONMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM NARRATIONMASTER`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG narrations (Column is "NARRATION" based on your pgAdmin)
      const existingRows: { NARRATION: string }[] = await queryRunner.manager.query(
        `SELECT "NARRATION" FROM narrationmaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NARRATION || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;
        for (const ele of rows) {
          // Oracle uses NARRATION column according to your screenshot
          const rawName = ele.NARRATION ? String(ele.NARRATION).trim() : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            // transformValue converts those Oracle symbols into readable text
            NARRATION: this.transformValue(rawName),
            BRANCH_CODE: branchId,
            // Add status or other mandatory columns if required by your PG schema
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('narrationmaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`NARRATIONMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateOCCUPATIONMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting OCCUPATIONMASTER migration (Safe String-Table Pattern)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM OCCUPATIONMASTER`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG names to prevent duplicates
      // Using raw query to be safe against any unused entity variables
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM occupationmaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = ${syspara[0]?.BRANCH_CODE || 101}`
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Oracle column fallback (NAME or OCCUPATION_NAME)
          const rawName = (ele.NAME || ele.OCCUPATION_NAME)
            ? String(ele.NAME || ele.OCCUPATION_NAME).trim()
            : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            // transformValue handles the legacy Marathi symbols (mojibake)
            NAME: this.transformValue(rawName),
            CODE: ele.CODE || null,
            BRANCH_CODE: branchId,
            status: '1', // Assuming active status by default
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',
          };

          // 4. Insert into PostgreSQL using the table name string
          // This is the "workful" way that avoids metadata/CTCODE-style crashes
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('occupationmaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`OCCUPATIONMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateOPERATIONMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting OPERATIONMASTER migration (Marathi Font & Metadata Bypass)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM OPERATIONMASTER`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG records for duplicate check
      // Using raw query to avoid Entity dependency and ESLint unused-var errors
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM operationmaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Handle common Oracle column names for Operation/Mode
          const rawName = (ele.NAME || ele.OPERATION_NAME || ele.MODE_DESC)
            ? String(ele.NAME || ele.OPERATION_NAME || ele.MODE_DESC).trim()
            : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            // transformValue handles legacy Marathi font symbols (mojibake)
            NAME: this.transformValue(rawName),
            CODE: ele.CODE || ele.MODE_CODE || null,
            BRANCH_CODE: branchId,
            status: '1',
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',
          };

          // 4. Insert into PostgreSQL using the table name string
          // This bypasses Entity class checks and prevents CTCODE-style errors
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('operationmaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`OPERATIONMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migratePRIORITYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PRIORITYMASTER migration (Sector Mapping)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      // Oracle table is typically PRIORITYMASTER
      const result = await this.clientConn.execute(`SELECT * FROM PRIORITYMASTER ORDER BY CODE ASC`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data for duplicate check
      // Using raw query to remain independent of Entity metadata
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM prioritysectormaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawName = ele.NAME ? String(ele.NAME).trim() : null;
          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            // transformValue handles Marathi font symbols
            NAME: this.transformValue(rawName),

            // Priority sectors often use hierarchical codes (SUB1, SUB2, etc.)
            SUB1_CODE: ele.SUB1_CODE || null,
            SUB2_CODE: ele.SUB2_CODE || null,
            SUB3_CODE: ele.SUB3_CODE || null,

            // Tracking and Constraints
            BRANCH_CODE: branchId,
            status: '1',
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',
          };

          // 4. Insert into PostgreSQL using the table name string
          // This bypasses Entity class checks and prevents CTCODE-style errors
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('prioritysectormaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PRIORITYMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migratePURPOSEMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PURPOSEMASTER migration (Marathi Font & Metadata Bypass)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      // Oracle table is typically PURPOSEMASTER or LNPURPOSEMASTER
      const result = await this.clientConn.execute(`SELECT * FROM PURPOSEMASTER ORDER BY CODE ASC`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG records for duplicate check
      // Using raw query to remain independent of Entity metadata
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM purposemaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Handle common Oracle column names for Purpose
          const rawName = (ele.NAME || ele.PURPOSE_NAME || ele.DESCRIPTION)
            ? String(ele.NAME || ele.PURPOSE_NAME || ele.DESCRIPTION).trim()
            : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            // transformValue handles legacy Marathi font symbols (mojibake)
            NAME: this.transformValue(rawName),
            CODE: ele.CODE || ele.PURPOSE_CODE || null,

            // Loan purposes often link to priority sectors
            PRIORITY_CODE: ele.PRIORITY_CODE || null,

            // Mandatory tracking columns
            BRANCH_CODE: branchId,
            status: '1',
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',
          };

          // 4. Insert into PostgreSQL using the table name string
          // This bypasses Entity class checks and prevents CTCODE-style errors
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('purposemaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PURPOSEMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateREPORTTYPEMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting REPORTTYPEMASTER migration (Metadata Bypass)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM REPORTTYPEMASTER ORDER BY CODE ASC`);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG records for duplicate check
      const existingRows: { NAME: string }[] = await queryRunner.manager.query(
        `SELECT "NAME" FROM reporttypemaster`
      );
      const existingNames = new Set(
        existingRows.map((item) => String(item.NAME || '').trim().toLowerCase())
      );

      // 3. Get Default Branch ID
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Handle common Oracle column names for Report Type
          const rawName = (ele.NAME || ele.REPORT_TYPE_NAME || ele.DESCRIPTION)
            ? String(ele.NAME || ele.REPORT_TYPE_NAME || ele.DESCRIPTION).trim()
            : null;

          if (!rawName || existingNames.has(rawName.toLowerCase())) continue;

          const payload = {
            // transformValue handles legacy Marathi font symbols
            NAME: this.transformValue(rawName),
            CODE: ele.CODE || ele.REPORT_TYPE_CODE || null,

            // Categorization (e.g., Financial, Administrative, Audit)
            CATEGORY: ele.CATEGORY || 'GENERAL',

            // Mandatory tracking columns
            BRANCH_CODE: branchId,
            status: '1',
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',
          };

          // 4. Insert into PostgreSQL using the table name string
          // Bypasses Entity class checks to prevent metadata-related crashes
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('reporttypemaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`REPORTTYPEMASTER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  // ---------------- HOLIDAYSMASTER MIGRATION ----------------

  async migrateHOLIDAYSMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting HOLIDAYSMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM HOLIDAYSMASTER ORDER BY T_DATE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicate dates
      // Using raw query to avoid Entity/Metadata issues
      const existingRows: { T_DATE: Date }[] = await queryRunner.manager.query(
        `SELECT "T_DATE" FROM holidaysmaster`
      );

      // Create a Set of formatted strings for fast lookup
      const existingDates = new Set(
        existingRows.map(r => moment(r.T_DATE).format('YYYY-MM-DD'))
      );

      // 3. Get Default Branch ID from syspara
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branch = await queryRunner.manager.query(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`, [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Validation: Ensure we have a date
          if (!ele.T_DATE) continue;

          const formattedDate = moment(ele.T_DATE).format('YYYY-MM-DD');

          // Skip if this holiday date already exists in Postgres
          if (existingDates.has(formattedDate)) {
            continue;
          }

          const payload = {
            // Date formatting for Postgres
            T_DATE: moment(ele.T_DATE).format('DD/MM/YYYY'),

            // transformValue handles Marathi font transliteration (e.g., 'DVBW-TTYogeshEn')
            T_DESC: this.transformValue(ele.T_DESC || ele.DESCRIPTION || 'Bank Holiday'),

            BRANCH_CODE: branchId,

            // Standard status tracking if required by your Entity
            status: '1',
            SYSCHNG_LOGIN: ele.OFFICER_CODE || 'ADMIN',
          };

          // 4. Insert into PostgreSQL using Query Builder
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('holidaysmaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`HOLIDAYSMASTER: Successfully migrated ${inserted} holiday records.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Inner failure in HOLIDAYSMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  // ---------------- TRANINPUTHEAD MIGRATION ----------------
  async migrateTRANINPUTHEAD() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting TRANINPUTHEAD migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM TRANINPUTHEAD ORDER BY SERIAL_NO`);
      const rows = this.convertOracleRows(result as any);

      // 2. Duplicate Check
      // We check by SERIAL_NO and DESCRIPTION to prevent duplicate config entries
      const existingRows: { SERIAL_NO: number; DESCRIPTION: string }[] = await queryRunner.manager.query(
        `SELECT "SERIAL_NO", "DESCRIPTION" FROM traninputhead`
      );
      const existingKeys = new Set(
        existingRows.map(r => `${r.SERIAL_NO}_${String(r.DESCRIPTION || '').trim().toLowerCase()}`)
      );

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const rawDesc = ele.DESCRIPTION ? String(ele.DESCRIPTION).trim() : '';
          const key = `${ele.SERIAL_NO}_${rawDesc.toLowerCase()}`;

          if (existingKeys.has(key)) continue;

          const payload = {
            SERIAL_NO: ele.SERIAL_NO,
            SCHEME_TYPE: ele.SCHEME_TYPE,
            FIELD_AMOUNT: ele.FIELD_AMOUNT,
            FIELD_GL: ele.FIELD_GL,
            FIELD_INTEREST_DATE: ele.FIELD_INTEREST_DATE,
            FIELD_TRAN_TABLE: ele.FIELD_TRAN_TABLE,

            // GL Code handling: treat 0 as null for foreign key safety
            GL_CODE: ele.GL_CODE === 0 ? null : ele.GL_CODE,
            GL_CODE_FROM_SCHEME_FIELD: ele.GL_CODE_FROM_SCHEME_FIELD,

            // Transliteration for Description/Short Name
            DESCRIPTION: this.transformValue(rawDesc),
            SHORT_NAME: this.transformValue(ele.SHORT_NAME || ''),

            // Flag Conversion (0/1 to '0'/'1')
            CHECK_REQUIRE: ele.CHECK_REQUIRE == 0 ? '0' : '1',
            DRCR_APPLICABLE: ele.DRCR_APPLICABLE,
            INTEREST_DATE_INPUT: ele.INTEREST_DATE_INPUT == 0 ? '0' : '1',
            HEAD_TYPE: ele.HEAD_TYPE,
            IS_NOTING_REQUIRED: ele.IS_NOTING_REQUIRED == 0 ? '0' : '1',
            IS_GLBAL_MAINTAIN: ele.IS_GLBAL_MAINTAIN == 0 ? '0' : '1',

            // Mandatory tracking column
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('traninputhead')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`TRANINPUTHEAD: Successfully migrated ${inserted} input head configurations.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Inner failure in TRANINPUTHEAD loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  // ---------------- PGCOMMISSIONMASTER MIGRATION ----------------
  async migratePGCOMMISSIONMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PGCOMMISSIONMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM PGCOMMISSIONMASTER ORDER BY EFFECT_DATE ASC, SR_NO ASC
    `);

      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data to prevent duplicates
      // We check by EFFECT_DATE, SLAB_TYPE, and AMOUNT_FROM
      const existingRows: { EFFECT_DATE: Date; SLAB_TYPE: string; AMOUNT_FROM: number }[] =
        await queryRunner.manager.query(
          `SELECT "EFFECT_DATE", "SLAB_TYPE", "AMOUNT_FROM" FROM pgcommissionmaster`
        );

      const existingKeys = new Set(
        existingRows.map(r =>
          `${moment(r.EFFECT_DATE).format('YYYY-MM-DD')}_${r.SLAB_TYPE}_${Number(r.AMOUNT_FROM)}`
        )
      );

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('YYYY-MM-DD') : null;
          const amountFrom = Number(ele.AMOUNT_FROM) === -1 ? 1 : Number(ele.AMOUNT_FROM) || 0;
          const slabType = String(ele.SLAB_TYPE || '');

          const key = `${effectDateStr}_${slabType}_${amountFrom}`;

          // Skip duplicates
          if (existingKeys.has(key)) continue;

          const payload = {
            SR_NO: ele.SR_NO,
            EFFECT_DATE: ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : null,
            SLAB_TYPE: slabType,

            // Logic from source: if AMOUNT_FROM is -1, set to 1
            AMOUNT_FROM: amountFrom,
            AMOUNT_TO: Number(ele.AMOUNT_TO) || 0,

            PIGMY_COMMISSION_PERCENTAGE: Number(ele.PIGMY_COMMISSION_PERCENTAGE) || 0,
            COMM_AGAINST_LN_PERCENT: Number(ele.COMM_AGAINST_LN_PERCENT) || 0,
            PIGMY_SVR_CHARGE_RATE: Number(ele.PIGMY_SVR_CHARGE_RATE) || 0,

            // Set to null as per source logic for general master entries
            AC_ACNOTYPE: null,
            AC_TYPE: null,
            AC_NO: null,
            PG_AC_ACNOTYPE: null,
            PG_AC_TYPE: null,

            status: '1', // Default active status
          };

          // Insert into PostgreSQL
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('pgcommissionmaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PGCOMMISSIONMASTER: Successfully migrated ${inserted} commission slabs.`);

        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Inner failure in PGCOMMISSIONMASTER loop: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateSTOCKSTATEMENT() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting STOCKSTATEMENT migration (Schema ID Lookup Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM STOCKSTATEMENT`);
      const rows = this.convertOracleRows(result as any) as StockStatementOracleRow[];
      if (rows.length === 0) return { success: true, inserted: 0 };

      // 2. Load Mappings
      // Map S_APPL to the actual Postgres ID (e.g., 65200 -> 115)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityPGData = await queryRunner.manager.query<{ id: number; SECU_NAME: string }[]>(
        `SELECT id, "SECU_NAME" FROM securitymaster`
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- KEY FIX: Find the internal Postgres ID ---
          const oracleAcType = Number(ele.AC_TYPE);
          const postgresSchemaId = schemaMap.get(oracleAcType);

          // If the S_APPL code from Oracle isn't in your schemast table, 
          // set to null to avoid Foreign Key violation.
          const finalAcTypeId = postgresSchemaId || null;

          // Security lookup
          let internalSecuId: number | null = null;
          if (ele.SECU_CODE) {
            const match = securityPGData.find(s => s.id === Number(ele.SECU_CODE));
            internalSecuId = match ? match.id : null;
          }

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_TYPE: finalAcTypeId, // Uses the actual ID from your screenshot
            AC_NO: String(ele.AC_NO),
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,
            SUBMISSION_DATE: ele.SUBMISSION_DATE ? moment(ele.SUBMISSION_DATE).format('DD/MM/YYYY') : null,
            STATEMENT_DATE: ele.STATEMENT_DATE ? moment(ele.STATEMENT_DATE).format('DD/MM/YYYY') : null,
            RAW_MATERIAL: String(ele.RAW_MATERIAL || '0'),
            WORK_PROGRESS: String(ele.WORK_PROGRESS || '0'),
            FINISHED_GOODS: String(ele.FINISHED_GOODS || '0'),
            RAW_MARGIN: String(ele.RAW_MARGIN || '0'),
            WORK_MARGIN: String(ele.WORK_MARGIN || '0'),
            FINISHED_MARGIN: String(ele.FINISHED_MARGIN || '0'),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('stockstatement')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`STOCKSTATEMENT: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateVEHICLE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting VEHICLE migration (Final Stable Version)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM VEHICLE`);

      // ✅ FIX: Applying the interface here solves ESLint errors 
      // and provides property suggestions inside the loop.
      const rows = this.convertOracleRows(result as any) as VehicleOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle VEHICLE table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load PostgreSQL Mappings into Memory once
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- AC_TYPE LOOKUP (FOREIGN KEY SAFETY) ---
          const oracleAcType = Number(ele.AC_TYPE);
          const finalAcTypeId = schemaMap.get(oracleAcType) || null;

          // --- AC_NO LENGTH FIX (VARCHAR 15 SAFETY) ---
          const finalAcNo = String(ele.AC_NO);

          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) || null;

          // --- LOCAL EXTRACTION FOR ESLINT/MOMENT SAFETY ---
          const subDate = ele.SUBMISSION_DATE as string | null;
          const regDate = ele.RTO_REG_DATE as string | null;
          const acqDate = ele.AQUISITION_DATE as string | null;
          const remarkText = String(ele.REMARK || '');
          const makeText = String(ele.VEHICLE_MAKE || '');
          const supplierText = String(ele.SUPPLIER_NAME || '');

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            RTO_REG_DATE: regDate ? moment(regDate).format('DD/MM/YYYY') : null,
            AQUISITION_DATE: acqDate ? moment(acqDate).format('DD/MM/YYYY') : null,

            MARGIN: Number(ele.MARGIN) || 0,
            PURCHASE_PRICE: Number(ele.PURCHASE_PRICE) || 0,

            REMARK: this.transformValue(remarkText),
            VEHICLE_MAKE: this.transformValue(makeText),
            SUPPLIER_NAME: this.transformValue(supplierText),

            SECURITY_TYPE: ele.SECURITY_TYPE,
            MANUFACTURE_YEAR: ele.MANUFACTURE_YEAR,
            VEHICLE_NO: ele.VEHICLE_NO,
            CHASSIS_NO: ele.CHASSIS_NO,
            NEW_VEHICLE: ele.NEW_VEHICLE,
            NEW_EQUIPEMENT: ele.NEW_EQUIPEMENT,
            REF_ID: ele.REF_ID,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('vehicle')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`VEHICLE: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`VEHICLE Migration Error: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migratePLEDGESTOCK() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PLEDGESTOCK migration (Direct Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM PLEDGESTOCK`);

      // ✅ Apply the interface to satisfy ESLint and provide typing
      const rows = this.convertOracleRows(result as any) as PledgeStockOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle PLEDGESTOCK table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load PostgreSQL Mappings (Schema, Security, Branch)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- AC_TYPE LOOKUP (FOREIGN KEY SAFETY) ---
          const oracleAcType = Number(ele.AC_TYPE);
          const finalAcTypeId = schemaMap.get(oracleAcType) || null;

          // --- AC_NO LENGTH FIX (VARCHAR 15 SAFETY) ---
          const finalAcNo = String(ele.AC_NO);

          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) || null;

          // --- LOCAL EXTRACTION FOR ESLINT/MOMENT SAFETY ---
          const subDate = ele.SUBMISSION_DATE as string | null;
          const stateDate = ele.STATEMENT_DATE as string | null;
          const remarkText = String(ele.REMARK || '');

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            STATEMENT_DATE: stateDate ? moment(stateDate).format('DD/MM/YYYY') : null,

            // Numeric fields converted to string to match Entity (if defined as string)
            QUANTITY: String(ele.QUANTITY || '0'),
            RATE: String(ele.RATE || '0'),
            TOTAL_VALUE: String(ele.TOTAL_VALUE || '0'),
            MARGIN: String(ele.MARGIN || '0'),
            DRAWING_POWER: String(ele.DRAWING_POWER || '0'),

            // Transliteration / Cleaning
            REMARK: this.transformValue(remarkText),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            GODOWN_ADDRESS: ele.GODOWN_ADDRESS,
            ITEM_DESCRIPTION: ele.ITEM_DESCRIPTION,
            UNIT: ele.UNIT,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('pledgestock')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PLEDGESTOCK: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`PLEDGESTOCK Migration Error: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migratePLANTMACHINARY() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PLANTMACHINARY migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM PLANTMACHINARY`);

      // Using the Entity class for typing (ensure PLANTMACHINARY is imported)
      const rows = this.convertOracleRows(result as any) as Partial<PLANTMACHINARY>[];

      if (rows.length === 0) return { success: true, inserted: 0 };

      // 2. Load Mappings
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- AC_TYPE LOOKUP ---
          const oracleAcType = Number(ele.AC_TYPE);
          const finalAcTypeId = schemaMap.get(oracleAcType) || null;

          // --- VARCHAR(15) SAFETY ---
          const finalAcNo = String(ele.AC_NO || '');

          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) || null;

          // Local extraction for formatting/transliteration
          const subDate = ele.SUBMISSION_DATE as string | null;
          const acqDate = ele.AQUISITION_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_TYPE: finalAcTypeId,
            AC_NO: finalAcNo,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            // Dates
            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            AQUISITION_DATE: acqDate ? moment(acqDate).format('DD/MM/YYYY') : null,

            // Machine Specific Columns (Matched to your Entity)
            MACHINE_NAME: ele.MACHINE_NAME,
            MACHINE_TYPE: ele.MACHINE_TYPE,
            DISTINCTIVE_NO: ele.DISTINCTIVE_NO,
            SPECIFICATION: ele.SPECIFICATION,
            NEW_EQUIPEMENT: ele.NEW_EQUIPEMENT,

            // Numeric fields (Entity uses number)
            PURCHASE_PRICE: Number(ele.PURCHASE_PRICE) || 0,
            MARGIN: Number(ele.MARGIN) || 0,

            // Transliterated / Cleaned Text
            SUPPLIER_NAME: this.transformValue(String(ele.SUPPLIER_NAME || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('plantmachinary')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`PLANTMACHINARY: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateOWNDEPOSIT() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting OWNDEPOSIT migration (Clean Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM OWNDEPOSIT`);

      // ✅ Interface provides access to Oracle columns without ESLint errors
      const rows = this.convertOracleRows(result as any) as OwnDepositOracleRow[];

      if (rows.length === 0) return { success: true, inserted: 0 };

      // 2. Load Mappings
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const oracleAcType = Number(ele.AC_TYPE);
          const finalAcTypeId = schemaMap.get(oracleAcType) || null;
          const finalAcNo = String(ele.AC_NO || '');
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) || null;

          const subDate = ele.SUBMISSION_DATE as string | null;
          const remarkText = String(ele.REMARK || '');

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            // ✅ FIX: Populate the required DEPO columns
            // Use the same values as the main account if that is the intent
            DEPO_AC_NO: finalAcNo,
            DEPO_AC_TYPE: finalAcTypeId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,

            MARGIN: String(ele.MARGIN || '0'),
            RECEIPT_NO: ele.RECEIPT_NO,
            REMARK: this.transformValue(remarkText),
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('owndeposit')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`OWNDEPOSIT: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateOTHERSECURITY() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting OTHERSECURITY migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM OTHERSECURITY`);

      // ✅ Cast to our specific interface for property access
      const rows = this.convertOracleRows(result as any) as OtherSecurityOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle OTHERSECURITY table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- AC_TYPE LOOKUP (FOREIGN KEY SAFETY) ---
          const oracleAcType = Number(ele.AC_TYPE);
          const finalAcTypeId = schemaMap.get(oracleAcType) || null;

          // --- AC_NO LENGTH FIX (VARCHAR 15 SAFETY) ---
          const finalAcNo = String(ele.AC_NO || '');

          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) || null;

          // Local extraction for formatting/transliteration
          const subDate = ele.SUBMISSION_DATE as string | null;
          const remarkText = String(ele.REMARK || '');
          const particularText = String(ele.PARTICULARS || '');

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,

            // Numeric fields - adjust String/Number based on your Entity
            VALUATION_AMT: String(ele.VALUATION_AMT || '0'),
            MARGIN: String(ele.MARGIN || '0'),

            // Text fields with Transliteration
            PARTICULARS: this.transformValue(particularText),
            REMARK: this.transformValue(remarkText),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('othersecurity')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`OTHERSECURITY: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateMARKETSHARE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting MARKETSHARE migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM MARKETSHARE`);

      // ✅ Use the interface for typed property access
      const rows = this.convertOracleRows(result as any) as MarketShareOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle MARKETSHARE table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings (Schema, Security, Branch)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      const syspara = await queryRunner.manager.query<{ BRANCH_CODE: any }[]>(
        `SELECT "BRANCH_CODE" FROM syspara LIMIT 1`
      );
      const branch = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1`,
        [syspara[0]?.BRANCH_CODE || 101]
      );
      const branchId = branch[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- AC_TYPE LOOKUP (FOREIGN KEY SAFETY) ---
          const oracleAcType = Number(ele.AC_TYPE);
          const finalAcTypeId = schemaMap.get(oracleAcType) || null;

          // --- AC_NO LENGTH FIX (VARCHAR 15 SAFETY) ---
          const finalAcNo = String(ele.AC_NO || '');

          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) || null;

          // Local extraction for formatting/transliteration
          const subDate = ele.SUBMISSION_DATE as string | null;
          const remarkText = String(ele.REMARK || '');
          const companyText = String(ele.COMPANY_NAME || '');

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,

            // Numeric fields - Ensure these match your Entity types (String vs Number)
            NO_OF_SHARES: String(ele.NO_OF_SHARES || '0'),
            FACE_VALUE: String(ele.FACE_VALUE || '0'),
            MARKET_VALUE: String(ele.MARKET_VALUE || '0'),
            MARGIN: String(ele.MARGIN || '0'),

            // Text fields with Transliteration
            COMPANY_NAME: this.transformValue(companyText),
            CERTIFICATE_NO: ele.CERTIFICATE_NO,
            REMARK: this.transformValue(remarkText),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('marketshare')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`MARKETSHARE: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateLANDBUILDING() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting LANDBUILDING migration (Aggressive Branch Lookup)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      const result = await this.clientConn.execute(`SELECT * FROM LANDBUILDING`);
      const rows = this.convertOracleRows(result as any) as LandBuildingOracleRow[];
      if (rows.length === 0) return { success: true, inserted: 0 };

      // 1. Mappings
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(securityData.map((x) => [String(x.SECU_CODE), x.id]));

      // --- 2. IMPROVED BRANCH LOOKUP ---
      // Try 1: Look for the specific Branch Code '1' from your screenshot
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      // Try 2: If not found, just grab the first branch in the table (The "Emergency" fix)
      if (branchRes.length === 0) {
        this.logger.warn('Branch Code 1 not found. Defaulting to first available branch.');
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;

      // Final Check: If STILL null, the table is definitely empty
      if (!branchId) {
        throw new Error('FATAL: ownbranchmaster table is empty. Please check your Postgres table data.');
      }

      await queryRunner.startTransaction();

      try {
        let inserted = 0;
        for (const ele of rows) {
          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: String(ele.AC_NO),
            AC_TYPE: schemaMap.get(Number(ele.AC_TYPE)) ?? null,
            BRANCH_CODE: branchId,
            SECU_CODE: securityMap.get(String(ele.SECU_CODE)) ?? null,

            SUBMISSION_DATE: ele.SUBMISSION_DATE ? moment(ele.SUBMISSION_DATE).format('DD/MM/YYYY') : null,

            VALUE: Number(ele.VALUE) || 0,
            LOCATION: this.transformValue(String(ele.LOCATION || '')),
            AREA: String(ele.AREA || '0'),
            UNIT_AREA: String(ele.UNIT_AREA || ''),

            MARGIN: String(ele.MARGIN || '0'),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('landbuilding')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`LANDBUILDING: Successfully migrated ${inserted} records using Branch ID: ${branchId}`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateGOLDSILVER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting GOLDSILVER migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM GOLDSILVER`);
      const rows = this.convertOracleRows(result as any) as GoldSilverOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle GOLDSILVER table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      // 3. Aggressive Branch Lookup (Matches the Land/Building Fix)
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      if (branchRes.length === 0) {
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;
      if (!branchId) throw new Error('FATAL: ownbranchmaster is empty.');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- Lookups ---
          const finalAcTypeId = schemaMap.get(Number(ele.AC_TYPE)) ?? null;
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) ?? null;
          const finalAcNo = String(ele.AC_NO || '');

          // Dates
          const subDate = ele.SUBMISSION_DATE as string | null;
          const valDate = ele.VALUATION_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            VALUATION_DATE: valDate ? moment(valDate).format('DD/MM/YYYY') : null,

            // Numeric Weight & Value Fields
            GROSS_WEIGHT: String(ele.GROSS_WEIGHT || '0'),
            NET_WEIGHT: String(ele.NET_WEIGHT || '0'),
            VALUATION_AMT: String(ele.VALUATION_AMT || '0'),
            MARGIN: String(ele.MARGIN || '0'),
            QUANTITY: String(ele.QUANTITY || '0'),

            // Text Fields
            PURITY: ele.PURITY,
            ITEM_DESCRIPTION: this.transformValue(String(ele.ITEM_DESCRIPTION || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('goldsilver')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`GOLDSILVER: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateFURNITURE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting FURNITURE migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM FURNITURE`);
      const rows = this.convertOracleRows(result as any) as FurnitureOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle FURNITURE table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings (Schema & Security)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      // 3. Aggressive Branch Lookup (FK Safety)
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      if (branchRes.length === 0) {
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;
      if (!branchId) throw new Error('FATAL: ownbranchmaster is empty. Migration halted.');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- Mapping Lookups ---
          const finalAcTypeId = schemaMap.get(Number(ele.AC_TYPE)) ?? null;
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) ?? null;
          const finalAcNo = String(ele.AC_NO || '');

          // Dates
          const subDate = ele.SUBMISSION_DATE as string | null;
          const acqDate = ele.AQUISITION_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            AQUISITION_DATE: acqDate ? moment(acqDate).format('DD/MM/YYYY') : null,

            // Numeric Fields
            PURCHASE_PRICE: String(ele.PURCHASE_PRICE || '0'),
            VALUATION_AMT: String(ele.VALUATION_AMT || '0'),
            MARGIN: String(ele.MARGIN || '0'),
            QUANTITY: String(ele.QUANTITY || '0'),

            // Text Fields with Cleaning
            ITEM_DESCRIPTION: this.transformValue(String(ele.ITEM_DESCRIPTION || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('furniture')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`FURNITURE: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateFIREPOLICY() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting FIREPOLICY migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM FIREPOLICY`);
      const rows = this.convertOracleRows(result as any) as FirePolicyOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle FIREPOLICY table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings (Schema & Security)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      // 3. Aggressive Branch Lookup (FK Safety)
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      if (branchRes.length === 0) {
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;
      if (!branchId) throw new Error('FATAL: ownbranchmaster is empty.');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- Mapping Lookups ---
          const finalAcTypeId = schemaMap.get(Number(ele.AC_TYPE)) ?? null;
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) ?? null;
          const finalAcNo = String(ele.AC_NO || '');

          // Dates
          const subDate = ele.SUBMISSION_DATE as string | null;
          const expDate = ele.EXPIRY_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            EXPIRY_DATE: expDate ? moment(expDate).format('DD/MM/YYYY') : null,

            // Numeric Fields
            POLICY_AMT: String(ele.POLICY_AMT || '0'),
            PREMIUM_AMT: String(ele.PREMIUM_AMT || '0'),

            // Text Fields
            POLICY_NO: ele.POLICY_NO,
            INSURANCE_COMPANY: this.transformValue(String(ele.INSURANCE_COMPANY || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('firepolicy')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`FIREPOLICY: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateSECINSURANCE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting SECINSURANCE migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM SECINSURANCE`);
      const rows = this.convertOracleRows(result as any) as SecInsuranceOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle SECINSURANCE table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings (Schema & Security)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      // 3. Aggressive Branch Lookup (FK Safety)
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      if (branchRes.length === 0) {
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;
      if (!branchId) throw new Error('FATAL: ownbranchmaster is empty.');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- Mapping Lookups ---
          const finalAcTypeId = schemaMap.get(Number(ele.AC_TYPE)) ?? null;
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) ?? null;
          const finalAcNo = String(ele.AC_NO || '');

          // Dates
          const subDate = ele.SUBMISSION_DATE as string | null;
          const expDate = ele.EXPIRY_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            EXPIRY_DATE: expDate ? moment(expDate).format('DD/MM/YYYY') : null,

            // Numeric Fields
            POLICY_AMT: String(ele.POLICY_AMT || '0'),
            PREMIUM_AMT: String(ele.PREMIUM_AMT || '0'),

            // Text Fields
            POLICY_NO: ele.POLICY_NO,
            INSURANCE_COMPANY: this.transformValue(String(ele.INSURANCE_COMPANY || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('secinsurance')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`SECINSURANCE: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateGOVTSECULIC() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting GOVTSECULIC migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM GOVTSECULIC`);
      const rows = this.convertOracleRows(result as any) as GovtSecuLicOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle GOVTSECULIC table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings (Schema & Security)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      // 3. Aggressive Branch Lookup (FK Safety)
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      if (branchRes.length === 0) {
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;
      if (!branchId) throw new Error('FATAL: ownbranchmaster is empty.');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- Mapping Lookups ---
          const finalAcTypeId = schemaMap.get(Number(ele.AC_TYPE)) ?? null;
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) ?? null;
          const finalAcNo = String(ele.AC_NO || '');

          // Dates
          const subDate = ele.SUBMISSION_DATE as string | null;
          const matDate = ele.MATURITY_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            MATURITY_DATE: matDate ? moment(matDate).format('DD/MM/YYYY') : null,

            // Numeric/Value Fields
            FACE_VALUE: String(ele.FACE_VALUE || '0'),
            SURRENDER_VALUE: String(ele.SURRENDER_VALUE || '0'),
            MARGIN: String(ele.MARGIN || '0'),

            // Text Fields
            POLICY_NO: ele.POLICY_NO || ele.CERTIFICATE_NO, // Fallback if one is null
            ISSUING_AUTHORITY: this.transformValue(String(ele.ISSUING_AUTHORITY || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('govtseculic')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`GOVTSECULIC: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateBOOKDEBTS() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting BOOKDEBTS migration (Safe Mapping Mode)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM BOOKDEBTS`);
      const rows = this.convertOracleRows(result as any) as BookDebtsOracleRow[];

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle BOOKDEBTS table.');
        return { success: true, inserted: 0 };
      }

      // 2. Load Mappings (Schema & Security)
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map<number, number>(
        schemaData.map((x) => [Number(x.S_APPL), x.id])
      );

      const securityData = await queryRunner.manager.query<{ id: number; SECU_CODE: string }[]>(
        `SELECT id, "SECU_CODE" FROM securitymaster`
      );
      const securityMap = new Map<string, number>(
        securityData.map((x) => [String(x.SECU_CODE), x.id])
      );

      // 3. Aggressive Branch Lookup (FK Safety)
      let branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = '1' OR "CODE" = 1 LIMIT 1`
      );

      if (branchRes.length === 0) {
        branchRes = await queryRunner.manager.query<{ id: number }[]>(
          `SELECT id FROM ownbranchmaster LIMIT 1`
        );
      }

      const branchId = branchRes[0]?.id;
      if (!branchId) throw new Error('FATAL: ownbranchmaster is empty.');

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // --- Mapping Lookups ---
          const finalAcTypeId = schemaMap.get(Number(ele.AC_TYPE)) ?? null;
          const internalSecuId = securityMap.get(String(ele.SECU_CODE)) ?? null;
          const finalAcNo = String(ele.AC_NO || '');

          // Dates
          const subDate = ele.SUBMISSION_DATE as string | null;
          const valDate = ele.VALUATION_DATE as string | null;

          const payload = {
            AC_ACNOTYPE: ele.AC_ACNOTYPE,
            AC_NO: finalAcNo,
            AC_TYPE: finalAcTypeId,
            BRANCH_CODE: branchId,
            SECU_CODE: internalSecuId,

            SUBMISSION_DATE: subDate ? moment(subDate).format('DD/MM/YYYY') : null,
            VALUATION_DATE: valDate ? moment(valDate).format('DD/MM/YYYY') : null,

            // Numeric / Amount Fields
            TOTAL_BOOK_DEBTS: String(ele.TOTAL_BOOK_DEBTS || '0'),
            UPTO_90_DAYS: String(ele.UPTO_90_DAYS || '0'),
            OVER_90_DAYS: String(ele.OVER_90_DAYS || '0'),
            ELIGIBLE_DEBTS: String(ele.ELIGIBLE_DEBTS || '0'),
            MARGIN: String(ele.MARGIN || '0'),

            // Text Fields
            PARTY_NAME: this.transformValue(String(ele.PARTY_NAME || '')),
            REMARK: this.transformValue(String(ele.REMARK || '')),
            SECURITY_TYPE: ele.SECURITY_TYPE,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('bookdebts')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`BOOKDEBTS: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateTDSFORMSUBMIT() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting TDS Forms Migration (Interface Fixed)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. FETCH DATA
      const tdsResult = await this.clientConn.execute(`SELECT * FROM TDSFORMSUBMIT`);

      // Now TypeScript finds ITdsFormSubmit because it is defined above
      const tdsRows = this.convertOracleRows(tdsResult as any) as ITdsFormSubmit[];

      // 2. LOAD MAPPING DATA
      const dpMasterData = await queryRunner.manager.query<{ id: number; AC_NO: string; AC_ACNOTYPE: string }[]>(
        `SELECT id, "AC_NO", "AC_ACNOTYPE" FROM dpmaster`
      );
      const acToIdMap = new Map(dpMasterData.map(d => [`${d.AC_ACNOTYPE}-${d.AC_NO}`, d.id]));

      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1 OR "CODE" = '1' LIMIT 1`,
        [String(syspara[0].BRANCH_CODE)]
      );
      const branchId = branchRes[0]?.id || 1;

      await queryRunner.startTransaction();

      try {
        for (const t of tdsRows) {
          const parentId = acToIdMap.get(`${t.AC_ACNOTYPE}-${t.AC_NO}`);

          // Constructing object using the Interface
          const insertData = {
            DPMasterID: parentId || null,
            AC_NO: String(t.AC_NO),
            AC_ACNOTYPE: t.AC_ACNOTYPE,
            FIN_YEAR: t.FIN_YEAR,
            FORM_TYPE: t.FORM_TYPE,
            SUBMISSION_DATE: t.SUB_DATE ? moment(t.SUB_DATE).format('DD/MM/YYYY') : null,
            REMARKS: this.transformValue(t.REMARKS || ''),
            BRANCH_CODE: branchId,
            status: '1'
          };

          await queryRunner.manager.insert('tdsformsubmit', insertData);
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Success! Migrated ${tdsRows.length} TDS forms.`);
        return { success: true };

      } catch (err) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateTODTRAN() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting TODTRAN Migration (Using Entity Reference)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      const result = await this.clientConn.execute(`
      SELECT TODTRAN.*, SCHEMAST.S_APPL AS ACTYPE_PREFIX 
      FROM TODTRAN 
      LEFT JOIN SCHEMAST ON TODTRAN.AC_TYPE = SCHEMAST.S_APPL
    `);
      const rows = this.convertOracleRows(result as any);

      const syspara = await queryRunner.manager.query(`SELECT "BANK_CODE", "BRANCH_CODE" FROM syspara LIMIT 1`);
      const { BANK_CODE: bankCode, BRANCH_CODE: branchCodeStr } = syspara[0];
      const branchCode = Number(branchCodeStr);

      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      const branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1 OR "CODE" = 1 LIMIT 1`,
        [String(branchCode)]
      );
      const branchId = branchRes[0]?.id || 1;

      let totalInserted = 0;
      await queryRunner.startTransaction();

      try {
        for (const ele of rows) {
          if (!ele.AC_TYPE) continue;

          const postgresSchemaId = schemaMap.get(Number(ele.AC_TYPE));
          if (!postgresSchemaId) continue;

          const finalBankAcNo = this.generateBankAcNo(
            bankCode,
            branchCode,
            ele.ACTYPE_PREFIX || ele.AC_TYPE,
            Number(ele.AC_NO)
          );

          const isStandardTOD = String(ele.TOD_TYPE).trim().toUpperCase() === 'TOD';

          const payload: any = {
            AC_TYPE: postgresSchemaId,
            AC_NO: finalBankAcNo,
            BRANCH_CODE: branchId,
            RELEASE_DATE: ele.RELEASE_DATE ? moment(ele.RELEASE_DATE).format('DD/MM/YYYY') : undefined,
            AC_ODAMT: isStandardTOD ? (Number(ele.TOD_AMOUNT) || 0) : 0,
            AC_SODAMT: !isStandardTOD ? (Number(ele.TOD_AMOUNT) || 0) : 0,
            AC_ODDAYS: Number(ele.TOD_DAYS) || 0,
            AC_ODDATE: ele.TRAN_DATE ? moment(ele.TRAN_DATE).format('DD/MM/YYYY') : undefined,
            status: '1'
          };

          // --- FIX: Use Entity Class Reference instead of string "tod_tran" ---
          await queryRunner.manager.createQueryBuilder()
            .insert()
            .into(TODTRAN)
            .values(payload)
            .execute();

          totalInserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Success! Migrated ${totalInserted} TODTRAN records.`);
        return { success: true, totalInserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error in TODTRAN: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateSPECIALINSTRUCTION() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting SPECIALINSTRUCTION Migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      const instResult = await this.clientConn.execute(`
      SELECT SPECIALINSTRUCTION.*, SCHEMAST.S_APPL as ACTYPE_PREFIX 
      FROM SPECIALINSTRUCTION 
      LEFT JOIN SCHEMAST ON SPECIALINSTRUCTION.TRAN_ACTYPE = SCHEMAST.S_APPL 
      ORDER BY INSTRUCTION_DATE
    `);
      const instRows = this.convertOracleRows(instResult as any);

      const syspara = await queryRunner.manager.query(`SELECT "BANK_CODE", "BRANCH_CODE" FROM syspara LIMIT 1`);
      const { BANK_CODE: bankCode, BRANCH_CODE: branchCodeStr } = syspara[0];
      const branchCode = Number(branchCodeStr);

      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      const branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1 OR "CODE" = 1 LIMIT 1`,
        [String(branchCode)]
      );
      const branchId = branchRes[0]?.id || 1;

      let totalInserted = 0;
      await queryRunner.startTransaction();

      try {
        for (const ele of instRows) {
          if (!ele.TRAN_ACTYPE) continue;

          const postgresSchemaId = schemaMap.get(Number(ele.TRAN_ACTYPE));
          if (!postgresSchemaId) continue;

          const finalBankAcNo = this.generateBankAcNo(
            bankCode,
            branchCode,
            ele.ACTYPE_PREFIX || ele.TRAN_ACTYPE,
            Number(ele.TRAN_ACNO)
          );

          // FIX: Use undefined instead of null to satisfy TypeORM QueryDeepPartialEntity
          const payload: any = {
            INSTRUCTION_DATE: ele.INSTRUCTION_DATE ? moment(ele.INSTRUCTION_DATE).format('DD/MM/YYYY') : undefined,
            FROM_DATE: ele.FROM_DATE ? moment(ele.FROM_DATE).format('DD/MM/YYYY') : undefined,
            TO_DATE: ele.TO_DATE ? moment(ele.TO_DATE).format('DD/MM/YYYY') : undefined,
            REVOKE_DATE: ele.REVOKE_DATE ? moment(ele.REVOKE_DATE).format('DD/MM/YYYY') : undefined,

            TRAN_ACNO: finalBankAcNo,
            TRAN_ACTYPE: postgresSchemaId,

            DRCR_APPLY: ele.DRCR_APPLY || 'B',
            DETAILS: this.transformValue(ele.DETAILS || ''),
            IS_RESTRICT: ele.IS_RESTRICT == 0 ? '0' : '1',

            BRANCH_CODE: branchId,
            status: '1'
          };

          await queryRunner.manager.createQueryBuilder()
            .insert()
            .into(SPECIALINSTRUCTION)
            .values(payload)
            .execute();

          totalInserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${totalInserted} Special Instructions.`);
        return { success: true, totalInserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        // FIX: Type assertion for unknown error
        const error = err as Error;
        this.logger.error(`Loop Error: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateCASTMASTER() {

    if (!this.clientConn) throw new Error('Client DB not connected');
    if (!this.serverDB) throw new Error('Server DB not connected');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {

      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT * FROM CASTMASTER ORDER BY CODE
    `);

      const data = this.convertOracleRows(result as {
        rows: any[];
        metaData: { name: string }[];
      });

      // 2. Fetch existing PG data
      const existingCasts = await queryRunner.manager.find(CASTMASTER);

      // Normalize for safe comparison (VERY IMPORTANT)
      const normalize = (val: string) => val.trim().toLowerCase();

      const existingNames = new Set(
        existingCasts
          .map(c => c.NAME ? normalize(c.NAME) : null)
          .filter((name): name is string => !!name)
      );

      let inserted = 0;

      // 3. Loop through Oracle data
      for (const ele of data) {

        const rawName = ele.NAME ? String(ele.NAME) : null;
        if (!rawName) continue;

        const normalizedName = normalize(rawName);

        // Skip duplicates
        if (existingNames.has(normalizedName)) {
          this.logger.warn(`Skipping duplicate CAST: ${rawName}`);
          continue;
        }

        const newObj: Record<string, any> = {
          NAME: this.transformValue(rawName),
          CODE: ele.CODE ?? null
        };

        // Use entity (NOT string table name) ✅
        await queryRunner.manager.insert(CASTMASTER, newObj);

        inserted++;
      }

      // 4. Commit transaction
      await queryRunner.commitTransaction();

      this.logger.log(`CASTMASTER migration completed. Inserted: ${inserted}`);

      return { success: true, inserted };

    } catch (error) {

      await queryRunner.rollbackTransaction();
      this.logger.error('CASTMASTER migration failed', error);
      throw error;

    } finally {

      await queryRunner.release();
    }
  }

  async migrateSTANDINSTRUCTION() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting STANDINSTRUCTION Migration (Debit/Credit Mapping)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data with Schema Joins for both sides
      const result = await this.clientConn.execute(`
      SELECT SI.*, 
             S1.S_APPL AS DR_PREFIX, 
             S2.S_APPL AS CR_PREFIX
      FROM STANDINSTRUCTION SI
      LEFT JOIN SCHEMAST S1 ON SI.DR_ACTYPE = S1.S_APPL
      LEFT JOIN SCHEMAST S2 ON SI.CR_ACTYPE = S2.S_APPL
      ORDER BY SI.INSTRUCTION_DATE ASC
    `);
      const rows = this.convertOracleRows(result as any);

      // 2. Load Mapping Data from Postgres
      const syspara = await queryRunner.manager.query(`SELECT "BANK_CODE", "BRANCH_CODE" FROM syspara LIMIT 1`);
      const { BANK_CODE: bankCode, BRANCH_CODE: branchCodeStr } = syspara[0];
      const branchCode = Number(branchCodeStr);

      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      const branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1 OR "CODE" = 1 LIMIT 1`,
        [String(branchCode)]
      );
      const branchId = branchRes[0]?.id || 1;

      let totalInserted = 0;
      await queryRunner.startTransaction();

      try {
        for (const ele of rows) {
          // Find internal Postgres Schema IDs for Debit and Credit types
          const drSchemaId = schemaMap.get(Number(ele.DR_ACTYPE)) || null;
          const crSchemaId = schemaMap.get(Number(ele.CR_ACTYPE)) || null;

          // Generate 15-digit BANKACNO for both sides
          const drBankAcNo = ele.DR_AC_NO ? this.generateBankAcNo(
            bankCode, branchCode, ele.DR_PREFIX || ele.DR_ACTYPE, Number(ele.DR_AC_NO)
          ) : undefined;

          const crBankAcNo = ele.CR_AC_NO ? this.generateBankAcNo(
            bankCode, branchCode, ele.CR_PREFIX || ele.CR_ACTYPE, Number(ele.CR_AC_NO)
          ) : undefined;

          const payload: any = {
            BRANCH_CODE: branchId,
            INSTRUCTION_DATE: ele.INSTRUCTION_DATE ? moment(ele.INSTRUCTION_DATE).format('DD/MM/YYYY') : undefined,
            FROM_DATE: ele.FROM_DATE ? moment(ele.FROM_DATE).format('DD/MM/YYYY') : undefined,
            TO_DATE: ele.NEXT_EXE_DATE ? moment(ele.NEXT_EXE_DATE).format('DD/MM/YYYY') : undefined,
            LAST_EXEC_DATE: ele.LAST_EXEC_DATE ? moment(ele.LAST_EXEC_DATE).format('DD/MM/YYYY') : undefined,
            REVOKE_DATE: ele.REVOKE_DATE ? moment(ele.REVOKE_DATE).format('DD/MM/YYYY') : undefined,

            // Frequency Mapping: M=Monthly, Q=Quarterly, H=Half Yearly, Y/F=Yearly/Fixed
            SI_FREQUENCY: ele.SI_FREQUENCY,
            EXECUTION_DAY: ele.EXECUTION_DAY, // MB, ME, or specific day
            DAYS: Number(ele.SI_PERIOD) || 0,

            // Debit Side
            DR_ACTYPE: drSchemaId,
            DR_AC_NO: drBankAcNo,
            DR_PARTICULARS: this.transformValue(ele.DR_PARTICULARS || ''),

            // Credit Side
            CR_ACTYPE: crSchemaId,
            CR_AC_NO: crBankAcNo,
            CR_PARTICULARS: this.transformValue(ele.CR_PARTICULARS || ''),

            // Financials
            TRAN_AMOUNT: Number(ele.TRAN_AMOUNT) || 0,
            PAYINT_AMOUNT: Number(ele.PAYINT_AMOUNT) || 0,
            MIN_BAL: Number(ele.MIN_BAL) || 0,

            IS_AUTO_CUT_LNPGCOM: ele.IS_AUTO_CUT_LNPGCOM == 0 ? '0' : '1',
            status: '1'
          };

          await queryRunner.manager.createQueryBuilder()
            .insert()
            .into(STANDINSTRUCTION) // Entity reference avoids "relation does not exist"
            .values(payload)
            .execute();

          totalInserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Success! Migrated ${totalInserted} Standing Instructions.`);
        return { success: true, totalInserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error in STANDINSTRUCTION: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateINTINSTRUCTION() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting INTINSTRUCTION Migration (Fixed Null Constraints)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      const result = await this.clientConn.execute(`
      SELECT INT.*, 
             S1.S_APPL AS DR_PREFIX, 
             S2.S_APPL AS CR_PREFIX
      FROM INTINSTRUCTION INT
      LEFT JOIN SCHEMAST S1 ON INT.DR_ACTYPE = S1.S_APPL
      LEFT JOIN SCHEMAST S2 ON INT.CR_ACTYPE = S2.S_APPL
      ORDER BY INT.INSTRUCTION_DATE ASC
    `);
      const rows = this.convertOracleRows(result as any);

      const syspara = await queryRunner.manager.query(`SELECT "BANK_CODE", "BRANCH_CODE" FROM syspara LIMIT 1`);
      const { BANK_CODE: bankCode, BRANCH_CODE: branchCodeStr } = syspara[0];
      const branchCode = Number(branchCodeStr);

      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      const branchRes = await queryRunner.manager.query<{ id: number }[]>(
        `SELECT id FROM ownbranchmaster WHERE "CODE" = $1 OR "CODE" = 1 LIMIT 1`,
        [String(branchCode)]
      );
      const branchId = branchRes[0]?.id || 1;

      let totalInserted = 0;
      await queryRunner.startTransaction();

      try {
        for (const ele of rows) {
          const drSchemaId = schemaMap.get(Number(ele.DR_ACTYPE)) || null;
          const crSchemaId = schemaMap.get(Number(ele.CR_ACTYPE)) || null;

          // FIX: Ensure we have a valid account number or a safe fallback string
          // We use Number(ele.DR_AC_NO) to check if it's actually 0 or empty
          const drBankAcNo = (ele.DR_AC_NO && Number(ele.DR_AC_NO) !== 0)
            ? this.generateBankAcNo(bankCode, branchCode, ele.DR_PREFIX || ele.DR_ACTYPE, Number(ele.DR_AC_NO))
            : '000000000000000'; // 15-digit zero fallback to satisfy NOT NULL

          const crBankAcNo = (ele.CR_AC_NO && Number(ele.CR_AC_NO) !== 0)
            ? this.generateBankAcNo(bankCode, branchCode, ele.CR_PREFIX || ele.CR_ACTYPE, Number(ele.CR_AC_NO))
            : '000000000000000';

          const payload: any = {
            BRANCH_CODE: branchId,
            INSTRUCTION_DATE: ele.INSTRUCTION_DATE ? moment(ele.INSTRUCTION_DATE).format('DD/MM/YYYY') : undefined,
            FROM_DATE: ele.FROM_DATE ? moment(ele.FROM_DATE).format('DD/MM/YYYY') : undefined,
            NEXT_EXE_DATE: ele.NEXT_EXE_DATE ? moment(ele.NEXT_EXE_DATE).format('DD/MM/YYYY') : undefined,
            LAST_EXEC_DATE: ele.LAST_EXEC_DATE ? moment(ele.LAST_EXEC_DATE).format('DD/MM/YYYY') : undefined,
            REVOKE_DATE: ele.REVOKE_DATE ? moment(ele.REVOKE_DATE).format('DD/MM/YYYY') : undefined,

            EXECUTION_DAY: String(ele.EXECUTION_DAY || ''),
            SI_FREQUENCY: ele.SI_FREQUENCY || 'M',
            TRAN_TYPE: String(ele.TRAN_TYPE).trim().toUpperCase() === 'TR' ? 'Transfer' : 'Cash',

            // Debit Side
            DR_ACTYPE: drSchemaId,
            DR_AC_NO: drBankAcNo, // Guaranteed not null
            DR_PARTICULARS: this.transformValue(ele.DR_PARTICULARS || ''),

            // Credit Side
            CR_ACTYPE: crSchemaId,
            CR_AC_NO: crBankAcNo, // Guaranteed not null
            CR_PARTICULARS: this.transformValue(ele.CR_PARTICULARS || ''),

            ADV_NARRATION: this.transformValue(ele.ADV_NARRATION || ''),
            status: '1'
          };

          await queryRunner.manager.createQueryBuilder()
            .insert()
            .into(INTINSTRUCTION)
            .values(payload)
            .execute();

          totalInserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Success! Migrated ${totalInserted} Interest Instructions.`);
        return { success: true, totalInserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error in INTINSTRUCTION: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }



  async migrateintrateTD() {
    if (!this.clientConn || !this.serverDB) throw new Error('Databases not connected');
    this.logger.log('Starting Flat Interest Rate Migration (9 Rows)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch ALL 9 rows from Oracle (Removed DISTINCT)
      const result = await this.clientConn.execute(`SELECT * FROM INTRATETD`);
      const rows = this.convertOracleRows(result as any);

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const row of rows) {
          const effectDateStr = row.EFFECT_DATE ? moment(row.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          const payload: any = {
            ACNOTYPE: row.ACTYPE ? Number(row.ACTYPE) : null,
            TYPE: row.ACNOTYPE,
            INT_CATEGORY: Number(row.INT_CATEGORY),
            EFFECT_DATE: effectDateStr,
            // Mapping the slab columns directly into the main table
            FROM_DAYS: Number(row.FROM_DAYS) || 0,
            FROM_MONTHS: Number(row.FROM_MONTHS) || 0,
            TO_DAYS: Number(row.TO_DAYS) || 0,
            TO_MONTHS: Number(row.TO_MONTHS) || 0,
            INT_RATE: Number(row.INT_RATE) || 0,
            PENAL_INT_RATE: Number(row.PENAL_INT_RATE) || 0,
            status: '1'
          };

          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into(INTRATETD)
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Migration Finished: Inserted exactly ${inserted} flat rows.`);
        return { success: true, totalInserted: inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration Failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateINTRATETDMULTI() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting Multi-Tier TD Interest Rate Migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. FETCH FROM ORACLE
      // Corrected table name based on your likely Oracle schema
      const result = await this.clientConn.execute(`
      SELECT * FROM INTRATETDMULTI
    `);
      const rows = this.convertOracleRows(result as any);

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle INTRATETDMULTI table.');
        return { success: true, inserted: 0 };
      }

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          // 2. CONSTRUCT PAYLOAD
          // Note: Map these fields to your Postgres INTRATETDMULTI Entity columns
          const payload: any = {
            // If this table in Postgres is also flat:
            ACNOTYPE: Number(ele.ACTYPE) || null,
            TYPE: ele.ACNOTYPE,
            INT_CATEGORY: Number(ele.INT_CATEGORY),
            EFFECT_DATE: effectDateStr,
            INT_RATE: Number(ele.INT_RATE) || 0,
            status: '1',
            // Add other columns if they exist in your multi-tier table
          };

          // 3. INSERT INTO POSTGRES
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('intratetdmulti') // Verify this table name in pgAdmin
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} Multi-Tier records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateDEPRRATE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting Depreciation Rate Migration (FK Bypass & ESLint Clean)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch from Oracle
      const result = await this.clientConn.execute(`SELECT * FROM DEPRRATE ORDER BY EFFECT_DATE ASC`);
      const rows = this.convertOracleRows(result as any);

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle DEPRRATE table.');
        return { success: true, inserted: 0 };
      }

      await queryRunner.startTransaction();

      try {
        // 2. DISABLE ALL TRIGGERS (Bypass FK checks)
        await queryRunner.manager.query(`ALTER TABLE "deprrate" DISABLE TRIGGER ALL`);

        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          await queryRunner.manager.query(
            `INSERT INTO "deprrate" ("DEPR_RATE", "EFFECT_DATE", "CATEGORY") 
           VALUES ($1, $2, $3)`,
            [
              Number(ele.DEPR_RATE) || 0,
              effectDateStr,
              ele.CATEGORY
            ]
          );

          inserted++;
        }

        // 3. RE-ENABLE TRIGGERS
        await queryRunner.manager.query(`ALTER TABLE "deprrate" ENABLE TRIGGER ALL`);

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        // FIX: Cleaned up the empty catch block and unused 'e'
        try {
          await queryRunner.manager.query(`ALTER TABLE "deprrate" ENABLE TRIGGER ALL`);
        } catch (cleanupError) {
          this.logger.error('Failed to re-enable triggers after main error:', cleanupError);
        }

        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration Loop Failure: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateINTRATELOAN() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting Loan Interest Rate Migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. FETCH FROM ORACLE
      const result = await this.clientConn.execute(`
      SELECT * FROM INTRATELOAN ORDER BY EFFECT_DATE ASC
    `);
      const rows = this.convertOracleRows(result as any);

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle INTRATELOAN table.');
        return { success: true, inserted: 0 };
      }

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          const payload: any = {
            // FIX: In your Postgres schema, ACNOTYPE is an Integer.
            // We map the Oracle ACTYPE (e.g. 20100) to this column.
            ACNOTYPE: Number(ele.ACTYPE) || null,

            // If your table has a separate column for the "LN" string, use it here.
            // Otherwise, we skip sending "LN" to an integer column.
            // TYPE: ele.ACNOTYPE, 

            INT_CATEGORY: Number(ele.INT_CATEGORY),
            EFFECT_DATE: effectDateStr,
            INT_RATE: Number(ele.INT_RATE) || 0,
            PENAL_INT_RATE: Number(ele.PENAL_INT_RATE) || 0,
            status: '1'
          };

          // 2. INSERT INTO POSTGRES
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('intrateloan')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} Loan Interest records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateINTRATEPATSCHEMES() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting PAT Interest Scheme Migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. FETCH FROM ORACLE
      // Fix: Table name updated to match your schema's standard naming convention
      const result = await this.clientConn.execute(`
      SELECT * FROM INTRATEPATSCHEMES ORDER BY EFFECT_DATE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle INTRATEPATSCHEMES table.');
        return { success: true, inserted: 0 };
      }

      // 2. LOAD MAPPINGS
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          // Map the numeric Oracle AC_TYPE (e.g., 20200) to the Postgres Schema ID
          const postgresSchemaId = schemaMap.get(Number(ele.AC_TYPE)) || null;

          const payload: any = {
            AC_TYPE: postgresSchemaId,           // Internal Postgres ID
            INT_CATEGORY: Number(ele.INT_CATEGORY),
            EFFECT_DATE: effectDateStr,

            // These fields are specific to the PAT table slabs
            MONTHS: Number(ele.MONTHS) || 0,
            DAYS: Number(ele.DAYS) || 0,
            INT_RATE: Number(ele.INT_RATE) || 0,

            status: '1'
          };

          // 3. INSERT INTO POSTGRES
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('intratepatschemes') // Ensure this matches your table name in pgAdmin
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} PAT Interest records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error: ${error.message}`);
        throw err;
      }
    } catch (err: any) {
      this.logger.error(`Top-level Error: ${err.message}`);
      throw err;
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migratePREMATULESSRATE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting Premature Less Rate Migration (Penalty Logic)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. FETCH FROM ORACLE
      // Fix: Table name updated to PREMATULESSRATE to match your schema pattern
      const result = await this.clientConn.execute(`
      SELECT * FROM PREMATULESSRATE ORDER BY EFFECT_DATE ASC
    `);

      const rows = this.convertOracleRows(result as any);

      if (rows.length === 0) {
        this.logger.warn('No records found in Oracle PREMATULESSRATE table.');
        return { success: true, inserted: 0 };
      }

      // 2. LOAD MAPPINGS
      const schemaData = await queryRunner.manager.query<{ id: number; S_APPL: number }[]>(
        `SELECT id, "S_APPL" FROM schemast`
      );
      const schemaMap = new Map(schemaData.map((x) => [Number(x.S_APPL), x.id]));

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          // Map Oracle ACTYPE (e.g. 30500) to Postgres Schema ID
          const postgresSchemaId = schemaMap.get(Number(ele.ACTYPE)) || null;

          const payload: any = {
            ACNOTYPE: postgresSchemaId,
            EFFECT_DATE: effectDateStr,

            // Penalty Rules
            FROM_MONTHS: Number(ele.FROM_MONTHS) || 0,
            TO_MONTHS: Number(ele.TO_MONTHS) || 0,
            LESS_INT_RATE: Number(ele.LESS_INT_RATE) || 0,

            status: '1'
          };

          // 3. INSERT INTO POSTGRES
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('prematulessrate') // Ensure this matches your Postgres table name
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} Premature Less Rate records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error: ${error.message}`);
        throw err;
      }
    } catch (err: any) {
      this.logger.error(`Top-level Error: ${err.message}`);
      throw err;
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateINTRATESBPG() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting SB & Pigmy Interest Rate Migration (Logic-Based Mapping)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`SELECT * FROM INTRATESBPG`);
      const rows = this.convertOracleRows(result as any);

      // 2. Define Lookup Interface for ESLint
      interface SchemaLookup {
        id: number;
        S_ACNOTYPE: string;
        S_APPL: string;
      }

      // Fetch Postgres IDs to avoid "Integer" syntax errors
      const schemaData = await queryRunner.manager.query<SchemaLookup[]>(
        `SELECT id, "S_ACNOTYPE", "S_APPL" FROM schemast`
      );

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const effectDateStr = ele.EFFECT_DATE ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY') : undefined;

          // This is the exact string from Oracle ('PG' or 'SB')
          const oracleExactString = String(ele.ACNOTYPE || '').trim().toUpperCase();

          // 3. Script Logic: Find the corresponding Numeric ID
          let match = schemaData.find(s => String(s.S_ACNOTYPE).trim().toUpperCase() === oracleExactString);

          // Fallback for 'PG' if S_ACNOTYPE doesn't match
          if (!match && oracleExactString === 'PG') {
            match = schemaData.find(s => String(s.S_APPL).startsWith('3') || String(s.S_APPL).startsWith('4'));
          }

          // 4. MAPPING PAYLOAD
          const payload: any = {
            // Put the Number (ID) here to satisfy the Postgres Integer requirement
            ACNOTYPE: match ? match.id : null,

            // Put the EXACT Oracle String ("PG"/"SB") here (already a Varchar column)
            TYPE: oracleExactString,

            INT_CATEGORY: Number(ele.INT_CATEGORY),
            EFFECT_DATE: effectDateStr,
            INT_RATE: String(ele.INT_RATE || '0'),
            status: '1'
          };

          // 5. INSERT
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('intratesbpg')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} records using script logic.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration Failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateSECURITYMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting Security Master Migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. FETCH FROM ORACLE
      const result = await this.clientConn.execute(`SELECT * FROM SECURITYMASTER`);
      const rows = this.convertOracleRows(result as any);

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          const payload: any = {
            // FIX: Use the actual SECU_CODE from Oracle, not a loop index or auto-id
            SECU_CODE: Number(ele.SECU_CODE),
            SECU_NAME: ele.SECU_NAME || 'Unknown',

            // Mapping other columns visible in your screenshots
            MARGIN: Number(ele.MARGIN) || 0,
            FIRE_POLICY: Number(ele.FIRE_POLICY) || 0,
            MARKET_SHARE: Number(ele.MARKET_SHARE) || 0,
            BOOK_DEBTS: Number(ele.BOOK_DEBTS) || 0,
            PLEDGE_STOCK: Number(ele.PLEDGE_STOCK) || 0,
            STOCK_STATEMENT: Number(ele.STOCK_STATEMENT) || 0,
            GOVT_SECU_LIC: Number(ele.GOVT_SECU_LIC) || 0,
            PLANT_MACHINERY: Number(ele.PLANT_MACHINARY) || 0, // Note spelling in Oracle screenshot
            FURNITURE_FIXTURE: Number(ele.FURNITURE_FIXTURE) || 0,
            VEHICLE: Number(ele.VEHICLE) || 0,
            OWN_DEPOSIT: Number(ele.OWN_DEPOSIT) || 0,
            LAND_BUILDING: Number(ele.LAND_BUILDING) || 0,
            GOLD_SILVER: Number(ele.GOLD_SILVER) || 0,
            OTHER_SECURITY: Number(ele.OTHER_SECURITY) || 0,
            CUST_INSURANCE: Number(ele.CUST_INSURANCE) || 0,

            status: '1'
          };

          // 2. INSERT INTO POSTGRES
          await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('securitymaster')
            .values(payload)
            .execute();

          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Successfully migrated ${inserted} records matching Oracle SECU_CODE.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        this.logger.error(`Loop Error: ${(err as Error).message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateTDSRATE() {
    if (!this.clientConn || !this.serverDB) throw new Error('DB not connected');
    this.logger.log('Starting TDSRATE migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Oracle Data
      const result = await this.clientConn.execute(`
      SELECT DISTINCT FIN_YEAR, INTEREST_AMOUNT, TDS_RATE, SURCHARGE_RATE, EFFECT_DATE 
      FROM TDSRATE 
      ORDER BY EFFECT_DATE ASC
    `);
      const rows = this.convertOracleRows(result as any);

      // 2. Fetch existing PG data from TDSRATE (Fixes Error 2339)
      // You were previously calling TDSFORMSUBMIT which doesn't have EFFECT_DATE
      const pgData = await queryRunner.manager.find(TDSRATE);

      await queryRunner.startTransaction();

      try {
        let inserted = 0;

        for (const ele of rows) {
          // Format the date or provide an empty string fallback (Fixes Error 2322)
          const effectDateFormatted: string = ele.EFFECT_DATE
            ? moment(ele.EFFECT_DATE).format('DD/MM/YYYY')
            : ''; // Use '' instead of null to satisfy strict string type

          // Duplicate Check using pgData from TDSRATE
          const isDuplicate = pgData.some(pgItem =>
            pgItem.FIN_YEAR === ele.FIN_YEAR &&
            pgItem.EFFECT_DATE === effectDateFormatted
          );

          if (isDuplicate) continue;

          // 3. Construct Payload
          const newTdsRate = new TDSRATE();
          newTdsRate['FIN_YEAR'] = ele.FIN_YEAR;
          newTdsRate['INTEREST_AMOUNT'] = Number(ele.INTEREST_AMOUNT) || 0;
          newTdsRate['TDS_RATE'] = Number(ele.TDS_RATE) || 0;
          newTdsRate['SURCHARGE_RATE'] = Number(ele.SURCHARGE_RATE) || 0;

          // Fix for Type 'string | null' is not assignable to type 'string'
          newTdsRate['EFFECT_DATE'] = effectDateFormatted;
          newTdsRate['status'] = '1';

          await queryRunner.manager.save(TDSRATE, newTdsRate);
          inserted++;
        }

        await queryRunner.commitTransaction();
        this.logger.log(`TDSRATE: Successfully migrated ${inserted} records.`);
        return { success: true, inserted };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Loop Error: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }

  async migrateNPAMASTER() {
    if (!this.clientConn || !this.serverDB) throw new Error('Databases not connected');
    this.logger.log('Starting full NPAMASTER migration...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch ALL rows from Oracle
      const result = await this.clientConn.execute(`SELECT * FROM NPAMASTER ORDER BY EFFECT_DATE ASC`);
      const allRows = this.convertOracleRows(result as any);

      if (allRows.length === 0) {
        this.logger.warn('No records found in Oracle NPAMASTER table.');
        return { success: true, masterInserted: 0, slabsInserted: 0 };
      }

      // 2. Fetch existing PG data to prevent duplicates
      const existingMasters = await queryRunner.manager.find(NPAMASTER);

      await queryRunner.startTransaction();

      try {
        let masterCount = 0;
        let slabCount = 0;

        // 3. Group Oracle data by Unique Master (Date + BaseDays)
        const masterGroups = new Map<string, any[]>();

        for (const row of allRows) {
          const dateStr = row.EFFECT_DATE ? moment(row.EFFECT_DATE).format('DD/MM/YYYY') : '';
          const groupKey = `${dateStr}_${row.NPA_BASE_DAYS}`;

          // FIX: Ensure group is initialized to resolve TS2532 "Object is possibly undefined"
          let group = masterGroups.get(groupKey);
          if (!group) {
            group = [];
            masterGroups.set(groupKey, group);
          }
          group.push(row);
        }

        // 4. Iterate through each unique Master group
        for (const [key, slabs] of masterGroups) {
          const keyParts = key.split('_');
          const effectDate = keyParts[0];
          const baseDays = keyParts[1];

          // Skip if this specific Master already exists in Postgres
          const exists = existingMasters.some(m =>
            String(m.EFFECT_DATE).trim() === String(effectDate).trim() &&
            Number(m.NPA_BASE_DAYS) === Number(baseDays)
          );

          if (exists) {
            this.logger.log(`Skipping existing Master: ${effectDate} / ${baseDays}`);
            continue;
          }

          // --- INSERT MASTER ---
          const npaMaster = new NPAMASTER();
          npaMaster['NPA_BASE_DAYS'] = Number(baseDays);
          npaMaster['EFFECT_DATE'] = effectDate;
          npaMaster['status'] = '1';

          const savedMaster = await queryRunner.manager.save(NPAMASTER, npaMaster);
          masterCount++;

          // --- INSERT RELATED SLABS ---
          for (const s of slabs) {
            const slab = new NPACLASSIFICATION();
            slab['SERIAL_NO'] = s.SERIAL_NO;
            slab['NPA_CLASS'] = s.NPA_CLASS;
            slab['SUB_CLASS_NO'] = s.SUB_CLASS_NO;
            // transformValue handles legacy font conversion for descriptions
            slab['NPA_DESCRIPTION'] = this.transformValue(s.NPA_DESCRIPTION || '');
            slab['FROM_MONTHS'] = Number(s.FROM_MONTHS) || 0;
            slab['FROM_DAYS'] = Number(s.FROM_DAYS) || 0;
            slab['TO_MONTHS'] = Number(s.TO_MONTHS) || 0;
            slab['TO_DAYS'] = Number(s.TO_DAYS) || 0;
            slab['SECURED_PERCENT'] = Number(s.SECURED_PERCENT) || 0;
            slab['UNSECURED_PERCENT'] = Number(s.UNSECURED_PERCENT) || 0;

            // Link child to the specific Master ID we just generated
            slab['NPAClassID'] = savedMaster.id;
            slab['status'] = '1';

            await queryRunner.manager.save(NPACLASSIFICATION, slab);
            slabCount++;
          }
        }

        await queryRunner.commitTransaction();
        this.logger.log(`Migration Finished: ${masterCount} Masters and ${slabCount} Slabs.`);

        return {
          success: true,
          masterInserted: masterCount,
          slabsInserted: slabCount
        };

      } catch (err: unknown) {
        if (queryRunner.isTransactionActive) await queryRunner.rollbackTransaction();
        const error = err as Error;
        this.logger.error(`Migration loop failed: ${error.message}`);
        throw err;
      }
    } finally {
      if (!queryRunner.isReleased) await queryRunner.release();
    }
  }


  async migrateDEADSTOCKHEADER() {
    if (!this.clientConn || !this.serverDB) throw new Error('Databases not connected');
    this.logger.log('Starting DEADSTOCKHEADER & DETAIL migration (Strict Mentor Logic)...');

    const queryRunner = this.serverDB.createQueryRunner();
    await queryRunner.connect();

    try {
      // 1. Fetch Header Records with Schema Join (Mentor Logic)
      const result = await this.clientConn.execute(`
        SELECT DEADSTOCKHEADER.*, SCHEMAST.S_APPL AS ACTYPE 
        FROM DEADSTOCKHEADER 
        LEFT JOIN SCHEMAST ON DEADSTOCKHEADER.TRANSFER_ACTYPE = SCHEMAST.S_APPL 
        ORDER BY DEADSTOCKHEADER.TRAN_DATE, DEADSTOCKHEADER.TRAN_NO
      `);
      const rows = this.convertOracleRows(result as any);

      // Setup Constants
      const syspara = await queryRunner.manager.query(`SELECT "BRANCH_CODE" FROM syspara LIMIT 1`);
      const branchRes = await queryRunner.manager.query(`SELECT id FROM ownbranchmaster WHERE "CODE" = $1 LIMIT 1`, [String(syspara[0]?.BRANCH_CODE || 101)]);
      const branchId = branchRes[0]?.id || 1;

      for (const item of rows) {
        await queryRunner.startTransaction();
        try {
          const date = item.TRAN_DATE ? moment(item.TRAN_DATE).format('DD/MM/YYYY') : null;

          // --- STEP 1: PREPARE AND SAVE HEADER ---
          const headerPayload: any = {
            TRAN_YEAR: item.TRAN_YEAR,
            TRAN_DATE: date,
            TRAN_NO: item.TRAN_NO,
            BRANCH_CODE: branchId,
            TRAN_TIME: item.TRAN_TIME,
            TRAN_TYPE: item.TRAN_TYPE,
            TRAN_MODE: item.TRAN_MODE,
            TRAN_DRCR: item.TRAN_DRCR,
            TRAN_AMOUNT: Number(item.TRAN_AMOUNT) || 0,
            TRAN_GLACNO: item.TRAN_GLACNO,
            TRANSFER_ACNOTYPE: item.TRANSFER_ACNOTYPE,
            TRANSFER_ACTYPE: item.ACTYPE, // From the Join
            TRANSFER_ACNO: item.TRANSFER_ACNOTYPE === 'GL' ? item.TRANSFER_ACNO : String(Number(item.TRANSFER_ACNO) + 100000),
            TRAN_SUPPLIER_NAME: this.transformValue(item.TRAN_SUPPLIER_NAME),
            NARRATION: this.transformValue(item.NARRATION?.replace("\x00", "")),
            USER_CODE: item.USER_CODE || 'SYSTEM',
            OFFICER_CODE: item.OFFICER_CODE,
            status: '1',
            SYSCHNG_LOGIN: item.OFFICER_CODE || 'ADMIN',
            TRAN_STATUS: item.TRAN_STATUS === 'UP' ? 0 : item.TRAN_STATUS === 'PS' ? 1 : 2
          };

          const savedHeader = await queryRunner.manager
            .createQueryBuilder()
            .insert()
            .into('deadstockheader')
            .values(headerPayload)
            .returning('id')
            .execute();

          const parentHeaderId = savedHeader.raw[0].id;

          // --- STEP 2: NESTED DETAIL FETCH (Mentor Logic) ---
          if (date) {
            const detailResult = await this.clientConn.execute(`
              SELECT * FROM DEADSTOCKDETAIL 
              WHERE TRAN_DATE = TO_DATE('${date}', 'DD/MM/YYYY') 
              AND TRAN_NO = ${item.TRAN_NO} 
              ORDER BY SERIAL_NO
            `);
            const detailRows = this.convertOracleRows(detailResult as any);

            for (const ele of detailRows) {
              // Mentor Logic: Lookup Item Master for name/type
              const itemData = await queryRunner.manager.query(
                `SELECT "ITEM_NAME", "ITEM_TYPE" FROM itemmaster WHERE "ITEM_CODE" = $1 LIMIT 1`,
                [String(ele.ITEM_CODE)]
              );

              const detailPayload = {
                TRAN_YEAR: ele.TRAN_YEAR,
                TRAN_DATE: ele.TRAN_DATE ? moment(ele.TRAN_DATE).format('DD/MM/YYYY') : null,
                TRAN_NO: ele.TRAN_NO,
                SERIAL_NO: ele.SERIAL_NO,
                TRAN_DRCR: ele.TRAN_DRCR,
                ITEM_CODE: ele.ITEM_CODE,
                ITEM_TYPE: Number(itemData[0]?.ITEM_TYPE) || 1, // Looked up from Master
                ITEM_NAME: itemData[0]?.ITEM_NAME || `ITEM-${ele.ITEM_CODE}`,
                ITEM_RATE: Number(ele.ITEM_RATE) || 0,
                ITEM_QTY: Number(ele.ITEM_QTY) || 0,
                TRAN_AMOUNT: Number(ele.TRAN_AMOUNT) || 0,
                DEPR_RATE: Number(ele.DEPR_RATE) || 0,
                BRANCH_CODE: branchId,
                deadstockHeaderId: parentHeaderId, // Linked to parent!
                status: '1'
              };

              await queryRunner.manager.insert('deadstockdetail', detailPayload);
            }
          }

          await queryRunner.commitTransaction();
        } catch (err: unknown) {
          this.logger.error('Migration failed during transaction', err as any);
          throw err;
        }
      }
      this.logger.log('Migration Completed.');
      return { success: true };
    } finally {
      await queryRunner.release();
    }
  }


  /* ===================== METADATA / DISCOVERY (SERVER SIDE) ===================== */

  async getServerDatabases(config: any): Promise<string[]> {
    // 1. We use the existing getServerDataSource to get a temporary connection
    // We connect to the default 'postgres' database to see the others
    const tempDS = await this.dbService.getServerDataSource({
      ...config,
      database: 'postgres'
    });

    try {
      // 2. Run the Postgres-specific query directly here
      const res = await tempDS.query(
        `SELECT datname as name FROM pg_database WHERE datistemplate = false AND datname != 'postgres'`
      );

      // 3. Clean up the connection
      await this.dbService.closeServerConnection();

      return res.map((d: any) => d.name);
    } catch (error) {
      await this.dbService.closeServerConnection();
      this.logger.error('Finalize error', error as any);
      throw error;
    }
  }

  async getPrimaryTableNames(): Promise<string[]> {
    if (!this.serverDB || !this.serverDB.isInitialized) {
      throw new Error('Server DB not connected');
    }

    // Query Postgres information_schema directly
    const res = await this.serverDB.query(
      `SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name`
    );
    return res.map((r: any) => r.table_name);
  }

  async getAllColumnsNames(tableName: string): Promise<string[]> {
    if (!this.serverDB || !this.serverDB.isInitialized) {
      throw new Error('Server DB not connected');
    }

    // Force the incoming tableName to lowercase to match the 'syspara' we see in your screenshot
    const searchName = tableName.toLowerCase();

    const res = await this.serverDB.query(
      `SELECT attname AS column_name
       FROM pg_attribute
       WHERE attrelid = $1::regclass
       AND attnum > 0
       AND NOT attisdropped
       ORDER BY attnum`,
      [searchName]
    );

    this.logger.log(`Internal Catalog fetch for ${searchName}: Found ${res.length} columns.`);

    return res.map((c: any) => c.column_name);
  }


  async getClientTableNames(): Promise<string[]> {
    if (!this.clientConn) throw new Error('Client (Oracle) not connected');
    // We pass the raw Oracle connection to the DatabaseService helper
    return await this.dbService.getTableNames(this.clientConn);
  }

  async getClientColumns(tableName: string): Promise<string[]> {
    if (!this.clientConn) throw new Error('Client (Oracle) not connected');
    // We pass the raw Oracle connection and table name to the helper
    return await this.dbService.getColumnNames(this.clientConn, tableName);
  }




}
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, Unique, UpdateDateColumn, Index, JoinColumn, ManyToOne } from 'typeorm';
//import { CUSTOMERADDRESS } from './customer-address.entity'
import { SHMASTER } from './share-master.entity';
//import { TDSFORMSUBMIT } from './tds-form.entity'
//import { CUSTDOCUMENT } from './document.entity'
import { LNMASTER } from './term-loan-master.entity'
import { DPMASTER } from './dpmaster.entity';
import { RISKCATEGORYMASTER } from './risk-category.entity';
import { OCCUPATIONMASTER } from './occupation-master.entity';
//import { PGMASTER } from './pgmaster.entity';
//import { CASTMASTER } from './cast-master.entity'
//import { OCCUPATIONMASTER } from './ocuupation-master.entity'
//import { RISKCATEGORYMASTER } from './risk-category.entity'
@Entity({name:'idmaster'})
@Unique(['AC_NO'])
@Index("NDXIDMASTER", ["BRANCH_CODE", "AC_NO"])
export class IDMASTER {

   @PrimaryGeneratedColumn()
    id!: number;


    @Column({ name: 'AC_NO', type: 'int' })
    AC_NO!: number;  



    @Column({ nullable: true })
    AC_MEMBTYPE!: number;

    @Column({ nullable: true })
    AC_MEMBNO!: number;

    @Column({ nullable: true })
    AC_TITLE!: string;

    @Column({ nullable: true })
    F_NAME!: string;

    @Column({ nullable: true })
    L_NAME!: string;

    @Column({ nullable: true })
    M_NAME!: string;

    @Column({ nullable: true })
    AC_NAME!: string;

    // @Column({ default: 0 })
   @Column({ type: 'int', nullable: true })
AC_OCODE!: number | null;

    @Column({ nullable: true, length: 14 })
    AC_ADHARNO!: string;

    // @Column({ default: 0 })
   @Column({ type: 'int', nullable: true })
AC_RISKCATG!: number | null;

   @Column({ type: 'varchar', nullable: true })
    AC_BIRTH_DT!: string | null;

    @Column({ nullable: true })
    AC_PANNO!: string;

    // @Column({ nullable: true })
    // AC_SALARYDIVISION_CODE: string;

    @Column({ nullable: true, length: 13 })
    AC_MOBILENO!: string;

    @Column({ nullable: true })
    AC_PHONE_RES!: string;

    @Column({ nullable: true })
    AC_PHONE_OFFICE!: string;

    @Column({ nullable: true })
    AC_EMAILID!: string;

    @Column({ nullable: true, default: 0 })
    TDSDOCUMNET!: string;

    // @Column({ nullable: true })
    // AC_IS_RECOVERY: string;

    @Column({ nullable: true, default: 0 })
    TDS_REQUIRED!: string;

    @Column({ nullable: true, default: 0 })
    SMS_REQUIRED!: string;

    @Column({ nullable: true, default: 0 })
    IS_KYC_RECEIVED!: string;

    @CreateDateColumn({ nullable: true })
    SYSADD_DATETIME!: Date;

    @Column({ nullable: true })
    SYSADD_LOGIN!: string;

    @UpdateDateColumn()
    SYSCHNG_DATETIME!: Date;

    @Column({ nullable: true })
    SYSCHNG_LOGIN!: string;

    @Index('IDMASTERBRANCH')
    @Column({ nullable: true })
    BRANCH_CODE!: number;

    // @OneToMany(() => CUSTOMERADDRESS, custAddress => custAddress.idmaster, {
    //     cascade: ["insert", "update"]
    // })
    // custAddress: CUSTOMERADDRESS[];

    // @OneToOne(() => TDSFORMSUBMIT, tdsForm => tdsForm.idmaster, {
    //     cascade: ["insert", "update"]
    // })
    // tdsForm: TDSFORMSUBMIT[];

    @OneToMany(() => SHMASTER, shareMaster => shareMaster.idmaster, {
        cascade: ["insert", "update"]
    })
    shareMaster!: SHMASTER[];

    @OneToMany(() => DPMASTER, dpmaster => dpmaster.idmaster, {
        cascade: ["insert", "update"]
    })
    dpmaster!: DPMASTER[];

    // @OneToMany(() => CUSTDOCUMENT, custdocument => custdocument.idmaster, {
    //     cascade: ["insert", "update"]
    // })
    // custdocument: CUSTDOCUMENT[];

    @OneToMany(() => LNMASTER, ln => ln.idmaster)
    termLoan!: LNMASTER[];


    // @OneToMany(() => PGMASTER, pgmaster => pgmaster.idmaster, {
    //     cascade: ["insert", "update"]
    // })
    // pgmaster: PGMASTER[];

    // @Column({ default: 0 })
   
@Column({ type: 'int', nullable: true })
AC_CAST!: number | null;

    @Column({ nullable: true })
    AC_TITLE_REG!: string;
    @Column({ nullable: true })
    F_NAME_REG!: string;
    @Column({ nullable: true })
    M_NAME_REG!: string;
    @Column({ nullable: true })
    L_NAME_REG!: string;
    @Column({ nullable: true })
    AC_ADD_REG!: string;


    @Column({ nullable: true })
    ORA_AC_NO!: number;

    @Column({ nullable: true })
    ORA_BRANCH!: number;

//    @ManyToOne(() => CASTMASTER)
// @JoinColumn({ name: "AC_CAST" })
// castMaster: CASTMASTER;



    @ManyToOne(() => OCCUPATIONMASTER)
    @JoinColumn({ name: "AC_OCODE" })
    occupMaster!: OCCUPATIONMASTER;


    @ManyToOne(() => RISKCATEGORYMASTER)
    @JoinColumn({ name: "AC_RISKCATG" })
    riskCategory!: RISKCATEGORYMASTER;

}
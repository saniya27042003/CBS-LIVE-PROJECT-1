// src/font-decoder/index.ts
// export * from './yogesh/yogesh.decoder';
// export { repairYogeshStream } from './yogesh/yogesh.stream-repair';
// export { normalizeDevanagari } from './yogesh/yogesh.normalize';
// export { dictionaryFixMarathiName } from './yogesh/yogesh.dictionary';
// export { decodeYogesh } from './yogesh/yogesh.decoder';



// src/font-decoder/index.ts
export { decodeYogesh } from './yogesh/yogesh.decoder';
// export { transliterateToEnglish } from './yogesh/yogesh.transliterate'; 
export{transliterateMarathiToEnglish} from'./yogesh/yogesh.transliterate';



import { Column, CreateDateColumn, Entity, Generated, JoinColumn, ManyToOne, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { IDMASTER } from './customer-id.entity';
import { LNMASTER } from './term-loan-master.entity';

@Entity()
export class SECURITYDETAILS {

    @PrimaryGeneratedColumn()
    id: number;

    @Column({ nullable: true })
    AC_ACNOTYPE: string

    @Column({ nullable: true })
    AC_TYPE: string

    @Column({ length: 15 })
    AC_NO: string

    @Column()
    @Generated('increment')
    SERIAL_NO: number

    @Column({ nullable: true })
    SECURITY_CODE: string

    @Column({ type: 'numeric', precision: 20, scale: 2, default: 0 })
    SECURITY_VALUE: number

    @Column()
    lnmasterID: number
    @ManyToOne(() => LNMASTER, (lnmaster) => lnmaster.securityMaster, {
        cascade: true
    })
    @JoinColumn({ name: "lnmasterID" })
    lnmaster: LNMASTER[];
}


// import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
// @Entity()
// export class OWNDEPOSIT {
//   @PrimaryGeneratedColumn()
//   id: number;

//   @Column({ nullable: true })
//   AC_TYPE: string

//   @Column()
//   AC_NO: number

//   @Column({ nullable: true })
//   DEPO_AC_TYPE: string

//   @Column({ nullable: true })
//   DEPO_AC_NO: string

//   @Column({ nullable: true })
//   LEDGER_BAL: string      //ask

//   // @Column({ nullable: true })
//   // SECU_CODE: string

//   @Column({ nullable: true })
//   RECEIPT_NO: string

//   @Column({ nullable: true })
//   DEPOSIT_AMT: string

//   @Column({ nullable: true })
//   AC_EXPIRE_DATE: string

//   @Column({ default: false })
//   IS_LIEN_MARK_CLEAR: boolean

//   @Column({ nullable: true })
//   BALANCE_OF_LOAN_ACCOUNT: string   //ask
// }

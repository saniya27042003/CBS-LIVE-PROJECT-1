export class ConnectionDto {
  host: string;
  port: string | number;
  username: string;
  password: string;
  database: string;
}
